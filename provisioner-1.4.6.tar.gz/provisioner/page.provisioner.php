<?php
$cssVersion = filemtime(__DIR__ . '/assets/css/provisioner.css');
$jsVersion = filemtime(__DIR__ . '/assets/js/provisioner.js');
echo '<link rel="stylesheet" href="/admin/modules/provisioner/assets/css/provisioner.css?v=' . $cssVersion . '">';
echo '<script src="/admin/modules/provisioner/assets/js/provisioner.js?v=' . $jsVersion . '"></script>';
echo FreePBX::Provisioner()->showPage();

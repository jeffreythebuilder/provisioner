<?php
global $db;
$version = '1.4.6';
$rawname = 'provisioner';

// Write to BOTH connections:
// global $db (PEAR DB) — modulefunctions.class.php reads/writes version here
// \FreePBX::Database() (PDO) — install.php uses this directly
//
// DELETE + INSERT ensures exactly one row (modulename has no unique key)
$sql = "DELETE FROM modules WHERE modulename='$rawname'";
$db->query($sql);
\FreePBX::Database()->exec($sql);
$sql = "INSERT INTO modules (modulename, version, enabled) VALUES ('$rawname', '$version', 1)";
$db->query($sql);
\FreePBX::Database()->exec($sql);
\FreePBX::Database()->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_SILENT);

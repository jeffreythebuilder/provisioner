<?php

namespace FreePBX\modules;

class Provisioner implements \BMO {
    private $db;
    private $sipTransportCache;
    private $python3BinaryCache = false;

    private static $ouiMap = [
        '0004f3' => 'digium',
        '000fd3' => 'digium',
        '00809f' => 'alcatel',
        '08005a' => 'alcatel',
        '001c0e' => 'alcatel',
        '00236a' => 'alcatel',
        '3c28a6' => 'alcatel',
        '00037f' => 'yealink',
        '001565' => 'yealink',
        '346671' => 'yealink',
        '5c116f' => 'yealink',
        '805ec0' => 'yealink',
        'c098e5' => 'yealink',
        'f40e22' => 'yealink',
        'fc0fe6' => 'yealink',
        '000c41' => 'polycom',
        '00904f' => 'polycom',
        '000e53' => 'snom',
        '000413' => 'cisco',
        '001681' => 'grandstream',
    ];

    public function getBrandByMac($mac) {
        $prefix = substr(strtolower(preg_replace('/[^a-f0-9]/i', '', $mac)), 0, 6);
        return self::$ouiMap[$prefix] ?? null;
    }

    public function getBrands() {
        $dirs = glob(__DIR__ . '/templates/*', GLOB_ONLYDIR);
        $brands = [];
        foreach ($dirs as $dir) {
            $name = basename($dir);
            if (file_exists("$dir/default.cfg")) $brands[] = $name;
        }
        sort($brands);
        return $brands;
    }

    private function getSupportedDiscoveryBrand($mac) {
        $brand = $this->getBrandByMac($mac);
        if (!$brand || !in_array($brand, $this->getBrands(), true)) return null;
        return method_exists($this, 'generate' . ucfirst($brand) . 'Config') ? $brand : null;
    }

    public function getExtensions() {
        if (!class_exists('FreePBX') || !\FreePBX::Core()) return [];
        $users = \FreePBX::Core()->listUsers();
        $exts = [];
        foreach ($users as $u) {
            $exts[] = ['extension' => $u[0], 'name' => $u[1]];
        }
        return $exts;
    }

    public function autoAssignExtensions() {
        $stmt = $this->db->query("SELECT id, mac_address, extension FROM provisioner_devices ORDER BY mac_address ASC");
        $devices = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $assigned = array_column($devices, 'extension');
        $assigned = array_filter($assigned, fn($v) => $v !== '');

        if (!class_exists('FreePBX') || !\FreePBX::Core()) {
            return ['success' => false, 'error' => 'Cannot access FreePBX extensions'];
        }
        $users = \FreePBX::Core()->listUsers();
        $allExts = array_map(fn($u) => $u[0], $users);
        sort($allExts, SORT_NUMERIC);
        $freeExts = array_values(array_diff($allExts, $assigned));

        $assignments = [];
        foreach ($devices as $d) {
            if (empty($d['extension'])) {
                $ext = array_shift($freeExts);
                if ($ext === null) break;
                $assignments[] = ['id' => $d['id'], 'mac' => $d['mac_address'], 'extension' => $ext];
            }
        }

        if (!empty($_REQUEST['save'])) {
            $now = date('Y-m-d H:i:s');
            foreach ($assignments as $a) {
                $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, needs_changes=1, updated_at=? WHERE id=?");
                $stmt->execute([$a['extension'], $now, $a['id']]);
            }
            $this->addLog('device', "Auto-assigned " . count($assignments) . " extension(s)", 'success');
            $deployMode = $this->getSetting('deploy_mode') ?: 'dhcp';
            return ['success' => true, 'assignments' => $assignments, 'deploy_mode' => $deployMode];
        }

        return ['success' => true, 'assignments' => $assignments];
    }

    public function exportCsv() {
        $rows = $this->db->query("SELECT extension, mac_address, brand, description, static_ip, static_mask, static_gw FROM provisioner_devices ORDER BY extension ASC");
        $csv = "Extension,MAC,Brand,Description,Static IP,Subnet Mask,Gateway\n";
        while ($row = $rows->fetch(\PDO::FETCH_ASSOC)) {
            $csv .= '"' . $row['extension'] . '","' . $row['mac_address'] . '","' . ($row['brand'] ?: 'digium') . '","' . str_replace('"', '""', $row['description'] ?? '') . '","' . ($row['static_ip'] ?? '') . '","' . ($row['static_mask'] ?? '') . '","' . ($row['static_gw'] ?? '') . '"' . "\n";
        }
        return ['success' => true, 'csv' => $csv];
    }

    public function __construct($freepbx = null) {
        if ($freepbx) {
            $this->db = $freepbx->Database();
        }
    }

    public function install() {}
    public function uninstall() {}
    public function backup() {}
    public function restore($backup) {}
    public function doConfigPageInit($page) {}

    public function getSetting($key) {
        $stmt = $this->db->prepare("SELECT value FROM provisioner_settings WHERE key_name=?");
        $stmt->execute([$key]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $row['value'] : null;
    }

    public function setSetting($key, $value) {
        $stmt = $this->db->prepare("INSERT INTO provisioner_settings (key_name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value=?");
        $stmt->execute([$key, $value, $value]);
    }

    public function getSettings() {
        $stmt = $this->db->query("SELECT key_name, value FROM provisioner_settings");
        $settings = [];
        while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $settings[$row['key_name']] = $row['value'];
        }
        return $settings;
    }

    public function saveSettings($data) {
        if (array_key_exists('scan_subnets', $data)) {
            $scanSubnets = $this->normalizeScanSubnets($data['scan_subnets']);
            if ($scanSubnets === null) {
                return ['success' => false, 'error' => 'Scan Subnets must contain valid IPv4 CIDR ranges separated by commas.'];
            }
            $data['scan_subnets'] = implode(', ', $scanSubnets);
        }
        $keys = ['pbx_ip', 'sip_port', 'transport', 'prov_dir', 'scan_subnets', 'phone_admin_pass', 'phone_admin_pass_alcatel', 'deploy_mode', 'vlan_id', 'vlan_data_id', 'dhcp_leases_file'];
        foreach ($keys as $key) {
            if (isset($data[$key])) {
                $this->setSetting($key, $data[$key]);
            }
        }
        $this->addLog('settings', 'Settings updated', 'success');
        return ['success' => true];
    }

    private function normalizeScanSubnets($value) {
        $value = trim((string)$value);
        if ($value === '') return [];
        $subnets = [];
        foreach (preg_split('/\s*,\s*/', $value) as $subnet) {
            if (!preg_match('/^(\d+\.\d+\.\d+\.\d+)\/(\d{1,2})$/', trim($subnet), $m)) return null;
            $prefix = (int)$m[2];
            $ipLong = ip2long($m[1]);
            if ($ipLong === false || $prefix < 8 || $prefix > 30) return null;
            $mask = -1 << (32 - $prefix);
            $subnets[] = long2ip($ipLong & $mask) . '/' . $prefix;
        }
        return array_values(array_unique($subnets));
    }

    public function getSipTransportInfo() {
        if ($this->sipTransportCache !== null) return $this->sipTransportCache;
        $output = shell_exec('asterisk -rx "pjsip show transports" 2>/dev/null');
        $all = [];
        if ($output) {
            foreach (explode("\n", $output) as $line) {
                if (!preg_match('/^\s*Transport:\s+(\S+)\s+(udp|tcp|tls)\s+\S+\s+\S+\s+(\S+)\s*$/i', $line, $m)) continue;
                $bind = $m[3];
                if (!preg_match('/^(?:\[([^\]]+)\]|(.+)):(\d+)$/', $bind, $address)) continue;
                $protocol = strtoupper($m[2]);
                $all[$protocol][] = [
                    'id' => $m[1],
                    'protocol' => $protocol,
                    'bind_address' => $address[1] !== '' ? $address[1] : $address[2],
                    'port' => (int)$address[3]
                ];
            }
        }

        $pbxIp = $this->getSetting('pbx_ip') ?: '';
        $selected = [];
        foreach ($all as $protocol => $transports) {
            usort($transports, function ($a, $b) use ($pbxIp) {
                $rank = function ($transport) use ($pbxIp) {
                    if ($transport['bind_address'] === '0.0.0.0' || $transport['bind_address'] === '::') return 0;
                    if ($pbxIp && $transport['bind_address'] === $pbxIp) return 1;
                    return 2;
                };
                return $rank($a) <=> $rank($b);
            });
            $selected[$protocol] = $transports[0];
            $all[$protocol] = $transports;
        }

        $this->sipTransportCache = [
            'success' => !empty($selected),
            'source' => !empty($selected) ? 'Asterisk runtime' : 'Provisioner fallback',
            'transports' => $selected,
            'all' => $all,
            'fallback_port' => (int)($this->getSetting('sip_port') ?: 5060)
        ];
        return $this->sipTransportCache;
    }

    private function getDetectedSipPort($transport) {
        $protocol = strtoupper((string)$transport);
        $info = $this->getSipTransportInfo();
        if (!empty($info['transports'][$protocol]['port'])) return (string)$info['transports'][$protocol]['port'];
        return (string)($this->getSetting('sip_port') ?: '5060');
    }

    private function findPython3Binary($candidates = null) {
        $useCache = $candidates === null;
        if ($useCache && $this->python3BinaryCache !== false) return $this->python3BinaryCache;

        if ($candidates === null) {
            $candidates = [
                '/usr/bin/python3',
                '/usr/local/bin/python3',
                '/usr/bin/python3.6',
                '/usr/local/bin/python3.6'
            ];
            foreach (['python3', 'python3.6'] as $command) {
                $path = trim((string)shell_exec('command -v ' . $command . ' 2>/dev/null'));
                if ($path !== '') $candidates[] = $path;
            }
        }

        foreach (array_unique($candidates) as $candidate) {
            if (!is_string($candidate) || !is_executable($candidate)) continue;
            $check = escapeshellarg($candidate) . ' -c ' . escapeshellarg('import sys; print(sys.version_info[0])') . ' 2>/dev/null';
            if (trim((string)shell_exec($check)) === '3') {
                if ($useCache) $this->python3BinaryCache = $candidate;
                return $candidate;
            }
        }

        if ($useCache) $this->python3BinaryCache = null;
        return null;
    }

    // =====================
    // PHONE STATUS
    // =====================
    private function isPhoneReachable($ip) {
        $arp = @file_get_contents('/proc/net/arp');
        if (!$arp) return false;
        foreach (explode("\n", $arp) as $line) {
            $parts = preg_split('/\s+/', trim($line));
            if (isset($parts[0]) && $parts[0] === $ip && isset($parts[3]) && $parts[3] === '0x2') {
                return true;
            }
        }
        return false;
    }

    private function isPrivateIp($ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return false;
        $parts = explode('.', $ip);
        $first = (int)$parts[0];
        $second = (int)$parts[1];
        if ($first === 10) return true;
        if ($first === 192 && $second === 168) return true;
        if ($first === 172 && $second >= 16 && $second <= 31) return true;
        if ($ip === '127.0.0.1') return true;
        return false;
    }

    private function getPjsipContacts($output = null) {
        if ($output === null) {
            $output = shell_exec('asterisk -rx "pjsip show contacts" 2>/dev/null');
        }
        $contacts = [];
        if (!$output) return $contacts;
        foreach (explode("\n", $output) as $line) {
            if (!preg_match('/^\s*Contact:\s+([^\/\s]+)\/sip:[^@\s]+@(\d+\.\d+\.\d+\.\d+)/i', $line, $m)) continue;
            $status = preg_match('/\b(Avail|Unavail)\b/i', $line, $state) ? ucfirst(strtolower($state[1])) : 'Unknown';
            $contacts[$m[1]] = [
                'ip' => $m[2],
                'status' => $status
            ];
        }
        return $contacts;
    }

    private function getCurrentArpMap() {
        $result = [];
        $arp = @file('/proc/net/arp');
        if (!$arp) return $result;
        foreach ($arp as $line) {
            $parts = preg_split('/\s+/', trim($line));
            if (count($parts) < 4 || $parts[2] !== '0x2') continue;
            $mac = strtolower(str_replace(':', '', $parts[3]));
            if (strlen($mac) === 12) $result[$mac] = $parts[0];
        }
        return $result;
    }

    private function getDhcpLeaseMap() {
        $result = [];
        if (($this->getSetting('deploy_mode') ?: 'dhcp') !== 'dhcp') return $result;
        $path = $this->getSetting('dhcp_leases_file') ?: '/var/lib/misc/dnsmasq.leases';
        $lines = @file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines) return $result;
        foreach ($lines as $line) {
            $parts = preg_split('/\s+/', trim($line));
            if (count($parts) < 3) continue;
            $mac = strtolower(preg_replace('/[^a-f0-9]/i', '', $parts[1]));
            if (strlen($mac) === 12 && filter_var($parts[2], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $result[$mac] = $parts[2];
            }
        }
        return $result;
    }

    private function resolveDeviceTarget($device, $contacts = null, $arpMap = null, $dhcpMap = null, $arpFresh = false, $localSubnets = null) {
        $contacts = is_array($contacts) ? $contacts : $this->getPjsipContacts();
        $arpMap = is_array($arpMap) ? $arpMap : $this->getCurrentArpMap();
        $dhcpMap = is_array($dhcpMap) ? $dhcpMap : $this->getDhcpLeaseMap();
        $localSubnets = is_array($localSubnets) ? $localSubnets : $this->getArpCapableSubnets();
        $mac = strtolower(preg_replace('/[^a-f0-9]/i', '', $device['mac_address'] ?? ''));
        $currentExtension = (string)($device['extension'] ?? '');
        $previousExtension = (string)($device['previous_extension'] ?? '');
        $extensionOrder = !empty($device['needs_changes']) && $previousExtension !== '' && $previousExtension !== $currentExtension
            ? [$previousExtension, $currentExtension]
            : [$currentExtension, $previousExtension];
        $extensions = array_values(array_unique(array_filter($extensionOrder, 'strlen')));
        $pjsipCandidate = null;
        foreach ($extensions as $extension) {
            if (!empty($contacts[$extension]['ip'])) {
                $pjsipCandidate = [
                    'source' => 'pjsip',
                    'label' => 'PJSIP contact (' . $extension . ')',
                    'ip' => $contacts[$extension]['ip'],
                    'status' => $contacts[$extension]['status'] ?? 'Unknown',
                    'stale' => false
                ];
                break;
            }
        }
        $arpCandidate = !empty($arpMap[$mac]) ? [
            'source' => 'arp',
            'label' => $arpFresh ? 'Fresh ARP (active sweep)' : 'ARP cache',
            'ip' => $arpMap[$mac],
            'stale' => !$arpFresh
        ] : null;
        $conflict = $arpFresh && $arpCandidate && $pjsipCandidate && $arpCandidate['ip'] !== $pjsipCandidate['ip'];

        $raw = [];
        if ($arpFresh && $arpCandidate) $raw[] = $arpCandidate;
        if ($pjsipCandidate) $raw[] = $pjsipCandidate;
        if (!empty($device['static_ip'])) $raw[] = ['source' => 'static_ip', 'label' => 'Static IP', 'ip' => $device['static_ip'], 'stale' => false];
        if (!empty($dhcpMap[$mac])) {
            $dhcpLocal = $this->ipInSubnets($dhcpMap[$mac], $localSubnets);
            $raw[] = [
                'source' => 'dhcp',
                'label' => 'DHCP lease',
                'ip' => $dhcpMap[$mac],
                'stale' => false,
                'eligible' => $dhcpLocal,
                'ignored_reason' => $dhcpLocal ? null : 'Lease is not on a directly connected subnet'
            ];
        }
        if (!$arpFresh && $arpCandidate) $raw[] = $arpCandidate;
        if (!empty($device['ip_address'])) $raw[] = ['source' => 'stored', 'label' => 'Stored last-known IP', 'ip' => $device['ip_address'], 'stale' => true];

        $candidates = [];
        $selectedIp = null;
        $selectedSource = null;
        foreach ($raw as $candidate) {
            $candidate['valid'] = $this->isPrivateIp($candidate['ip']);
            if (!isset($candidate['eligible'])) $candidate['eligible'] = true;
            $candidate['selected'] = false;
            if (!$conflict && $selectedIp === null && $candidate['valid'] && $candidate['eligible']) {
                $selectedIp = $candidate['ip'];
                $selectedSource = $candidate['source'];
                $candidate['selected'] = true;
            }
            $candidates[] = $candidate;
        }

        $confidence = 'unresolved';
        if ($conflict) {
            $confidence = 'conflict';
        } elseif ($selectedSource === 'arp' && $pjsipCandidate && $selectedIp === $pjsipCandidate['ip']) {
            $selectedSource = 'arp_pjsip';
            $confidence = 'verified';
            foreach ($candidates as &$candidate) {
                if ($candidate['ip'] === $selectedIp && in_array($candidate['source'], ['arp', 'pjsip'], true)) $candidate['selected'] = true;
            }
            unset($candidate);
        } elseif ($selectedSource === 'arp') {
            $confidence = $arpFresh ? 'mac_verified' : 'arp_cached';
        } elseif ($selectedSource === 'pjsip') {
            $confidence = 'cross_subnet';
        } elseif (in_array($selectedSource, ['static_ip', 'dhcp'], true)) {
            $confidence = 'configured';
        } elseif ($selectedSource === 'stored') {
            $confidence = 'stale';
        }

        return [
            'selected_ip' => $selectedIp,
            'selected_source' => $selectedSource,
            'is_stale_fallback' => $selectedSource === 'stored',
            'confidence' => $confidence,
            'conflict' => $conflict,
            'conflict_message' => $conflict ? 'Fresh ARP maps the configured MAC to ' . $arpCandidate['ip'] . ' but PJSIP maps extension ' . ($extensions[0] ?? '') . ' to ' . $pjsipCandidate['ip'] . '.' : null,
            'candidates' => $candidates,
            'pjsip_status' => $this->getDevicePjsipStatus($extensions, $contacts)
        ];
    }

    private function getDevicePjsipStatus($extensions, $contacts) {
        foreach ($extensions as $extension) {
            if (isset($contacts[$extension])) return $contacts[$extension]['status'] ?? 'Unknown';
        }
        return 'Not registered';
    }

    private function getArpCapableSubnets() {
        $links = shell_exec('ip -o link show 2>/dev/null');
        $addresses = shell_exec('ip -o -f inet addr show up 2>/dev/null');
        if (!$links || !$addresses) return [];
        $interfaces = [];
        foreach (explode("\n", trim($links)) as $line) {
            if (!preg_match('/^\d+:\s+([^:]+):\s+<([^>]+)>.*\bstate\s+(\w+)/', $line, $m)) continue;
            $flags = explode(',', $m[2]);
            if ($m[3] === 'UP' && in_array('BROADCAST', $flags, true) && in_array('UP', $flags, true) && in_array('LOWER_UP', $flags, true) && !in_array('NOARP', $flags, true)) {
                $interfaces[explode('@', $m[1], 2)[0]] = true;
            }
        }
        $subnets = [];
        foreach (explode("\n", trim($addresses)) as $line) {
            if (!preg_match('/^\d+:\s+(\S+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)\/(\d+)/', $line, $m)) continue;
            $interface = explode('@', $m[1], 2)[0];
            if (empty($interfaces[$interface])) continue;
            $prefix = (int)$m[3];
            if ($prefix < 8 || $prefix > 30) continue;
            $network = long2ip(ip2long($m[2]) & (-1 << (32 - $prefix)));
            $subnets[] = $network . '/' . $prefix;
        }
        return array_values(array_unique($subnets));
    }

    private function getConfiguredScanSubnets() {
        $configured = $this->normalizeScanSubnets($this->getSetting('scan_subnets') ?: '');
        if (!empty($configured)) return $configured;

        $pbxIp = $this->getSetting('pbx_ip') ?: '';
        foreach ($this->getNetworkInterfaces() as $interface) {
            if ($pbxIp !== '' && $interface['ip'] === $pbxIp) return [$interface['subnet']];
        }
        return $this->getArpCapableSubnets();
    }

    private function ipInSubnet($ip, $subnet) {
        if (!$this->isPrivateIp($ip) || strpos($subnet, '/') === false) return false;
        [$network, $prefix] = explode('/', $subnet, 2);
        $prefix = (int)$prefix;
        if (!filter_var($network, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) || $prefix < 0 || $prefix > 32) return false;
        $mask = $prefix === 0 ? 0 : (-1 << (32 - $prefix));
        return (ip2long($ip) & $mask) === (ip2long($network) & $mask);
    }

    private function ipInSubnets($ip, $subnets) {
        foreach ($subnets as $subnet) {
            if ($this->ipInSubnet($ip, $subnet)) return true;
        }
        return false;
    }

    private function annotateResolutionMode($target, $localSubnets) {
        if (!empty($target['conflict'])) $target['resolution_mode'] = 'conflict';
        elseif ($target['confidence'] === 'verified') $target['resolution_mode'] = 'local_verified';
        elseif ($target['confidence'] === 'mac_verified') $target['resolution_mode'] = 'local_mac_verified';
        elseif ($target['selected_source'] === 'pjsip') $target['resolution_mode'] = $this->ipInSubnets($target['selected_ip'], $localSubnets) ? 'local_unverified' : 'cross_subnet';
        elseif (in_array($target['selected_source'], ['static_ip', 'dhcp'], true)) $target['resolution_mode'] = $this->ipInSubnets($target['selected_ip'], $localSubnets) ? 'local_configured' : 'cross_subnet_configured';
        elseif ($target['selected_source'] === 'stored') $target['resolution_mode'] = 'stale';
        else $target['resolution_mode'] = 'unresolved';
        return $target;
    }

    private function applyPendingSwapTargetOverrides($targets, $groups = null) {
        $groups = $groups === null ? $this->getPendingExtensionSwapGroups() : $groups;
        foreach ($groups as $group) {
            $arpByMac = [];
            $arpIps = [];
            $valid = true;
            $hasConflict = false;
            foreach ($group as $mac) {
                if (empty($targets[$mac])) {
                    $valid = false;
                    break;
                }
                $arp = null;
                foreach ($targets[$mac]['candidates'] as $candidate) {
                    if ($candidate['source'] === 'arp' && empty($candidate['stale']) && !empty($candidate['valid'])) $arp = $candidate;
                }
                if (!$arp || isset($arpIps[$arp['ip']])) {
                    $valid = false;
                    break;
                }
                $arpByMac[$mac] = $arp['ip'];
                $arpIps[$arp['ip']] = true;
                $hasConflict = $hasConflict || !empty($targets[$mac]['conflict']);
            }
            if (!$valid || !$hasConflict) continue;

            foreach ($group as $mac) {
                foreach ($targets[$mac]['candidates'] as $candidate) {
                    if ($candidate['source'] === 'pjsip' && !isset($arpIps[$candidate['ip']])) {
                        $valid = false;
                        break 2;
                    }
                }
            }
            if (!$valid) continue;

            foreach ($group as $mac) {
                $targets[$mac]['selected_ip'] = $arpByMac[$mac];
                $targets[$mac]['selected_source'] = 'arp_swap_verified';
                $targets[$mac]['confidence'] = 'verified';
                $targets[$mac]['conflict'] = false;
                $targets[$mac]['conflict_message'] = null;
                $targets[$mac]['resolution_mode'] = 'local_verified';
                $targets[$mac]['extension_swap'] = true;
                foreach ($targets[$mac]['candidates'] as &$candidate) {
                    $candidate['selected'] = $candidate['source'] === 'arp' && $candidate['ip'] === $arpByMac[$mac];
                }
                unset($candidate);
            }
        }
        return $targets;
    }

    private function resolveDeviceTargets($performScan = false, $onlyMac = null) {
        if ($onlyMac) {
            $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE mac_address=?");
            $stmt->execute([strtolower($onlyMac)]);
            $devices = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } else {
            $devices = $this->db->query("SELECT * FROM provisioner_devices")->fetchAll(\PDO::FETCH_ASSOC);
        }
        $contacts = $this->getPjsipContacts();
        $arpMap = $this->getCurrentArpMap();
        $dhcpMap = $this->getDhcpLeaseMap();
        $localSubnets = $this->getArpCapableSubnets();
        $configuredScanSubnets = $this->getConfiguredScanSubnets();
        $targets = [];
        foreach ($devices as $device) {
            $mac = strtolower($device['mac_address']);
            $targets[$mac] = $this->annotateResolutionMode($this->resolveDeviceTarget($device, $contacts, $arpMap, $dhcpMap, false, $localSubnets), $localSubnets);
        }
        if ($performScan) {
            $scanSubnets = [];
            $hasCandidate = false;
            $scanAllLocal = false;
            foreach ($targets as $target) {
                if (empty($target['selected_ip']) || $target['selected_source'] === 'stored') $scanAllLocal = true;
                foreach ($target['candidates'] as $candidate) {
                    if (empty($candidate['valid'])) continue;
                    $hasCandidate = true;
                    foreach ($configuredScanSubnets as $subnet) {
                        if ($this->ipInSubnet($candidate['ip'], $subnet)) $scanSubnets[] = $subnet;
                    }
                }
            }
            if (!$hasCandidate || $scanAllLocal) $scanSubnets = $configuredScanSubnets;
            $scanSubnets = array_values(array_unique($scanSubnets));
            $arpMap = $scanSubnets ? $this->resolveDeviceIpsLocal($scanSubnets) : [];
            foreach ($devices as $device) {
                $mac = strtolower($device['mac_address']);
                $targets[$mac] = $this->annotateResolutionMode($this->resolveDeviceTarget($device, $contacts, $arpMap, $dhcpMap, true, $localSubnets), $localSubnets);
                $targets[$mac]['scan_performed'] = !empty($scanSubnets);
                $targets[$mac]['scan_subnets'] = $scanSubnets;
            }
        } else {
            foreach ($targets as &$target) {
                $target['scan_performed'] = false;
                $target['scan_subnets'] = [];
            }
            unset($target);
        }
        if ($performScan && !$onlyMac) $targets = $this->applyPendingSwapTargetOverrides($targets);
        return $targets;
    }

    private function testTcpPort($ip, $port, $timeout = 1) {
        if (!$ip) return false;
        $socket = @fsockopen($ip, $port, $errno, $error, $timeout);
        if (!$socket) return false;
        fclose($socket);
        return true;
    }

    public function getDeviceDiagnostics($mac, $active = false) {
        $mac = strtolower(preg_replace('/[^a-f0-9]/i', '', $mac));
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) return ['success' => false, 'error' => 'Device not found'];

        $targets = $this->resolveDeviceTargets((bool)$active, $mac);
        $target = $targets[$mac] ?? $this->resolveDeviceTarget($device);
        $brand = $device['brand'] ?: 'digium';
        $port = $brand === 'alcatel' ? 443 : 80;
        $path = $this->getConfigFilePath($mac);
        $configExists = file_exists($path);
        $pbxIp = $this->getSetting('pbx_ip') ?: $this->getLocalIP();
        $provPort = $this->getSetting('prov_port') ?: '2001';

        return [
            'success' => true,
            'device' => [
                'mac' => $mac,
                'extension' => $device['extension'],
                'previous_extension' => $device['previous_extension'],
                'brand' => $brand,
                'description' => $device['description'],
                'static_ip' => $device['static_ip'],
                'stored_ip' => $device['ip_address']
            ],
            'target' => $target,
            'service' => [
                'port' => $port,
                'reachable' => $this->testTcpPort($target['selected_ip'], $port),
                'fetch_supported' => in_array($brand, ['digium', 'alcatel'], true)
            ],
            'config' => [
                'filename' => $this->getDeviceConfigFilename($mac),
                'path' => $path,
                'exists' => $configExists,
                'size' => $configExists ? filesize($path) : 0,
                'modified' => $configExists ? date('Y-m-d H:i:s', filemtime($path)) : null,
                'valid' => $configExists ? $this->isValidPhoneConfig($mac, file_get_contents($path)) : null,
                'custom' => !empty($device['custom_config'])
            ],
            'provisioning_url' => "http://{$pbxIp}:{$provPort}/provisioning/",
            'last_push' => [
                'status' => $device['last_push_status'],
                'attempt' => $device['last_push_attempt_at'],
                'ack' => $device['last_ack_at']
            ]
        ];
    }

    public function getPhoneStatus() {
        $devices = $this->getDevices();
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $contacts = $this->getPjsipContacts();
        $arpMap = $this->getCurrentArpMap();
        $dhcpMap = $this->getDhcpLeaseMap();
        $localSubnets = $this->getArpCapableSubnets();
        $results = [];

        foreach ($devices as $device) {
            $needsChanges = !empty($device['needs_changes']);

            $ext  = $device['extension'];
            $desc = $device['description'];
            $mac  = $device['mac_address'];

            if ($needsChanges) {
                $ext  = $device['previous_extension'] !== null ? $device['previous_extension'] : $ext;
                $desc = $device['previous_description'] !== null ? $device['previous_description'] : $desc;
            }

            $configExists = file_exists($provDir . '/' . $mac . '.cfg') || file_exists($provDir . '/config.' . $mac . '.xml');

            $targetDevice = $device;
            $targetDevice['extension'] = $ext;
            $target = $this->resolveDeviceTarget($targetDevice, $contacts, $arpMap, $dhcpMap, false, $localSubnets);
            $status = $target['pjsip_status'] === 'Not registered' ? 'Unavailable' : $target['pjsip_status'];
            $ip = $target['selected_ip'] ?: '';

            $results[] = [
                'extension'     => $ext,
                'mac'           => $mac,
                'description'   => $desc,
                'brand'         => $device['brand'] ?? 'digium',
                'ip'            => $ip,
                'status'        => $status,
                'needs_changes' => $needsChanges,
                'config_exists' => $configExists,
                'last_ack_at'   => $device['last_ack_at'] ?? null,
                'last_push_status' => $device['last_push_status'] ?? null,
                'ip_source'     => $target['selected_source'],
                'stale_ip'      => $target['is_stale_fallback']
            ];
        }

        return $results;
    }

    public function getPhoneStatusGrid() {
        $raw = $this->getPhoneStatus();
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $rows = [];
        foreach ($raw as $r) {
            $configExists = file_exists($provDir . '/' . $r['mac'] . '.cfg') || file_exists($provDir . '/config.' . $r['mac'] . '.xml');
            $isRegistered = $r['status'] === 'Avail' || $r['status'] === 'Unavail';
            $isAvail = $r['status'] === 'Avail';
            if ($r['needs_changes'] && $configExists) {
                $actions = '<a class="clickable reboot-btn" data-ext="' . $r['extension'] . '" title="Reboot"><i class="fa fa-power-off"></i></a>';
                $statusLabel = 'Apply Pending';
            } elseif ($r['needs_changes']) {
                $actions = '<span class="text-muted"><i class="fa fa-clock-o"></i> Push first</span>';
                $statusLabel = 'Config Pending';
            } elseif ($isAvail) {
                $actions = '<a class="clickable reboot-btn" data-ext="' . $r['extension'] . '" title="Reboot"><i class="fa fa-power-off"></i></a>';
                $statusLabel = 'Registered';
            } elseif (!$r['config_exists']) {
                $actions = '<span class="text-muted"><i class="fa fa-file-text-o"></i> Push config</span>';
                $statusLabel = 'No Config';
            } elseif ($isRegistered) {
                $actions = '<span class="text-muted"><i class="fa fa-power-off"></i></span>';
                $statusLabel = (!empty($r['ip']) && $this->isPhoneReachable($r['ip'])) ? 'Unreachable' : 'Offline';
            } elseif (!empty($r['ip'])) {
                $actions = '<a class="clickable reboot-btn" data-ext="' . $r['extension'] . '" title="Reboot"><i class="fa fa-power-off"></i></a>';
                $statusLabel = $this->isPhoneReachable($r['ip']) ? 'Online' : 'Offline';
            } else {
                $actions = '<span class="text-muted"><i class="fa fa-power-off"></i></span>';
                $statusLabel = 'Offline';
            }
            $actions .= ' <a class="clickable diagnostics-btn" data-mac="' . $r['mac'] . '" title="Device diagnostics"><i class="fa fa-stethoscope"></i></a>';
            $lastAck = $r['last_ack_at'] ?? null;
            if ($lastAck) {
                $ts = strtotime($lastAck);
                $ago = time() - $ts;
                if ($ago < 60) $ackLabel = 'Just now';
                elseif ($ago < 3600) $ackLabel = floor($ago / 60) . 'm ago';
                elseif ($ago < 86400) $ackLabel = floor($ago / 3600) . 'h ago';
                else $ackLabel = date('M j', $ts);
            } else {
                $ackLabel = 'Never';
            }

            $pushStatus = $r['last_push_status'] ?? null;
            if ($pushStatus === 'success') {
                $pushLabel = '<span class="text-success">OK</span>';
            } elseif ($pushStatus === 'failed') {
                $pushLabel = '<span class="text-danger">Failed</span> <a class="clickable retry-push-btn" data-mac="' . $r['mac'] . '" title="Retry push"><i class="fa fa-repeat"></i></a>';
            } else {
                $pushLabel = '<span class="text-muted">—</span>';
            }

            $rows[] = [
                'extension'   => $r['extension'],
                'mac'         => $r['mac'],
                'description' => $r['description'],
                'brand'       => ucfirst($r['brand']),
                'ip'          => $r['ip'],
                'status'      => $statusLabel,
                'push_status' => $pushLabel,
                'last_ack'    => $ackLabel,
                'actions'     => $actions
            ];
        }
        return $rows;
    }

    // =====================
    // REBOOT PHONE
    // =====================
    private function getBrandByExtension($extension) {
        $stmt = $this->db->prepare("SELECT brand FROM provisioner_devices WHERE extension=? OR previous_extension=?");
        $stmt->execute([$extension, $extension]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? ($row['brand'] ?? 'digium') : 'digium';
    }

    public function rebootPhone($extension) {
        $ext = preg_replace('/[^a-zA-Z0-9_-]/', '', $extension);
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE extension=? OR previous_extension=?");
        $stmt->execute([$ext, $ext]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        $target = $device ? $this->resolveDeviceTarget($device) : ['selected_ip' => null, 'selected_source' => null];
        $ip = $target['selected_ip'];
        $source = $target['selected_source'] ?: 'endpoint';
        if ($ip) {
            $output = shell_exec("asterisk -rx \"pjsip send notify sync-reboot-sangoma uri sip:$ip\" 2>/dev/null");
        } else {
            $output = shell_exec("asterisk -rx \"pjsip send notify sync-reboot-sangoma endpoint $ext\" 2>/dev/null");
        }
        $success = strpos($output, 'Sending NOTIFY') !== false;
        if ($success) {
            $this->db->prepare("UPDATE provisioner_devices SET needs_changes = 0, previous_extension = NULL, previous_description = NULL WHERE previous_extension = ? OR extension = ?")
                ->execute([$extension, $extension]);
        }
        $this->addLog('reboot', "Reboot sent to extension $extension" . ($ip ? " (IP:$ip source:$source)" : " (endpoint fallback)"), $success ? 'success' : 'error');
        return ['success' => $success, 'output' => $output, 'ip' => $ip, 'ip_source' => $source];
    }

    public function rebootPhones($extensions) {
        $results = [];
        foreach ($extensions as $ext) {
            $results[] = $this->rebootPhone($ext);
        }
        return ['success' => true, 'results' => $results];
    }

    // =====================
    // GENERATE PROVISIONING
    // =====================
    private function cleanDeviceConfig($mac, $provDir) {
        foreach ([$mac . '.cfg', 'config.' . $mac . '.xml'] as $file) {
            $path = $provDir . '/' . $file;
            if (file_exists($path)) unlink($path);
        }
    }

    private function writeGeneratedConfig($path, $config) {
        $tmpPath = tempnam(dirname($path), '.generate-');
        if ($tmpPath === false) return false;

        $expectedBytes = strlen($config);
        $written = file_put_contents($tmpPath, $config, LOCK_EX);
        if ($written !== $expectedBytes) {
            @unlink($tmpPath);
            return false;
        }

        if (!@chmod($tmpPath, 0644)) {
            @unlink($tmpPath);
            return false;
        }
        @chown($tmpPath, 'asterisk');
        @chgrp($tmpPath, 'asterisk');
        if (!rename($tmpPath, $path)) {
            @unlink($tmpPath);
            return false;
        }
        return true;
    }

    private function cleanupConfigStagingDirectory($dir) {
        if (!is_dir($dir)) return;
        $handle = @opendir($dir);
        if ($handle) {
            while (($file = readdir($handle)) !== false) {
                if ($file !== '.' && $file !== '..') @unlink($dir . '/' . $file);
            }
            closedir($handle);
        }
        @rmdir($dir);
    }

    private function rollbackConfigActivations($activations) {
        $restored = true;
        foreach ($activations as $activation) {
            if ($activation['had_original']) {
                if (!file_exists($activation['backup_path']) || !@rename($activation['backup_path'], $activation['original_path'])) {
                    $restored = false;
                    continue;
                }
                if ($activation['target_path'] !== $activation['original_path'] && file_exists($activation['target_path'])) {
                    if (!@unlink($activation['target_path'])) $restored = false;
                }
            } elseif (file_exists($activation['target_path']) && !@unlink($activation['target_path'])) {
                $restored = false;
            }
            if ($activation['backup_path'] && file_exists($activation['backup_path'])) @unlink($activation['backup_path']);
        }
        return $restored;
    }

    private function generateDeviceConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir, $cleanupAlternate = true) {
        $mac = strtolower($device['mac_address']);
        $existingPath = $cleanupAlternate ? $this->getConfigFilePath($mac) : null;
        $brand = $device['brand'] ?? 'digium';
        $method = 'generate' . ucfirst($brand) . 'Config';
        if (method_exists($this, $method)) {
            $generated = $this->$method($device, $template, $pbxIp, $sipPort, $transportVal, $provDir);
            if (!$generated) return false;

            if ($cleanupAlternate) {
                $targetPath = $provDir . '/' . ($brand === 'alcatel' ? 'config.' . $mac . '.xml' : $mac . '.cfg');
                foreach ([$existingPath, $provDir . '/' . $mac . '.cfg', $provDir . '/config.' . $mac . '.xml'] as $path) {
                    if ($path !== $targetPath && file_exists($path)) @unlink($path);
                }
            }
            return true;
        }
        return null;
    }

    private function generateConfigSet($devices, $customMode = 'skip') {
        $pbxIp = $this->getSetting('pbx_ip') ?: '192.168.0.10';
        $transport = $this->getSetting('transport') ?: 'UDP';
        $sipPort = $this->getDetectedSipPort($transport);
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $transportMap = ['UDP' => '0', 'TCP' => '1', 'TLS' => '2', 'TCP/UDP' => '0'];
        $transportVal = isset($transportMap[$transport]) ? $transportMap[$transport] : '0';

        if (!is_dir($provDir) && !mkdir($provDir, 0755, true)) {
            return ['success' => false, 'error' => 'Failed to create provisioning directory.'];
        }
        @chown($provDir, 'asterisk');
        @chgrp($provDir, 'asterisk');
        if (!is_writable($provDir)) {
            return ['success' => false, 'error' => 'Provisioning directory is not writable.'];
        }

        $templates = [];
        $eligible = [];
        $customTransitions = [];
        $preservedCustom = [];
        foreach ($devices as $device) {
            $mac = strtolower($device['mac_address']);
            $extensionChanged = $device['previous_extension'] !== null
                && $device['previous_extension'] !== ''
                && (string)$device['previous_extension'] !== (string)$device['extension'];
            $isCustom = !empty($device['custom_config']);
            if ($isCustom && $customMode !== 'replace' && !($customMode === 'extension_changes' && $extensionChanged)) {
                $preservedCustom[] = $device['mac_address'];
                continue;
            }
            if ($isCustom) $customTransitions[$mac] = true;
            $eligible[$mac] = $device;
            $brand = $device['brand'] ?? 'digium';
            if (!array_key_exists($brand, $templates)) {
                $templateFile = __DIR__ . '/templates/' . $brand . '/default.cfg';
                $templates[$brand] = file_exists($templateFile) ? file_get_contents($templateFile) : null;
            }
        }
        if (empty($eligible)) {
            return ['success' => true, 'generated' => [], 'custom_replaced' => 0, 'preserved_custom' => $preservedCustom];
        }

        $configWriteLock = $this->acquireConfigWriteLock();
        if (!$configWriteLock) {
            return ['success' => false, 'error' => 'Another config activation is already in progress. Try again shortly.'];
        }

        $stagingDir = tempnam($provDir, '.apply-');
        if ($stagingDir === false || !@unlink($stagingDir) || !@mkdir($stagingDir, 0755)) {
            if ($stagingDir && file_exists($stagingDir)) @unlink($stagingDir);
            return ['success' => false, 'error' => 'Failed to create config generation staging directory.'];
        }

        $generated = [];
        try {
            foreach ($eligible as $mac => $device) {
                $brand = $device['brand'] ?? 'digium';
                $template = $templates[$brand] ?? null;
                if (!$template || !$this->generateDeviceConfig($device, $template, $pbxIp, $sipPort, $transportVal, $stagingDir, false)) {
                    $this->cleanupConfigStagingDirectory($stagingDir);
                    return ['success' => false, 'error' => "Failed to generate config for $mac. Active configs were not changed."];
                }
                $generated[] = $device['mac_address'];
            }
        } catch (\Throwable $e) {
            $this->cleanupConfigStagingDirectory($stagingDir);
            return ['success' => false, 'error' => 'Config generation failed: ' . $e->getMessage()];
        }

        $activations = [];
        foreach ($eligible as $mac => $device) {
            $brand = $device['brand'] ?? 'digium';
            $filename = $brand === 'alcatel' ? 'config.' . $mac . '.xml' : $mac . '.cfg';
            $originalPath = $this->getConfigFilePath($mac);
            $hadOriginal = file_exists($originalPath);
            $backupPath = null;
            if ($hadOriginal) {
                $backupPath = tempnam($provDir, '.active-');
                $content = file_get_contents($originalPath);
                $written = $backupPath === false || $content === false ? false : file_put_contents($backupPath, $content, LOCK_EX);
                if ($content === false || $written !== strlen($content)) {
                    if ($backupPath) @unlink($backupPath);
                    foreach ($activations as $activation) {
                        if ($activation['backup_path']) @unlink($activation['backup_path']);
                    }
                    $this->cleanupConfigStagingDirectory($stagingDir);
                    return ['success' => false, 'error' => "Failed to back up active config for $mac. Active configs were not changed."];
                }
                @chmod($backupPath, 0644);
            }
            $activations[$mac] = [
                'original_path' => $originalPath,
                'backup_path' => $backupPath,
                'had_original' => $hadOriginal,
                'staged_path' => $stagingDir . '/' . $filename,
                'target_path' => $provDir . '/' . $filename
            ];
        }

        foreach ($customTransitions as $mac => $_) {
            $activation = $activations[$mac];
            if (!$activation['had_original']) continue;
            $content = file_get_contents($activation['backup_path']);
            if ($content === false || !$this->writeGeneratedConfig($activation['original_path'] . '.custom.bak', $content)) {
                foreach ($activations as $item) {
                    if ($item['backup_path']) @unlink($item['backup_path']);
                }
                $this->cleanupConfigStagingDirectory($stagingDir);
                return ['success' => false, 'error' => "Failed to archive custom config for $mac. Active configs were not changed."];
            }
        }

        if (!empty($customTransitions)) {
            try {
                $macs = array_keys($customTransitions);
                $placeholders = implode(',', array_fill(0, count($macs), '?'));
                $updated = $this->db->prepare("UPDATE provisioner_devices SET custom_config=0 WHERE mac_address IN ($placeholders)")->execute($macs);
                if (!$updated) throw new \RuntimeException('Failed to clear custom config state');
            } catch (\Throwable $e) {
                foreach ($activations as $activation) {
                    if ($activation['backup_path']) @unlink($activation['backup_path']);
                }
                $this->cleanupConfigStagingDirectory($stagingDir);
                return ['success' => false, 'error' => 'Generated configs could not be activated in the database. Active configs were not changed.'];
            }
        }

        $activationError = null;
        foreach ($activations as $mac => $activation) {
            if (!@rename($activation['staged_path'], $activation['target_path'])) {
                $activationError = "Failed to activate generated config for $mac.";
                break;
            }
            foreach ([$activation['original_path'], $provDir . '/' . $mac . '.cfg', $provDir . '/config.' . $mac . '.xml'] as $path) {
                if ($path !== $activation['target_path'] && file_exists($path) && !@unlink($path)) {
                    $activationError = "Failed to remove the previous config for $mac.";
                    break 2;
                }
            }
        }

        if ($activationError !== null) {
            $restored = $this->rollbackConfigActivations($activations);
            if (!empty($customTransitions)) {
                try {
                    $macs = array_keys($customTransitions);
                    $placeholders = implode(',', array_fill(0, count($macs), '?'));
                    $reset = $this->db->prepare("UPDATE provisioner_devices SET custom_config=1 WHERE mac_address IN ($placeholders)")->execute($macs);
                    if (!$reset) $restored = false;
                } catch (\Throwable $e) {
                    $restored = false;
                }
            }
            $this->cleanupConfigStagingDirectory($stagingDir);
            $activationError .= $restored ? ' Original configs were restored.' : ' One or more original configs require manual recovery.';
            return ['success' => false, 'error' => $activationError];
        }

        foreach ($activations as $activation) {
            if ($activation['backup_path']) @unlink($activation['backup_path']);
        }
        $this->cleanupConfigStagingDirectory($stagingDir);
        if (!empty($customTransitions)) {
            $this->addLog('config', 'Archived and regenerated ' . count($customTransitions) . ' custom config(s)', 'success');
        }
        return [
            'success' => true,
            'generated' => $generated,
            'custom_replaced' => count($customTransitions),
            'preserved_custom' => $preservedCustom
        ];
    }

    private function generateDigiumConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $ext = $device['extension'];
        $mac = $device['mac_address'];

        $stmt = $this->db->prepare("SELECT data FROM sip WHERE id = ? AND keyword = 'secret'");
        $stmt->execute([$ext]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            $stmt = $this->db->prepare("SELECT data FROM pjsip WHERE id = ? AND keyword = 'password'");
            $stmt->execute([$ext]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        }

        if (!$row) return null;

        $secret = $row['data'];
        $tcpUdp = $transportVal === '0' ? '0' : '1';

        $wanMode = empty($device['static_ip']) ? 'DHCP' : 'STATIC';
        $dhcpEnabled = empty($device['static_ip']) ? '1' : '0';
        $staticIp = $device['static_ip'] ?? null ?: '0.0.0.0';
        $staticMask = $device['static_mask'] ?? null ?: '0.0.0.0';
        $staticGw = $device['static_gw'] ?? null ?: '0.0.0.0';
        $staticDns = empty($device['static_ip']) ? '8.8.8.8' : ($device['static_gw'] ?: '8.8.8.8');
        $ntpServer = $pbxIp;
        $provPort = $this->getSetting('prov_port') ?: '2001';
        $provUrl = "http://{$pbxIp}:{$provPort}/provisioning/";
        $vlanId = $this->getSetting('vlan_id') ?: '';
        $vlanDataId = $this->getSetting('vlan_data_id') ?: '';
        $vlanEnabled = $vlanId ? '1' : '0';

        $config = str_replace(
            ['{{MAC}}', '{{EXTENSION}}', '{{PBX_IP}}', '{{SIP_PORT}}', '{{SECRET}}', '{{TCP_UDP}}',
             '{{WAN_MODE}}', '{{STATIC_IP}}', '{{STATIC_MASK}}', '{{STATIC_GW}}', '{{STATIC_DNS}}', '{{DHCP_ENABLED}}',
             '{{NTP_SERVER}}', '{{PROV_URL}}', '{{VLAN_ENABLED}}', '{{VLAN_ID}}', '{{DATA_VLAN_ID}}'],
            [$mac, $ext, $pbxIp, $sipPort, $secret, $tcpUdp,
             $wanMode, $staticIp, $staticMask, $staticGw, $staticDns, $dhcpEnabled,
             $ntpServer, $provUrl, $vlanEnabled, $vlanId, $vlanDataId],
            $template
        );

        return $this->writeGeneratedConfig($provDir . '/' . $mac . '.cfg', $config);
    }

    private function generateAlcatelConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $ext = $device['extension'];
        $mac = $device['mac_address'];

        $stmt = $this->db->prepare("SELECT data FROM sip WHERE id = ? AND keyword = 'secret'");
        $stmt->execute([$ext]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            $stmt = $this->db->prepare("SELECT data FROM pjsip WHERE id = ? AND keyword = 'password'");
            $stmt->execute([$ext]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        }

        if (!$row) return null;

        $secret = $row['data'];
        $dhcpEnabled = empty($device['static_ip']) ? 'Dynamic' : 'Static';
        $staticIp = $device['static_ip'] ?? '';
        $staticMask = $device['static_mask'] ?? '';
        $staticGw = $device['static_gw'] ?? '';
        $staticDns = $staticIp ? ($staticGw ?: '8.8.8.8') : '';
        $adminPass = $this->getSetting('phone_admin_pass_alcatel') ?: '123456';
        $vlanId = $this->getSetting('vlan_id') ?: '';
        $vlanDataId = $this->getSetting('vlan_data_id') ?: '';
        $vlanEnabled = $vlanId ? 'true' : 'false';
        $dataVlanEnabled = $vlanDataId ? 'true' : 'false';
        $ntpServer = $pbxIp;

        $config = str_replace(
            ['{{MAC}}', '{{EXTENSION}}', '{{PBX_IP}}', '{{SIP_PORT}}', '{{USERNAME}}', '{{PASSWORD}}', '{{TRANSPORT}}',
             '{{DHCP_ENABLED}}', '{{STATIC_IP}}', '{{STATIC_MASK}}', '{{STATIC_GW}}', '{{STATIC_DNS}}',
             '{{ADMIN_PASS}}', '{{VLAN_ENABLED}}', '{{VLAN_ID}}', '{{DATA_VLAN_ENABLED}}', '{{DATA_VLAN_ID}}',
             '{{NTP_SERVER}}'],
            [$mac, $ext, $pbxIp, $sipPort, $ext, $secret, $transportVal === '0' ? '0' : '1',
             $dhcpEnabled, $staticIp, $staticMask, $staticGw, $staticDns,
             $adminPass, $vlanEnabled, $vlanId, $dataVlanEnabled, $vlanDataId,
             $ntpServer],
            $template
        );

        $file = 'config.' . $mac . '.xml';
        return $this->writeGeneratedConfig($provDir . '/' . $file, $config);
    }

    private function generateYealinkConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $ext = $device['extension'];
        $mac = $device['mac_address'];

        $stmt = $this->db->prepare("SELECT data FROM sip WHERE id = ? AND keyword = 'secret'");
        $stmt->execute([$ext]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            $stmt = $this->db->prepare("SELECT data FROM pjsip WHERE id = ? AND keyword = 'password'");
            $stmt->execute([$ext]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        }

        if (!$row) return null;

        $secret = $row['data'];
        $displayName = $device['description'] ?: $ext;
        $wanType = empty($device['static_ip']) ? '0' : '2';
        $staticIp = $device['static_ip'] ?? '';
        $staticMask = $device['static_mask'] ?? '';
        $staticGw = $device['static_gw'] ?? '';
        $staticDns = $staticIp ? ($staticGw ?: '8.8.8.8') : '';
        $dnsEnable = $staticIp ? '1' : '0';
        $ntpServer = $this->getSetting('ntp_server') ?: $pbxIp;
        $vlanId = $this->getSetting('vlan_id') ?: '';
        $vlanDataId = $this->getSetting('vlan_data_id') ?: '';
        $vlanEnable = $vlanId ? '1' : '0';
        $dataVlanEnable = $vlanDataId ? '1' : '0';

        $config = str_replace(
            ['{ext}', '{display_name}', '{secret}', '{server_addr}', '{server_port}', '{transport}',
             '{wan_type}', '{static_ip}', '{static_mask}', '{static_gw}', '{static_dns}', '{dns_enable}',
             '{ntp_server}', '{vlan_enable}', '{vlan_id}', '{data_vlan_enable}', '{data_vlan_id}'],
            [$ext, $displayName, $secret, $pbxIp, $sipPort, $transportVal,
             $wanType, $staticIp, $staticMask, $staticGw, $staticDns, $dnsEnable,
             $ntpServer, $vlanEnable, $vlanId, $dataVlanEnable, $vlanDataId],
            $template
        );

        return $this->writeGeneratedConfig($provDir . '/' . $mac . '.cfg', $config);
    }

    public function generateProvisioning() {
        $dir = '/var/www/html/provisioning';
        $output = shell_exec("chown -R asterisk:asterisk $dir 2>&1");
        return ['success' => true, 'output' => $output];
    }

    public function generateAllConfigs($replaceCustom = false) {
        $devices = $this->getDevices();
        if (empty($devices)) {
            return ['success' => true, 'generated' => 0, 'message' => 'No devices in MAC Mapping.'];
        }

        $customDevices = [];
        foreach ($devices as $device) {
            if (!empty($device['custom_config'])) $customDevices[] = strtolower($device['mac_address']);
        }
        if (!empty($customDevices) && !$replaceCustom) {
            return [
                'success' => true,
                'requires_confirmation' => true,
                'custom_count' => count($customDevices),
                'custom_macs' => $customDevices
            ];
        }

        $result = $this->generateConfigSet($devices, $replaceCustom ? 'replace' : 'skip');
        if (!$result['success']) return $result;
        $generated = count($result['generated']);
        $this->addLog('apply', "Generated configs for $generated devices (all)", 'success');
        return [
            'success' => true,
            'generated' => $generated,
            'custom_replaced' => $result['custom_replaced']
        ];
    }

    // =====================
    // MAC MAPPING / DEVICES
    // =====================
    public function getDevices() {
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices ORDER BY extension ASC");
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getDeviceGrid() {
        $devices = $this->getDevices();
        $rows = [];
        foreach ($devices as $d) {
            $isPending = !empty($d['needs_changes']);
            $actions = '';
            $brandBadge = $this->brandBadge($d['brand'] ?? 'digium');
            $staticIp = $d['static_ip'] ?? '';
            $staticLabel = $staticIp ? $staticIp : '';
            $assignedExtension = (string)($d['extension'] ?? '');
            $previousExtension = (string)($d['previous_extension'] ?? '');
            $extensionDisplay = htmlspecialchars($assignedExtension, ENT_QUOTES);
            if ($isPending && $previousExtension !== '' && $previousExtension !== $assignedExtension) {
                $extensionDisplay = htmlspecialchars($previousExtension, ENT_QUOTES)
                    . ' <span class="text-muted">&rarr;</span> <strong>' . htmlspecialchars($assignedExtension, ENT_QUOTES) . '</strong>';
            }
            $configState = $this->getDeviceConfigExtensionState($d);
            $configSync = $this->formatConfigSyncState($configState, false);
            $actions .= '<a class="clickable edit-device-btn" data-id="' . $d['id'] . '" data-mac="' . $d['mac_address'] . '" data-ext="' . $d['extension'] . '" data-desc="' . htmlspecialchars($d['description'] ?? '', ENT_QUOTES) . '" data-brand="' . ($d['brand'] ?? 'digium') . '" data-static-ip="' . htmlspecialchars($staticIp, ENT_QUOTES) . '" data-static-mask="' . htmlspecialchars($d['static_mask'] ?? '', ENT_QUOTES) . '" data-static-gw="' . htmlspecialchars($d['static_gw'] ?? '', ENT_QUOTES) . '" title="Edit"><i class="fa fa-edit"></i></a> ';
            $actions .= '<a class="clickable diagnostics-btn" data-mac="' . $d['mac_address'] . '" title="Device diagnostics"><i class="fa fa-stethoscope"></i></a> ';
            if ($isPending) {
                $actions .= '<a class="clickable revert-device-btn" data-id="' . $d['id'] . '" title="Revert"><i class="fa fa-undo"></i></a> ';
            }
            $actions .= '<a class="clickable delete-device-btn" data-id="' . $d['id'] . '" data-ext="' . $d['extension'] . '" title="Delete"><i class="fa fa-trash"></i></a>';
            $rows[] = [
                'id'          => $d['id'],
                'extension'   => $d['extension'],
                'extension_display' => $extensionDisplay,
                'mac_address' => $d['mac_address'],
                'brand'       => $brandBadge,
                'description' => $d['description'] ?? '',
                'static_ip'   => $staticLabel,
                'config_sync' => $configSync,
                'is_pending'  => $isPending,
                'actions'     => $actions
            ];
        }
        return $rows;
    }

    private function brandBadge($brand) {
        $colors = ['digium' => 'primary', 'alcatel' => 'info', 'yealink' => 'success', 'polycom' => 'warning'];
        $color = $colors[$brand] ?? 'default';
        return '<span class="badge badge-' . $color . '">' . htmlspecialchars(ucfirst($brand)) . '</span>';
    }

    public function getPendingCount() {
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE needs_changes = 1");
        $stmt->execute();
        $macs = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        $count = count($macs);
        $deployMode = $this->getSetting('deploy_mode') ?: 'dhcp';
        if ($count === 0) {
            return ['count' => 0, 'needs_reboot' => false, 'deploy_mode' => $deployMode];
        }
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $allHaveConfig = true;
        foreach ($macs as $mac) {
            if (!file_exists($provDir . '/' . $mac . '.cfg') && !file_exists($provDir . '/config.' . $mac . '.xml')) {
                $allHaveConfig = false;
                break;
            }
        }
        return ['count' => $count, 'needs_reboot' => $allHaveConfig, 'deploy_mode' => $deployMode];
    }

    private function getDuplicateDesiredExtensions() {
        $stmt = $this->db->query("SELECT extension FROM provisioner_devices WHERE extension IS NOT NULL AND extension <> '' GROUP BY extension HAVING COUNT(*) > 1 ORDER BY extension");
        return $stmt->fetchAll(\PDO::FETCH_COLUMN);
    }

    private function getPendingExtensionSwapGroups($rows = null) {
        if ($rows === null) {
            $rows = $this->db->query("SELECT mac_address, extension, previous_extension FROM provisioner_devices WHERE needs_changes = 1 AND previous_extension IS NOT NULL AND previous_extension <> '' AND previous_extension <> extension")->fetchAll(\PDO::FETCH_ASSOC);
        }
        $byPrevious = [];
        foreach ($rows as $row) {
            if (isset($byPrevious[$row['previous_extension']])) return [];
            $byPrevious[$row['previous_extension']] = $row;
        }

        $groups = [];
        $claimed = [];
        foreach ($byPrevious as $startKey => $row) {
            $start = (string)$startKey;
            if (isset($claimed[$start])) continue;
            $path = [];
            $position = [];
            $extension = $start;
            while (isset($byPrevious[$extension]) && !isset($position[$extension])) {
                $position[$extension] = count($path);
                $path[] = $byPrevious[$extension];
                $extension = $byPrevious[$extension]['extension'];
            }
            if ($extension !== $start || count($path) < 2) continue;
            $macs = [];
            foreach ($path as $member) {
                $claimed[$member['previous_extension']] = true;
                $macs[] = strtolower($member['mac_address']);
            }
            $groups[] = $macs;
        }
        return $groups;
    }

    public function applyChanges($generate = true, $reboot = false, $finalize = true) {
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE needs_changes = 1");
        $stmt->execute();
        $pending = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        if (empty($pending)) {
            return ['success' => true, 'affected' => 0, 'message' => 'No pending changes.'];
        }

        $duplicates = $this->getDuplicateDesiredExtensions();
        if (!empty($duplicates)) {
            return [
                'success' => false,
                'error' => 'Duplicate desired extension assignment(s): ' . implode(', ', $duplicates) . '. Complete the extension swap before applying changes.'
            ];
        }

        $generated = [];
        $preservedCustom = [];
        $rebootResults = [];

        if (!$generate && $finalize) {
            foreach ($pending as $device) {
                $extensionChanged = $device['previous_extension'] !== null
                    && $device['previous_extension'] !== ''
                    && (string)$device['previous_extension'] !== (string)$device['extension'];
                if (!empty($device['custom_config']) && $extensionChanged) {
                    return ['success' => false, 'error' => 'Custom configs with extension changes must be regenerated before pending changes can be finalized.'];
                }
            }
        }

        if ($generate) {
            $result = $this->generateConfigSet($pending, 'extension_changes');
            if (!$result['success']) return $result;
            $generated = $result['generated'];
            $preservedCustom = $result['preserved_custom'];
            $this->addLog('apply', 'Generated configs for ' . count($generated) . ' devices', 'success');
        }

        $skippedReboot = 0;
        if ($reboot) {
            foreach ($pending as $device) {
                $rebootExt = $device['previous_extension'] !== null ? $device['previous_extension'] : $device['extension'];
                if ($rebootExt === null) {
                    $skippedReboot++;
                    continue;
                }
                $result = $this->rebootPhone($rebootExt);
                $rebootResults[] = [
                    'extension' => $rebootExt,
                    'success'   => $result['success']
                ];
            }
        }

        if (($generate || $reboot) && $finalize) {
            $ids = array_column($pending, 'id');
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $this->db->prepare("UPDATE provisioner_devices SET needs_changes = 0, previous_extension = NULL, previous_description = NULL WHERE id IN ($placeholders)")->execute($ids);
        }

        return [
            'success'        => true,
            'affected'       => count($pending),
            'generated'      => $generated,
            'preserved_custom' => $preservedCustom,
            'reboots'        => $rebootResults,
            'skipped_reboot' => $skippedReboot
        ];
    }

    public function addDevice($mac, $extension, $description = '', $brand = null, $ip = '', $staticIp = null, $staticMask = null, $staticGw = null) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        if ($brand === null || !in_array($brand, $this->getBrands())) {
            $detected = $this->getBrandByMac($mac);
            $brand = $detected ?: 'digium';
        }
        if (strlen($mac) !== 12) {
            return ['success' => false, 'error' => 'Invalid MAC address — must be 12 hex characters'];
        }
        if ($ip && !filter_var($ip, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid IP address'];
        }
        $ip = $ip ?: null;
        if ($staticIp && !filter_var($staticIp, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid static IP address'];
        }
        if ($staticGw && !filter_var($staticGw, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid gateway IP address'];
        }

        $prevExt  = null;
        $prevDesc = null;
        $stmt = $this->db->prepare("SELECT id, extension, description, brand, ip_address, static_ip, needs_changes, previous_extension, previous_description FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $existing = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($existing) {
            $originalExt = !empty($existing['needs_changes']) && $existing['previous_extension'] !== null
                ? $existing['previous_extension'] : $existing['extension'];
            $originalDesc = !empty($existing['needs_changes']) && $existing['previous_description'] !== null
                ? $existing['previous_description'] : $existing['description'];
            if ($extension !== $originalExt) {
                $prevExt = $originalExt;
            }
            if ($description !== $originalDesc) {
                $prevDesc = $originalDesc;
            }
        }

        $now = date('Y-m-d H:i:s');
        try {
            if ($existing) {
                $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, brand=?, ip_address=NULLIF(?, ''), static_ip=NULLIF(?, ''), static_mask=NULLIF(?, ''), static_gw=NULLIF(?, ''), needs_changes=1, previous_extension=?, previous_description=?, updated_at=? WHERE mac_address=?");
                $stmt->execute([$extension, $description, $brand, $ip, $staticIp, $staticMask, $staticGw, $prevExt, $prevDesc, $now, $mac]);
            } else {
                $stmt = $this->db->prepare("INSERT INTO provisioner_devices (mac_address, extension, description, brand, needs_changes, previous_extension, previous_description, ip_address, static_ip, static_mask, static_gw, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$mac, $extension, $description, $brand, $prevExt, $prevDesc, $ip, $staticIp, $staticMask, $staticGw, $now, $now]);
            }
            $this->addLog('device', ($existing ? 'Updated' : 'Added') . " device MAC:$mac EXT:$extension BRAND:$brand" . ($ip ? " IP:$ip" : ''), 'success');
            return ['success' => true];
        } catch (\Exception $e) {
            try {
                $this->ensureTables();
                $now = date('Y-m-d H:i:s');
                if ($existing) {
                    $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, brand=?, ip_address=NULLIF(?, ''), static_ip=NULLIF(?, ''), static_mask=NULLIF(?, ''), static_gw=NULLIF(?, ''), needs_changes=1, previous_extension=?, previous_description=?, updated_at=? WHERE mac_address=?");
                    $stmt->execute([$extension, $description, $brand, $ip, $staticIp, $staticMask, $staticGw, $prevExt, $prevDesc, $now, $mac]);
                } else {
                    $stmt = $this->db->prepare("INSERT INTO provisioner_devices (mac_address, extension, description, brand, needs_changes, previous_extension, previous_description, ip_address, static_ip, static_mask, static_gw, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$mac, $extension, $description, $brand, $prevExt, $prevDesc, $ip, $staticIp, $staticMask, $staticGw, $now, $now]);
                }
                $this->addLog('device', ($existing ? 'Updated' : 'Added') . " device MAC:$mac EXT:$extension BRAND:$brand" . ($ip ? " IP:$ip" : ''), 'success');
                return ['success' => true];
            } catch (\Exception $e2) {
                $msg = $e2->getMessage();
                $this->addLog('device', "Failed to add device MAC:$mac EXT:$extension - $msg", 'error');
                return ['success' => false, 'error' => $msg];
            }
        }
    }

    public function addDiscoveredDevices($devices) {
        $added = 0;
        $accepted = [];
        $errors = [];
        foreach ($devices as $d) {
            $mac  = is_array($d) ? ($d['mac'] ?? '') : $d;
            $ip   = is_array($d) ? ($d['ip'] ?? '') : '';
            $ext  = is_array($d) ? ($d['extension'] ?? '') : '';
            $clean = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
            if (strlen($clean) !== 12) {
                $errors[] = "$mac: invalid MAC";
                continue;
            }
            $stmt = $this->db->prepare("SELECT id, extension, ip_address FROM provisioner_devices WHERE mac_address=?");
            $stmt->execute([$clean]);
            $existing = $stmt->fetch(\PDO::FETCH_ASSOC);
            if ($existing) {
                $accepted[] = [
                    'mac' => strtoupper($clean),
                    'ip' => $ip ?: ($existing['ip_address'] ?? ''),
                    'extension' => $existing['extension'] ?? '',
                    'state' => 'existing'
                ];
                continue;
            }
            $result = $this->addDevice($mac, $ext, '', null, $ip);
            if ($result['success']) {
                $added++;
                if ($ext) {
                    $this->db->prepare("UPDATE provisioner_devices SET needs_changes=0 WHERE mac_address=?")->execute([$clean]);
                }
                $accepted[] = ['mac' => strtoupper($clean), 'ip' => $ip, 'extension' => $ext, 'state' => 'added'];
            } else {
                $errors[] = $mac . ': ' . $result['error'];
            }
        }
        $status = $errors ? 'warning' : 'success';
        $this->addLog('device', "Added $added discovered device(s) to MAC Mapping", $status);
        return [
            'success' => !empty($accepted),
            'added' => $added,
            'devices' => $accepted,
            'errors' => $errors,
            'error' => empty($accepted) && $errors ? implode('; ', $errors) : null
        ];
    }

    public function autoAddSupportedDiscoveredDevices($devices, $pjsipMatches = null) {
        if (($this->getSetting('deploy_mode') ?: 'dhcp') !== 'sip_notify') {
            return ['success' => false, 'error' => 'Auto Add Supported is available only in SIP NOTIFY mode.'];
        }
        if (!is_array($devices) || empty($devices)) {
            return ['success' => false, 'error' => 'No discovered devices supplied.'];
        }
        if (count($devices) > 1024) {
            return ['success' => false, 'error' => 'Too many discovered devices in one request.'];
        }

        $pjsipWarning = null;
        if ($pjsipMatches === null) {
            $discovery = $this->autoDiscoverFromPjsip();
            $pjsipMatches = !empty($discovery['success']) ? $discovery['matches'] : [];
            if (empty($discovery['success'])) $pjsipWarning = $discovery['error'] ?? 'PJSIP matching was unavailable.';
        }
        $extensionsByMac = [];
        foreach ((array)$pjsipMatches as $match) {
            $matchMac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', (string)($match['mac'] ?? '')));
            $extension = trim((string)($match['extension'] ?? ''));
            if (strlen($matchMac) === 12 && preg_match('/^[a-zA-Z0-9_-]+$/', $extension)) {
                $extensionsByMac[$matchMac] = $extension;
            }
        }

        $normalized = [];
        $unsupported = [];
        $errors = [];
        foreach ($devices as $device) {
            $rawMac = is_array($device) ? (string)($device['mac'] ?? '') : (string)$device;
            $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $rawMac));
            if (strlen($mac) !== 12) {
                $errors[] = ['mac' => $rawMac, 'error' => 'Invalid MAC address'];
                continue;
            }
            if (isset($normalized[$mac])) continue;
            $ip = is_array($device) ? trim((string)($device['ip'] ?? '')) : '';
            if ($ip !== '' && !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $errors[] = ['mac' => strtoupper($mac), 'error' => 'Invalid IPv4 address'];
                continue;
            }
            $recognizedBrand = $this->getBrandByMac($mac);
            $brand = $this->getSupportedDiscoveryBrand($mac);
            if (!$brand) {
                $unsupported[] = [
                    'mac' => strtoupper($mac),
                    'ip' => $ip,
                    'brand' => $recognizedBrand,
                    'reason' => $recognizedBrand ? 'Recognized brand is not provisionable' : 'Unknown device'
                ];
                continue;
            }
            $normalized[$mac] = [
                'mac' => $mac,
                'ip' => $ip,
                'brand' => $brand,
                'extension' => $extensionsByMac[$mac] ?? ''
            ];
        }

        $mappedRows = $this->db->query("SELECT mac_address, extension, ip_address FROM provisioner_devices")->fetchAll(\PDO::FETCH_ASSOC);
        $mappedByMac = [];
        $macByExtension = [];
        foreach ($mappedRows as $row) {
            $mappedMac = strtolower($row['mac_address']);
            $mappedByMac[$mappedMac] = $row;
            if ((string)$row['extension'] !== '') $macByExtension[(string)$row['extension']] = $mappedMac;
        }

        $extensionCandidates = [];
        foreach ($normalized as $mac => $device) {
            if (isset($mappedByMac[$mac]) || $device['extension'] === '') continue;
            $extensionCandidates[$device['extension']][] = $mac;
        }
        $extensionConflicts = [];
        foreach ($normalized as $mac => &$device) {
            $extension = $device['extension'];
            if ($extension === '' || isset($mappedByMac[$mac])) continue;
            $mappedConflict = isset($macByExtension[$extension]) && $macByExtension[$extension] !== $mac;
            $discoveryConflict = count($extensionCandidates[$extension] ?? []) > 1;
            if ($mappedConflict || $discoveryConflict) {
                $extensionConflicts[] = [
                    'mac' => strtoupper($mac),
                    'extension' => $extension,
                    'reason' => $mappedConflict ? 'Extension is already mapped to another MAC' : 'Extension matched multiple discovered phones'
                ];
                $device['extension'] = '';
            }
        }
        unset($device);

        $added = [];
        $refreshed = [];
        $unchanged = [];
        foreach ($normalized as $mac => $device) {
            if (isset($mappedByMac[$mac])) {
                $existing = $mappedByMac[$mac];
                if ($device['ip'] !== '' && $device['ip'] !== (string)($existing['ip_address'] ?? '')) {
                    $stmt = $this->db->prepare("UPDATE provisioner_devices SET ip_address=? WHERE mac_address=?");
                    if ($stmt && $stmt->execute([$device['ip'], $mac])) {
                        $refreshed[] = ['mac' => strtoupper($mac), 'ip' => $device['ip'], 'extension' => $existing['extension'] ?? ''];
                    } else {
                        $errors[] = ['mac' => strtoupper($mac), 'error' => 'Failed to refresh stored IP'];
                    }
                } else {
                    $unchanged[] = ['mac' => strtoupper($mac), 'ip' => $existing['ip_address'] ?? '', 'extension' => $existing['extension'] ?? ''];
                }
                continue;
            }
            $result = $this->addDevice($mac, $device['extension'], '', $device['brand'], $device['ip']);
            if (!empty($result['success'])) {
                $added[] = [
                    'mac' => strtoupper($mac), 'ip' => $device['ip'],
                    'extension' => $device['extension'], 'brand' => $device['brand']
                ];
            } else {
                $errors[] = ['mac' => strtoupper($mac), 'error' => $result['error'] ?? 'Failed to add device'];
            }
        }

        $withExtension = count(array_filter($added, function ($device) { return $device['extension'] !== ''; }));
        $status = $errors ? 'warning' : 'success';
        $this->addLog('device', 'Auto Add Supported: added ' . count($added) . ', refreshed ' . count($refreshed)
            . ', unsupported ' . count($unsupported) . ', errors ' . count($errors), $status);
        return [
            'success' => true,
            'added' => $added,
            'added_count' => count($added),
            'added_with_extension' => $withExtension,
            'added_without_extension' => count($added) - $withExtension,
            'refreshed' => $refreshed,
            'refreshed_count' => count($refreshed),
            'unchanged' => $unchanged,
            'unchanged_count' => count($unchanged),
            'unsupported' => $unsupported,
            'unsupported_count' => count($unsupported),
            'extension_conflicts' => $extensionConflicts,
            'errors' => $errors,
            'pjsip_warning' => $pjsipWarning
        ];
    }

    public function updateDevice($id, $mac, $extension, $description = '', $brand = null, $ip = '', $staticIp = null, $staticMask = null, $staticGw = null) {
        if ($brand !== null && !in_array($brand, $this->getBrands())) {
            $brand = 'digium';
        }
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        if (strlen($mac) !== 12) {
            return ['success' => false, 'error' => 'Invalid MAC address — must be 12 hex characters'];
        }
        if ($ip && !filter_var($ip, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid IP address'];
        }
        if ($staticIp && !filter_var($staticIp, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid static IP address'];
        }
        if ($staticGw && !filter_var($staticGw, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid gateway IP address'];
        }
        try {
            $stmt = $this->db->prepare("SELECT extension, description, ip_address, static_ip, needs_changes, previous_extension, previous_description FROM provisioner_devices WHERE id=?");
            $stmt->execute([$id]);
            $old = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$old) {
                return ['success' => false, 'error' => 'Device not found'];
            }

            $prevExt  = null;
            $prevDesc = null;
            $originalExt = !empty($old['needs_changes']) && $old['previous_extension'] !== null
                ? $old['previous_extension'] : $old['extension'];
            $originalDesc = !empty($old['needs_changes']) && $old['previous_description'] !== null
                ? $old['previous_description'] : $old['description'];
            if ($extension !== $originalExt) {
                $prevExt = $originalExt;
            }
            if ($description !== $originalDesc) {
                $prevDesc = $originalDesc;
            }

            $now = date('Y-m-d H:i:s');
            $sql = "UPDATE provisioner_devices SET mac_address=?, extension=?, description=?, ip_address=NULLIF(?, ''), static_ip=NULLIF(?, ''), static_mask=NULLIF(?, ''), static_gw=NULLIF(?, ''), needs_changes=1, previous_extension=?, previous_description=?, updated_at=? WHERE id=?";
            $params = [$mac, $extension, $description, $ip ?: null, $staticIp, $staticMask, $staticGw, $prevExt, $prevDesc, $now, $id];

            if ($brand !== null) {
                $sql = "UPDATE provisioner_devices SET mac_address=?, extension=?, description=?, brand=?, ip_address=NULLIF(?, ''), static_ip=NULLIF(?, ''), static_mask=NULLIF(?, ''), static_gw=NULLIF(?, ''), needs_changes=1, previous_extension=?, previous_description=?, updated_at=? WHERE id=?";
                $params = [$mac, $extension, $description, $brand, $ip ?: null, $staticIp, $staticMask, $staticGw, $prevExt, $prevDesc, $now, $id];
            }

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $this->addLog('device', "Updated device ID:$id", 'success');
            return ['success' => true];
        } catch (\Exception $e) {
            $this->addLog('device', "Failed to update device ID:$id - " . $e->getMessage(), 'error');
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function deleteDevice($id) {
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE id=?");
        $stmt->execute([$id]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        $stmt = $this->db->prepare("DELETE FROM provisioner_devices WHERE id=?");
        $stmt->execute([$id]);
        if ($row) {
            $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
            $this->cleanDeviceConfig($row['mac_address'], $provDir);
        }
        $this->addLog('device', "Deleted device ID:$id", 'warning');
        return ['success' => true];
    }

    public function deleteDevices($ids) {
        if (!is_array($ids)) $ids = [$ids];
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $macs = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        foreach ($macs as $mac) {
            $this->cleanDeviceConfig($mac, $provDir);
        }
        $stmt = $this->db->prepare("DELETE FROM provisioner_devices WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $this->addLog('device', "Deleted " . count($ids) . " device(s)", 'warning');
        return ['success' => true, 'deleted' => count($ids)];
    }

    public function bulkImport($csv) {
        $csv = str_replace(["\r\n", "\r"], "\n", $csv);
        $rows = explode("\n", trim($csv));
        $success = 0;
        $errors = [];
        foreach ($rows as $i => $line) {
            $line = trim($line);
            if (empty($line)) continue;
            if ($i === 0 && preg_match('/^(extension|mac|brand|description|static_ip)/i', $line)) continue;
            $parts = str_getcsv($line);
            if (count($parts) < 2) {
                $errors[] = "Row " . ($i + 1) . ": invalid format";
                continue;
            }
            $ext = trim($parts[0]);
            $mac = trim($parts[1]);
            $brand = isset($parts[2]) && trim($parts[2]) !== '' ? trim($parts[2]) : null;
            $desc = isset($parts[3]) ? trim($parts[3]) : '';
            $staticIp = isset($parts[4]) ? trim($parts[4]) : '';
            $staticMask = isset($parts[5]) ? trim($parts[5]) : '';
            $staticGw = isset($parts[6]) ? trim($parts[6]) : '';
            $result = $this->addDevice($mac, $ext, $desc, $brand, '', $staticIp ?: null, $staticMask ?: null, $staticGw ?: null);
            if ($result['success']) {
                $success++;
            } else {
                $errors[] = "Row " . ($i + 1) . ": " . $result['error'];
            }
        }
        $this->addLog('device', "Bulk imported $success devices", 'success');
        return ['success' => $success, 'errors' => $errors];
    }

    public function revertDevice($id) {
        $stmt = $this->db->prepare("SELECT extension, description, previous_extension, previous_description FROM provisioner_devices WHERE id=?");
        $stmt->execute([$id]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) {
            return ['success' => false, 'error' => 'Device not found'];
        }
        $newExt  = $device['previous_extension'] !== null ? $device['previous_extension'] : $device['extension'];
        $newDesc = $device['previous_description'] !== null ? $device['previous_description'] : $device['description'];
        $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, needs_changes=0, previous_extension=NULL, previous_description=NULL WHERE id=?");
        $stmt->execute([$newExt, $newDesc, $id]);
        $this->addLog('device', "Reverted device ID:$id", 'info');
        return ['success' => true];
    }

    public function discardAllChanges() {
        $stmt = $this->db->query("SELECT id, previous_extension, previous_description FROM provisioner_devices WHERE needs_changes = 1");
        $affected = 0;
        while ($device = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $newExt  = $device['previous_extension'] !== null ? $device['previous_extension'] : '';
            $newDesc = $device['previous_description'] !== null ? $device['previous_description'] : '';
            $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, needs_changes=0, previous_extension=NULL, previous_description=NULL WHERE id=?")
                ->execute([$newExt, $newDesc, $device['id']]);
            $affected++;
        }
        $this->addLog('device', "Discarded all changes for $affected device(s)", 'info');
        return ['success' => true, 'affected' => $affected];
    }

    // =====================
    // CONFIG FILES
    // =====================
    public function getConfigFiles() {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $files = [];
        if (!is_dir($provDir)) return $files;
        $dh = opendir($provDir);
        while (($file = readdir($dh)) !== false) {
            if (preg_match('/^([a-f0-9]{12})\.cfg$/i', $file, $m)) $mac = strtolower($m[1]);
            elseif (preg_match('/^config\.([a-f0-9]{12})\.xml$/i', $file, $m)) $mac = strtolower($m[1]);
            else continue;
            $path = $provDir . '/' . $file;
            $entry = [
                'mac'      => $mac,
                'file'     => $file,
                'size'     => filesize($path),
                'modified' => date('Y-m-d H:i:s', filemtime($path))
            ];
            if (!isset($files[$mac]) || filemtime($path) > strtotime($files[$mac]['modified'])) $files[$mac] = $entry;
        }
        closedir($dh);
        $files = array_values($files);
        usort($files, function ($a, $b) { return strcmp($b['modified'], $a['modified']); });
        return $files;
    }

    public function getConfigFileGrid() {
        $files = $this->getConfigFiles();
        $devices = $this->getDevices();
        $deviceMap = [];
        foreach ($devices as $d) {
            $deviceMap[$d['mac_address']] = $d;
        }
        $rows = [];
        foreach ($files as $f) {
            $device = $deviceMap[$f['mac']] ?? null;
            $ext = $device ? $device['extension'] : '-';
            $desc = $device ? $device['description'] : '-';
            $custom = $device && !empty($device['custom_config']);
            $backup = $this->getCustomBackupMetadata($f['mac']);
            $pullBtn = $custom
                ? '<a class="clickable revert-config-btn" data-mac="' . $f['mac'] . '" title="Revert to template-generated config"><i class="fa fa-undo"></i></a>'
                : '<a class="clickable fetch-config-btn" data-mac="' . $f['mac'] . '" title="Fetch current config from phone"><i class="fa fa-download"></i></a>';
            $state = $custom
                ? '<span class="badge badge-warning">Custom</span>'
                : '<span class="badge badge-primary">Template</span>';
            if ($device) {
                $configState = $this->getDeviceConfigExtensionState($device);
            } else {
                $brand = stripos($f['file'], 'config.') === 0 ? 'alcatel' : ($this->getBrandByMac($f['mac']) ?: 'digium');
                $configState = $this->getDeviceConfigExtensionState([
                    'mac_address' => $f['mac'], 'extension' => '', 'brand' => $brand,
                    'needs_changes' => 0, 'previous_extension' => null, 'custom_config' => 0
                ], ($this->getSetting('prov_dir') ?: '/var/www/html/provisioning') . '/' . $f['file']);
            }
            $state .= ' ' . $this->formatConfigSyncState($configState, true);
            $restoreBtn = '';
            if (!$custom && !empty($backup['exists'])) {
                if (!empty($backup['valid'])) {
                    $state .= ' <span class="badge badge-info">Pulled backup</span>';
                    $restoreBtn = ' <a class="clickable restore-pulled-btn" data-mac="' . $f['mac'] . '" title="Restore archived pulled config"><i class="fa fa-history"></i></a>';
                } else {
                    $state .= ' <span class="badge badge-danger">Invalid backup</span>';
                    $restoreBtn = ' <span class="text-danger" title="Archived pulled config failed validation"><i class="fa fa-exclamation-triangle"></i></span>';
                }
            }
            $rows[] = [
                'mac'         => $f['mac'],
                'assigned_extension' => $ext,
                'config_extension' => $configState['config_extension'] !== null
                    ? htmlspecialchars($configState['config_extension'], ENT_QUOTES) : '<span class="text-muted">Unknown</span>',
                'description' => $desc,
                'state'       => $state,
                'modified'    => $f['modified'],
                'actions'     => '<a class="clickable edit-config-btn" data-mac="' . $f['mac'] . '" data-ext="' . $ext . '" title="Edit"><i class="fa fa-edit"></i></a> '
                    . $pullBtn
                    . $restoreBtn
                    . ' <a class="clickable delete-config-btn" data-mac="' . $f['mac'] . '" title="Delete"><i class="fa fa-trash"></i></a>'
            ];
        }
        return $rows;
    }

    private function getDeviceBrand($mac) {
        $stmt = $this->db->prepare("SELECT brand FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $row['brand'] : 'digium';
    }

    private function isValidPhoneConfig($mac, $content, $brand = null) {
        if (empty($content) || strlen($content) < 100) {
            return false;
        }
        if (preg_match('/<html|<head|<body|<title>/i', $content)) {
            return false;
        }
        if (stripos($content, '403 Forbidden') !== false || stripos($content, 'nginx') !== false || stripos($content, 'server too busy') !== false) {
            return false;
        }
        if (stripos($content, '<title>Logon</title>') !== false) {
            return false;
        }
        $brand = $brand ?: $this->getDeviceBrand($mac);
        if ($brand === 'digium') {
            if (strpos($content, '<<VOIP CONFIG FILE>>') === false) {
                return false;
            }
            if (strpos($content, '<SIP CONFIG MODULE>') === false && strpos($content, '<GLOBAL CONFIG MODULE>') === false) {
                return false;
            }
            if (strpos($content, '<<END OF FILE>>') === false) {
                return false;
            }
        } elseif ($brand === 'alcatel') {
            if (substr(trim($content), 0, 5) !== '<?xml') {
                return false;
            }
            $oldLibXml = libxml_use_internal_errors(true);
            $xml = simplexml_load_string($content);
            libxml_use_internal_errors($oldLibXml);
            if (!$xml) {
                return false;
            }
        } elseif ($brand === 'yealink') {
            if (strpos($content, '#!version:') !== 0 || !preg_match('/^\s*[a-zA-Z0-9_.-]+\s*=\s*/m', $content)) {
                return false;
            }
        }
        return true;
    }

    private function getDeviceConfigFilename($mac, $brand = null) {
        $mac = strtolower($mac);
        $brand = $brand ?: $this->getDeviceBrand($mac);
        return $brand === 'alcatel' ? 'config.' . $mac . '.xml' : $mac . '.cfg';
    }

    private function getConfigFilePath($mac, $brand = null) {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $path = $provDir . '/' . $this->getDeviceConfigFilename($mac, $brand);
        if (file_exists($path)) {
            return $path;
        }
        $dh = @opendir($provDir);
        if (!$dh) {
            return $path;
        }
        while (($file = readdir($dh)) !== false) {
            $ext = substr($file, -4);
            $fileMac = null;
            if ($ext === '.cfg') {
                $fileMac = substr($file, 0, -4);
            } elseif (preg_match('/^config\.([a-f0-9]{12})\.xml$/i', $file, $m)) {
                $fileMac = $m[1];
            }
            if ($fileMac !== null && strtolower($fileMac) === strtolower($mac)) {
                closedir($dh);
                return $provDir . '/' . $file;
            }
        }
        closedir($dh);
        return $path;
    }

    private function getCustomBackupPath($mac) {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $filename = $this->getDeviceConfigFilename($mac) . '.custom.bak';
        $path = $provDir . '/' . $filename;
        if (file_exists($path)) return $path;
        $handle = @opendir($provDir);
        if (!$handle) return $path;
        while (($file = readdir($handle)) !== false) {
            if (strcasecmp($file, $filename) === 0) {
                closedir($handle);
                return $provDir . '/' . $file;
            }
        }
        closedir($handle);
        return $path;
    }

    private function extractConfigExtension($mac, $content, $brand = null) {
        $brand = $brand ?: $this->getDeviceBrand($mac);
        if ($brand === 'digium') {
            if (preg_match('/^SIP1 Register User\s*:\s*(.*?)\s*$/mi', $content, $match)) return trim($match[1]);
            if (preg_match('/^SIP1 Phone Number\s*:\s*(.*?)\s*$/mi', $content, $match)) return trim($match[1]);
        } elseif ($brand === 'alcatel') {
            $oldLibXml = libxml_use_internal_errors(true);
            $xml = simplexml_load_string($content);
            libxml_use_internal_errors($oldLibXml);
            if ($xml) {
                $settings = $xml->xpath("//setting[@id='SIPGroup1AuthenticationName']");
                if ($settings && isset($settings[0]['value'])) return trim((string)$settings[0]['value']);
            }
        } elseif ($brand === 'yealink') {
            if (preg_match('/^\s*account\.1\.(?:user_name|auth_name)\s*=\s*(.*?)\s*$/mi', $content, $match)) return trim($match[1]);
        }
        return null;
    }

    private function getDeviceConfigExtensionState($device, $path = null) {
        $mac = strtolower((string)($device['mac_address'] ?? ''));
        $brand = $device['brand'] ?? 'digium';
        $assigned = (string)($device['extension'] ?? '');
        $previous = (string)($device['previous_extension'] ?? '');
        $pending = !empty($device['needs_changes']);
        $custom = !empty($device['custom_config']);
        $extensionChanged = $pending && $previous !== '' && $previous !== $assigned;
        $willRegenerate = $pending && (!$custom || $extensionChanged);
        $path = $path ?: $this->getConfigFilePath($mac, $brand);

        if (!is_file($path)) {
            return [
                'status' => 'missing', 'assigned_extension' => $assigned, 'config_extension' => null,
                'push_extension' => $willRegenerate ? $assigned : null, 'will_regenerate' => $willRegenerate
            ];
        }
        $content = file_get_contents($path);
        if ($content === false || !$this->isValidPhoneConfig($mac, $content, $brand)) {
            return [
                'status' => 'invalid', 'assigned_extension' => $assigned, 'config_extension' => null,
                'push_extension' => $willRegenerate ? $assigned : null, 'will_regenerate' => $willRegenerate
            ];
        }
        $configExtension = $this->extractConfigExtension($mac, $content, $brand);
        if ($configExtension === null || $configExtension === '') {
            $status = 'unknown';
        } elseif ($willRegenerate && $configExtension !== $assigned) {
            $status = 'pending_generation';
        } elseif ($assigned === '') {
            $status = 'unmapped';
        } elseif ($configExtension === $assigned) {
            $status = 'in_sync';
        } elseif ($custom) {
            $status = 'custom_mismatch';
        } else {
            $status = 'mismatch';
        }
        return [
            'status' => $status,
            'assigned_extension' => $assigned,
            'config_extension' => $configExtension,
            'push_extension' => $willRegenerate ? $assigned : $configExtension,
            'will_regenerate' => $willRegenerate
        ];
    }

    private function formatConfigSyncState($state, $detailed) {
        $status = $state['status'];
        $assigned = htmlspecialchars((string)($state['assigned_extension'] ?? ''), ENT_QUOTES);
        $config = htmlspecialchars((string)($state['config_extension'] ?? ''), ENT_QUOTES);
        if ($status === 'in_sync') return '<span class="badge badge-success">' . ($detailed ? 'Extension match' : 'In Sync') . '</span>';
        if ($status === 'pending_generation') {
            return '<span class="badge badge-warning">Will generate ' . $assigned . ' on Push</span>';
        }
        if ($status === 'custom_mismatch') {
            return '<span class="badge badge-danger">' . ($detailed ? 'Push uses config ' . $config : 'Custom Mismatch: file uses ' . $config) . '</span>';
        }
        if ($status === 'mismatch') {
            return '<span class="badge badge-danger">' . ($detailed ? 'Push uses config ' . $config : 'Mismatch: file uses ' . $config) . '</span>';
        }
        if ($status === 'missing') return '<span class="badge badge-danger">Config Missing</span>';
        if ($status === 'invalid') return '<span class="badge badge-danger">Invalid Config</span>';
        if ($status === 'unmapped') return '<span class="badge badge-default">Unmapped</span>';
        return '<span class="badge badge-warning">Extension Unknown</span>';
    }

    private function getCustomBackupMetadata($mac) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        $path = $this->getCustomBackupPath($mac);
        $currentExtension = $this->getExtensionByMac($mac);
        if (!file_exists($path)) {
            return ['exists' => false, 'valid' => false, 'current_extension' => $currentExtension];
        }
        $content = file_get_contents($path);
        $valid = $content !== false && $this->isValidPhoneConfig($mac, $content);
        $archivedExtension = $valid ? $this->extractConfigExtension($mac, $content) : null;
        return [
            'exists' => true,
            'valid' => $valid,
            'file' => basename($path),
            'size' => filesize($path),
            'modified' => date('Y-m-d H:i:s', filemtime($path)),
            'archived_extension' => $archivedExtension,
            'current_extension' => $currentExtension,
            'extension_matches' => $archivedExtension !== null && (string)$archivedExtension === (string)$currentExtension
        ];
    }

    public function getCustomBackupInfo($mac) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        if (strlen($mac) !== 12) return ['success' => false, 'error' => 'Invalid MAC address.'];
        $metadata = $this->getCustomBackupMetadata($mac);
        if (empty($metadata['exists'])) return ['success' => false, 'error' => 'Archived pulled config not found.'];
        return array_merge(['success' => true], $metadata);
    }

    public function getConfigFileContent($mac) {
        $path = $this->getConfigFilePath($mac);
        if (!file_exists($path)) {
            return ['success' => false, 'error' => 'Config file not found'];
        }
        $ext = $this->getExtensionByMac($mac);
        return ['success' => true, 'content' => file_get_contents($path), 'extension' => $ext];
    }

    public function saveConfigFile($mac, $content) {
        $configWriteLock = $this->acquireConfigWriteLock();
        if (!$configWriteLock) return ['success' => false, 'error' => 'Another config activation is already in progress. Try again shortly.'];
        $path = $this->getConfigFilePath($mac);
        $result = file_put_contents($path, $content);
        if ($result === false) {
            $this->addLog('config', "Failed to save config for $mac", 'error');
            return ['success' => false, 'error' => 'Failed to write config file'];
        }
        $this->addLog('config', "Saved config for $mac", 'success');
        return ['success' => true];
    }

    public function deleteConfigFile($mac) {
        $configWriteLock = $this->acquireConfigWriteLock();
        if (!$configWriteLock) return ['success' => false, 'error' => 'Another config activation is already in progress. Try again shortly.'];
        $path = $this->getConfigFilePath($mac);
        if (file_exists($path)) {
            unlink($path);
        }
        $this->addLog('config', "Deleted config for $mac", 'warning');
        return ['success' => true];
    }

    public function deleteSelectedConfigFiles($macs) {
        $count = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $r = $this->deleteConfigFile($mac);
            if ($r['success']) $count++;
            else $errors[] = $mac;
        }
        $this->addLog('config', "Deleted $count config files", 'warning');
        return ['success' => true, 'deleted' => $count, 'errors' => $errors];
    }

    public function deleteAllConfigFiles() {
        $files = $this->getConfigFiles();
        $count = 0;
        foreach ($files as $f) {
            $this->deleteConfigFile($f['mac']);
            $count++;
        }
        $this->addLog('config', "Deleted all $count config files", 'warning');
        return ['success' => true, 'deleted' => $count];
    }

    private function acquirePhoneFetchLock($mac) {
        $uid = function_exists('posix_geteuid') ? posix_geteuid() : getmyuid();
        $path = sys_get_temp_dir() . '/provisioner-fetch-' . $uid . '-' . $mac . '.lock';
        $handle = @fopen($path, 'c');
        if (!$handle || !@flock($handle, LOCK_EX | LOCK_NB)) {
            if ($handle) fclose($handle);
            return null;
        }
        @chmod($path, 0600);
        return $handle;
    }

    private function acquireConfigWriteLock() {
        $uid = function_exists('posix_geteuid') ? posix_geteuid() : getmyuid();
        $path = sys_get_temp_dir() . '/provisioner-config-write-' . $uid . '.lock';
        $handle = @fopen($path, 'c');
        if (!$handle || !@flock($handle, LOCK_EX)) {
            if ($handle) fclose($handle);
            return null;
        }
        @chmod($path, 0600);
        return $handle;
    }

    private function releasePhoneFetchLock($handle) {
        if (!$handle) return;
        @flock($handle, LOCK_UN);
        @fclose($handle);
    }

    private function runFetchScript($mac, $ext, $ip) {
        $python = $this->findPython3Binary();
        if (!$python) return ['success' => false, 'error' => 'Python 3 not found (checked python3 and python3.6)'];
        $brand = $this->getDeviceBrand($mac);
        if ($brand === 'alcatel') {
            $script = 'fetch_alcatel_config.py';
            $pass = $this->getSetting('phone_admin_pass_alcatel') ?: '123456';
        } else {
            $script = 'fetch_digium_config.py';
            $pass = $this->getSetting('phone_admin_pass') ?: '789';
        }
        $cmd = escapeshellarg($python) . ' ' . escapeshellarg(__DIR__ . '/' . $script)
             . ' ' . escapeshellarg($ip)
             . ' admin'
             . ' ' . escapeshellarg($pass)
             . ' ' . escapeshellarg($mac) . ' 2>&1';
        $output = shell_exec($cmd);
        return json_decode($output, true);
    }

    private function fetchValidatedPhoneConfig($mac) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) {
            return ['success' => false, 'error' => 'Device not found in MAC Mapping'];
        }
        $ext = $device['extension'];
        $target = $this->resolveDeviceTarget($device);
        $ip = $target['selected_ip'];
        $source = $target['selected_source'] ?: 'none';
        if (!$ip) {
            return ['success' => false, 'error' => "Could not determine IP for extension $ext — phone may not be registered or on DHCP"];
        }
        $result = $this->runFetchScript($mac, $ext, $ip);
        if (!$result || !$result['success']) {
            $error = $result['error'] ?? 'Script execution failed';
            $this->addLog('config', "Fetch config failed for $mac (IP $ip): $error", 'error');
            return ['success' => false, 'error' => $error];
        }
        if (!$this->isValidPhoneConfig($mac, $result['config'])) {
            $errorMsg = 'Invalid config format — response does not match ' . $this->getDeviceBrand($mac) . ' phone config';
            $this->addLog('config', "Fetch config failed for $mac (IP $ip): $errorMsg", 'error');
            return ['success' => false, 'error' => $errorMsg];
        }
        return [
            'success' => true,
            'config' => $result['config'],
            'extension' => $ext,
            'ip' => $ip,
            'ip_source' => $source,
            'session_reused' => !empty($result['session_reused'])
        ];
    }

    private function activatePhoneConfig($mac, $content, $markPending = false) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        $stmt = $this->db->prepare("SELECT id FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        if (!$stmt->fetch(\PDO::FETCH_ASSOC)) return ['success' => false, 'error' => 'Device not found in MAC Mapping'];
        if (!$this->isValidPhoneConfig($mac, $content)) {
            return ['success' => false, 'error' => 'Invalid config format — content does not match ' . $this->getDeviceBrand($mac) . ' phone config'];
        }
        $configWriteLock = $this->acquireConfigWriteLock();
        if (!$configWriteLock) return ['success' => false, 'error' => 'Another config activation is already in progress. Try again shortly.'];

        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        if (!is_dir($provDir)) {
            if (!mkdir($provDir, 0755, true)) {
                return ['success' => false, 'error' => 'Failed to create provisioning directory'];
            }
            @chown($provDir, 'asterisk');
            @chgrp($provDir, 'asterisk');
        }
        if (!is_writable($provDir)) return ['success' => false, 'error' => 'Provisioning directory is not writable'];
        $filename = $this->getDeviceConfigFilename($mac);
        $path = $provDir . '/' . $filename;
        $bakPath = $provDir . '/' . $filename . '.bak';
        $tmpPath = tempnam($provDir, '.pull-');
        if ($tmpPath === false) return ['success' => false, 'error' => 'Failed to create temporary config file'];

        $expectedBytes = strlen($content);
        $written = file_put_contents($tmpPath, $content, LOCK_EX);
        if ($written !== $expectedBytes) {
            @unlink($tmpPath);
            return ['success' => false, 'error' => 'Failed to write complete config file'];
        }
        $verifyContent = file_get_contents($tmpPath);
        if ($verifyContent === false || !$this->isValidPhoneConfig($mac, $verifyContent)) {
            @unlink($tmpPath);
            return ['success' => false, 'error' => 'Written config failed validation'];
        }

        $hadExisting = file_exists($path);
        if ($hadExisting && !copy($path, $bakPath)) {
            @unlink($tmpPath);
            return ['success' => false, 'error' => 'Failed to back up existing config file'];
        }
        @chmod($tmpPath, 0644);
        @chown($tmpPath, 'asterisk');
        @chgrp($tmpPath, 'asterisk');
        if (!rename($tmpPath, $path)) {
            @unlink($tmpPath);
            return ['success' => false, 'error' => 'Failed to activate pulled config file'];
        }

        $sql = $markPending
            ? "UPDATE provisioner_devices SET custom_config=1, needs_changes=1 WHERE mac_address=?"
            : "UPDATE provisioner_devices SET custom_config=1 WHERE mac_address=?";
        $stmt = $this->db->prepare($sql);
        if (!$stmt || !$stmt->execute([$mac])) {
            if ($hadExisting && file_exists($bakPath)) copy($bakPath, $path);
            elseif (!$hadExisting) @unlink($path);
            return ['success' => false, 'error' => 'Config was fetched but its database state could not be saved'];
        }
        return [
            'success' => true,
            'file' => $filename,
            'bytes' => $expectedBytes,
            'modified' => date('Y-m-d H:i:s', filemtime($path))
        ];
    }

    public function pullPhoneConfig($mac) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        $lock = $this->acquirePhoneFetchLock($mac);
        if (!$lock) return ['success' => false, 'error' => 'A config fetch is already in progress for this phone.'];
        try {
            $fetched = $this->fetchValidatedPhoneConfig($mac);
            if (!$fetched['success']) return $fetched;
            $activated = $this->activatePhoneConfig($mac, $fetched['config']);
            if (!$activated['success']) return $activated;
            $session = $fetched['session_reused'] ? 'reused' : 'new';
            $this->addLog('config', "Pulled config from phone for $mac (ext {$fetched['extension']}) via {$fetched['ip']} source:{$fetched['ip_source']} session:$session", 'success');
            return array_merge($activated, [
                'message' => "Config pulled from phone ({$fetched['ip']}, {$fetched['ip_source']}). The previous config was backed up.",
                'ip' => $fetched['ip'],
                'ip_source' => $fetched['ip_source'],
                'session_reused' => $fetched['session_reused']
            ]);
        } finally {
            $this->releasePhoneFetchLock($lock);
        }
    }

    public function fetchPhoneConfig($mac) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        $lock = $this->acquirePhoneFetchLock($mac);
        if (!$lock) return ['success' => false, 'error' => 'A config fetch is already in progress for this phone.'];
        try {
            $result = $this->fetchValidatedPhoneConfig($mac);
            if ($result['success']) {
                $session = $result['session_reused'] ? 'reused' : 'new';
                $this->addLog('config', "Fetched config from phone for $mac (ext {$result['extension']}) via {$result['ip']} source:{$result['ip_source']} session:$session", 'info');
            }
            return $result;
        } finally {
            $this->releasePhoneFetchLock($lock);
        }
    }

    public function saveAsActiveConfig($mac, $content) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        $lock = $this->acquirePhoneFetchLock($mac);
        if (!$lock) return ['success' => false, 'error' => 'A config fetch or activation is already in progress for this phone.'];
        try {
            $result = $this->activatePhoneConfig($mac, $content);
            if (!$result['success']) return $result;
            $this->addLog('config', "Saved fetched config for $mac (with backup)", 'success');
            $result['message'] = 'Config saved as active config. Previous file backed up.';
            return $result;
        } finally {
            $this->releasePhoneFetchLock($lock);
        }
    }

    public function restoreCustomBackup($mac, $force = false) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        if (strlen($mac) !== 12) return ['success' => false, 'error' => 'Invalid MAC address.'];
        $lock = $this->acquirePhoneFetchLock($mac);
        if (!$lock) return ['success' => false, 'error' => 'A config fetch or activation is already in progress for this phone.'];
        try {
            $stmt = $this->db->prepare("SELECT custom_config FROM provisioner_devices WHERE mac_address=?");
            $stmt->execute([$mac]);
            $device = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$device) return ['success' => false, 'error' => 'Device not found in MAC Mapping.'];
            if (!empty($device['custom_config'])) return ['success' => false, 'error' => 'The archived pulled config is already active.'];

            $metadata = $this->getCustomBackupMetadata($mac);
            if (empty($metadata['exists'])) return ['success' => false, 'error' => 'Archived pulled config not found.'];
            if (empty($metadata['valid'])) return ['success' => false, 'error' => 'Archived pulled config failed validation.'];
            if (empty($metadata['extension_matches']) && !$force) {
                return array_merge(['success' => false, 'requires_confirmation' => true], $metadata);
            }

            $path = $this->getCustomBackupPath($mac);
            $content = file_get_contents($path);
            if ($content === false) return ['success' => false, 'error' => 'Failed to read archived pulled config.'];
            $result = $this->activatePhoneConfig($mac, $content, true);
            if (!$result['success']) return $result;
            $mismatch = empty($metadata['extension_matches']);
            $this->addLog('config', "Restored archived pulled config for $mac" . ($mismatch ? ' with forced extension mismatch' : ''), $mismatch ? 'warning' : 'success');
            return array_merge($result, [
                'message' => 'Archived pulled config restored. The generated config was backed up and the device is pending push.',
                'archived_extension' => $metadata['archived_extension'],
                'current_extension' => $metadata['current_extension'],
                'extension_matches' => $metadata['extension_matches']
            ]);
        } finally {
            $this->releasePhoneFetchLock($lock);
        }
    }

    public function revertConfigTemplate($mac) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        if (strlen($mac) !== 12) return ['success' => false, 'error' => 'Invalid MAC address.'];
        $phoneLock = $this->acquirePhoneFetchLock($mac);
        if (!$phoneLock) return ['success' => false, 'error' => 'A config fetch or activation is already in progress for this phone.'];
        try {
            $stmt = $this->db->prepare("SELECT custom_config FROM provisioner_devices WHERE mac_address=?");
            $stmt->execute([$mac]);
            $device = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$device) return ['success' => false, 'error' => 'Device not found in MAC Mapping.'];
            if (empty($device['custom_config'])) return ['success' => false, 'error' => 'This device is already using a template-generated config.'];

            $configWriteLock = $this->acquireConfigWriteLock();
            if (!$configWriteLock) return ['success' => false, 'error' => 'Another config activation is already in progress. Try again shortly.'];
            $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
            if (!is_dir($provDir) || !is_writable($provDir)) {
                return ['success' => false, 'error' => 'Provisioning directory is not writable.'];
            }
            $filename = $this->getDeviceConfigFilename($mac);
            $cfgPath = $this->getConfigFilePath($mac);
            $bakPath = $provDir . '/' . $filename . '.bak';
            if (!file_exists($bakPath)) {
                $handle = @opendir($provDir);
                if ($handle) {
                    while (($file = readdir($handle)) !== false) {
                        if (strcasecmp($file, $filename . '.bak') === 0) {
                            $bakPath = $provDir . '/' . $file;
                            break;
                        }
                    }
                    closedir($handle);
                }
            }

            $hadActive = is_file($cfgPath);
            $activeContent = $hadActive ? file_get_contents($cfgPath) : null;
            if ($hadActive && $activeContent === false) {
                return ['success' => false, 'error' => 'Failed to read the active custom config for rollback.'];
            }
            $rollbackPath = null;
            if ($hadActive) {
                $rollbackPath = tempnam($provDir, '.revert-current-');
                $written = $rollbackPath === false ? false : file_put_contents($rollbackPath, $activeContent, LOCK_EX);
                if ($written !== strlen($activeContent)) {
                    if ($rollbackPath) @unlink($rollbackPath);
                    return ['success' => false, 'error' => 'Failed to preserve the active custom config for rollback.'];
                }
                @chmod($rollbackPath, 0600);
            }

            $restored = file_exists($bakPath);
            if ($restored) {
                $backupContent = is_file($bakPath) && is_readable($bakPath) ? file_get_contents($bakPath) : false;
                if ($backupContent === false || !$this->isValidPhoneConfig($mac, $backupContent)) {
                    if ($rollbackPath) @unlink($rollbackPath);
                    return ['success' => false, 'error' => 'The previous generated config backup is unreadable or invalid.'];
                }
                $stagedPath = tempnam($provDir, '.revert-stage-');
                $written = $stagedPath === false ? false : file_put_contents($stagedPath, $backupContent, LOCK_EX);
                if ($written !== strlen($backupContent)) {
                    if ($stagedPath) @unlink($stagedPath);
                    if ($rollbackPath) @unlink($rollbackPath);
                    return ['success' => false, 'error' => 'Failed to stage the previous generated config.'];
                }
                if (!@chmod($stagedPath, 0644) || !@chown($stagedPath, 'asterisk') || !@chgrp($stagedPath, 'asterisk')) {
                    @unlink($stagedPath);
                    if ($rollbackPath) @unlink($rollbackPath);
                    return ['success' => false, 'error' => 'Failed to set ownership or permissions on the staged config.'];
                }
                if (!@rename($stagedPath, $cfgPath)) {
                    @unlink($stagedPath);
                    if ($rollbackPath) @unlink($rollbackPath);
                    return ['success' => false, 'error' => 'Failed to atomically restore the previous generated config.'];
                }
            } elseif ($hadActive && !@unlink($cfgPath)) {
                @unlink($rollbackPath);
                return ['success' => false, 'error' => 'Failed to remove the active custom config.'];
            }

            try {
                $stmt = $this->db->prepare("UPDATE provisioner_devices SET custom_config=0, needs_changes=1 WHERE mac_address=?");
                if (!$stmt || !$stmt->execute([$mac])) throw new \RuntimeException('Database update failed');
            } catch (\Throwable $e) {
                $rolledBack = true;
                if ($hadActive) {
                    @chmod($rollbackPath, 0644);
                    @chown($rollbackPath, 'asterisk');
                    @chgrp($rollbackPath, 'asterisk');
                    $rolledBack = @rename($rollbackPath, $cfgPath);
                } elseif (file_exists($cfgPath)) {
                    $rolledBack = @unlink($cfgPath);
                }
                if ($rolledBack && $rollbackPath && file_exists($rollbackPath)) @unlink($rollbackPath);
                $error = $rolledBack
                    ? 'Database state could not be updated. The active custom config was restored.'
                    : 'Database state could not be updated and automatic file rollback failed. Manual recovery is required.';
                $this->addLog('config', "Revert failed for $mac: $error", 'error');
                return ['success' => false, 'error' => $error];
            }

            if ($rollbackPath && file_exists($rollbackPath)) @unlink($rollbackPath);
            $msg = $restored
                ? 'Reverted to previous config by restoring from backup.'
                : 'Reverted to template. Config will be regenerated on next push.';
            $this->addLog('config', "Reverted $mac" . ($restored ? ' (restored from backup)' : ''), 'info');
            return ['success' => true, 'message' => $msg];
        } finally {
            $this->releasePhoneFetchLock($phoneLock);
        }
    }

    public function pullSelectedConfigFiles($macs) {
        $count = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $r = $this->pullPhoneConfig($mac);
            if ($r['success']) $count++;
            else $errors[] = ['mac' => $mac, 'error' => $r['error']];
        }
        $this->addLog('config', "Bulk pull: $count succeeded, " . count($errors) . " failed", $errors ? 'warning' : 'success');
        return ['success' => true, 'pulled' => $count, 'errors' => $errors];
    }

    public function revertSelectedConfigFiles($macs) {
        $count = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $r = $this->revertConfigTemplate($mac);
            if ($r['success']) $count++;
            else $errors[] = ['mac' => $mac, 'error' => $r['error']];
        }
        $this->addLog('config', "Bulk revert: $count succeeded, " . count($errors) . " failed", $errors ? 'warning' : 'success');
        return ['success' => true, 'reverted' => $count, 'errors' => $errors];
    }

    private function getExtensionByMac($mac) {
        $stmt = $this->db->prepare("SELECT extension FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $row['extension'] : '';
    }

    // =====================
    // PROVISIONING INFO
    // =====================
    public function getProvisioningInfo() {
        $pbxIp = $this->getSetting('pbx_ip') ?: '192.168.0.10';
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $isDir = is_dir($provDir);
        $writable = $isDir && is_writable($provDir) ? true : ($isDir ? false : 'missing');
        $deviceCount = 0;
        $modelFiles = [];
        if ($isDir) {
            $dh = opendir($provDir);
            while (($file = readdir($dh)) !== false) {
                $ext = substr($file, -4);
                $path = $provDir . '/' . $file;
                if ($ext === '.cfg') {
                    if (preg_match('/^f0A\d+hw1\.100\.cfg$/', $file)) {
                        $modelFiles[] = [
                            'name'     => $file,
                            'size'     => filesize($path),
                            'modified' => date('Y-m-d H:i:s', filemtime($path))
                        ];
                    } elseif ($file !== 'template.cfg' && preg_match('/^[a-f0-9]{12}\.cfg$/i', $file)) {
                        $deviceCount++;
                    }
                } elseif (preg_match('/^config\.[a-f0-9]{12}\.xml$/i', $file)) {
                    $deviceCount++;
                }
            }
            closedir($dh);
        }

        $modelCount = count($modelFiles);
        asort($modelFiles);

        return [
            'pbx_ip'       => $pbxIp,
            'prov_dir'     => $provDir,
            'dir_exists'   => $isDir,
            'dir_writable' => $writable,
            'device_count' => $deviceCount,
            'model_count'  => $modelCount,
            'model_files'  => array_values($modelFiles)
        ];
    }

    public function checkDhcpOption66() {
        $expected = 'http://' . ($this->getSetting('pbx_ip') ?: '192.168.0.10') . ':2001/provisioning/';
        $path = '/etc/asterisk/dnsmasq.conf';
        if (!file_exists($path) || !is_readable($path)) {
            return ['set' => false, 'correct' => false, 'value' => null, 'expected' => $expected];
        }
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (preg_match('/^dhcp-option\s*=\s*[^,]+,\s*66\s*,\s*(.*)$/i', trim($line), $m)) {
                $value = trim($m[1]);
                return ['set' => true, 'correct' => $value === $expected, 'value' => $value, 'expected' => $expected];
            }
        }
        return ['set' => false, 'correct' => false, 'value' => null, 'expected' => $expected];
    }

    public function getDhcpLeases() {
        if (($this->getSetting('deploy_mode') ?: 'dhcp') !== 'dhcp') {
            return ['success' => true, 'leases' => [], 'count' => 0, 'disabled' => true, 'message' => 'DHCP leases are disabled in SIP NOTIFY mode.'];
        }
        $path = $this->getSetting('dhcp_leases_file') ?: '/var/lib/misc/dnsmasq.leases';
        if (!is_readable($path)) {
            return ['success' => false, 'error' => "DHCP lease file not readable: $path"];
        }
        $lines = @file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines || !is_array($lines)) {
            return ['success' => false, 'error' => "Could not read DHCP lease file: $path"];
        }
        $leases = [];
        $seen = [];
        foreach ($lines as $line) {
            if (!preg_match('/^\d+\s+([a-f0-9:]{17})\s+(\d+\.\d+\.\d+\.\d+)\s/', trim($line), $m)) continue;
            $mac = str_replace(':', '', strtolower($m[1]));
            if (isset($seen[$mac])) continue;
            $seen[$mac] = true;
            $brand = $this->getBrandByMac($mac);
            $supportedBrand = $this->getSupportedDiscoveryBrand($mac);
            $inProvisioner = $this->checkProvisioner($mac);
            $leases[] = [
                'mac' => strtoupper($mac),
                'mac_formatted' => $this->formatMac($mac),
                'ip' => $m[2],
                'vendor' => $brand ? ucfirst($brand) : 'Unknown',
                'brand' => $brand,
                'model' => '-',
                'source' => 'DHCP:' . basename($path),
                'is_phone' => $brand !== null,
                'is_supported' => $supportedBrand !== null,
                'in_provisioner' => $inProvisioner,
                'status' => $inProvisioner ? 'added' : 'new',
            ];
        }
        return ['success' => true, 'leases' => $leases, 'count' => count($leases), 'file_path' => $path];
    }

    public function checkFirewallProvisioning() {
        $subnetsToCheck = [];

        $pbxIp = $this->getSetting('pbx_ip');
        if ($pbxIp) {
            $longIp = ip2long($pbxIp);
            if ($longIp !== false) {
                foreach ($this->getAllSubnets() as $cidr) {
                    $parts = explode('/', $cidr);
                    $net = $parts[0];
                    $prefix = (int)($parts[1] ?? 24);
                    $mask = -1 << (32 - $prefix);
                    if (($longIp & $mask) === (ip2long($net) & $mask)) {
                        $subnetsToCheck[] = $cidr;
                        break;
                    }
                }
            }
        }

        $trusted = [];
        $internal = [];
        exec('timeout 15s fwconsole firewall list trusted 2>/dev/null', $t, $trustedStatus);
        exec('timeout 15s fwconsole firewall list internal 2>/dev/null', $i, $internalStatus);
        if ($trustedStatus === 124 || $internalStatus === 124) {
            return ['success' => false, 'error' => 'Firewall zone check timed out.'];
        }

        foreach ($t as $l) {
            if (preg_match('/^\d+\.\d+\.\d+\.\d+\/\d+/', trim($l), $m)) {
                $trusted[] = $m[0];
            }
        }
        foreach ($i as $l) {
            if (preg_match('/^\d+\.\d+\.\d+\.\d+\/\d+/', trim($l), $m)) {
                $internal[] = $m[0];
            }
        }

        $blocked = [];
        foreach ($subnetsToCheck as $s) {
            if (in_array($s, $trusted) || in_array($s, $internal)) {
                continue;
            }
            $blocked[] = $s;
        }

        if (empty($blocked)) {
            return [
                'success' => true,
                'blocked' => false,
                'message' => 'Phone subnet(s) are registered in firewall zones and provisioning should work.'
            ];
        }

        return [
            'success' => true,
            'blocked' => true,
            'blocked_subnets' => $blocked,
            'message' => implode(', ', $blocked) . ' not found in firewall trusted or internal zones and may be blocked. '
                . '<a href="./config.php?display=firewall&tab=networks" target="_blank">Add to Firewall &rarr; Networks</a>.'
        ];
    }

    public function getNetworkSubnets() {
        $interfaces = $this->getNetworkInterfaces();
        $pbxIp = $this->getSetting('pbx_ip') ?: '';
        $selectedSubnet = null;
        foreach ($interfaces as $interface) {
            if ($interface['ip'] === $pbxIp) {
                $selectedSubnet = $interface['subnet'];
                break;
            }
        }
        return [
            'success' => true,
            'subnets' => $this->getAllSubnets(),
            'interfaces' => $interfaces,
            'selected_subnet' => $selectedSubnet
        ];
    }

    private function getNetworkInterfaces() {
        $output = shell_exec("ip -o -f inet addr show 2>/dev/null");
        $interfaces = [];
        if ($output) {
            foreach (explode("\n", trim($output)) as $line) {
                if (preg_match('/^(\d+):\s+(\S+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)\/(\d+)/', $line, $m)) {
                    $ip = $m[3]; $prefix = (int)$m[4];
                    if ($prefix < 8 || $prefix > 30) continue;
                    if (strpos($ip, '127.') === 0 || strpos($ip, '169.254.') === 0) continue;
                    $network = long2ip(ip2long($ip) & (-1 << (32 - $prefix)));
                    $subnet = "$network/$prefix";
                    $interfaces[] = [
                        'name' => $m[2],
                        'ip' => $ip,
                        'subnet' => $subnet,
                        'label' => $m[2] . ' (' . $subnet . ')',
                    ];
                }
            }
        }
        return $interfaces;
    }

    // =====================
    // LOGS
    // =====================
    public function addLog($action, $details, $status = 'info') {
        try {
            $stmt = $this->db->prepare("INSERT INTO provisioner_logs (timestamp, action, details, status) VALUES (NOW(), ?, ?, ?)");
            $stmt->execute([$action, $details, $status]);
        } catch (\Exception $e) {}
    }

    public function getLogs($limit = 100) {
        $stmt = $this->db->prepare("SELECT * FROM provisioner_logs ORDER BY id DESC LIMIT ?");
        $stmt->bindValue(1, (int)$limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getLogGrid() {
        $rows = $this->getLogs(200);
        $result = [];
        foreach ($rows as $r) {
            $statusClass = $r['status'] === 'success' ? 'text-success' : ($r['status'] === 'error' ? 'text-danger' : 'text-muted');
            $result[] = [
                'timestamp' => $r['timestamp'],
                'action'    => $r['action'],
                'details'   => $r['details'],
                'status'    => '<span class="' . $statusClass . '">' . ucfirst($r['status']) . '</span>'
            ];
        }
        return $result;
    }

    public function clearLogs() {
        $this->db->query("DELETE FROM provisioner_logs");
        $this->addLog('logs', 'Logs cleared', 'warning');
        return ['success' => true];
    }

    // =====================
    // TEMPLATE
    // =====================
    public function getTemplateContent($brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $path = __DIR__ . '/templates/' . $brand . '/default.cfg';
        if (!file_exists($path)) {
            // Fallback to digium
            $path = __DIR__ . '/templates/digium/default.cfg';
        }
        if (!file_exists($path)) {
            return ['success' => false, 'error' => 'Template file not found.'];
        }
        $raw = file_get_contents($path);
        if ($raw === false) {
            return ['success' => false, 'error' => 'Failed to read template.'];
        }
        $passKey = $this->getBrandPassKey($brand);
        $password = $passKey ? ($this->getSetting($passKey) ?: '') : '';
        return ['success' => true, 'content' => $raw, 'password' => $password];
    }

    public function saveTemplateContent($content, $brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $path = __DIR__ . '/templates/' . $brand . '/default.cfg';
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $result = file_put_contents($path, $content);
        if ($result === false) {
            return ['success' => false, 'error' => 'Failed to write template.'];
        }
        $passKey = $this->getBrandPassKey($brand);
        if ($passKey && isset($_REQUEST['password'])) {
            $this->setSetting($passKey, $_REQUEST['password']);
        }
        $this->addLog('settings', "$brand template saved", 'success');
        return ['success' => true];
    }

    private function getBrandPassKey($brand) {
        $map = [
            'digium' => 'phone_admin_pass',
            'alcatel' => 'phone_admin_pass_alcatel',
        ];
        return $map[$brand] ?? null;
    }

    public function getDefaultTemplateContent($brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $path = __DIR__ . '/templates/' . $brand . '/default.cfg.dist';
        if (!file_exists($path)) {
            $path = __DIR__ . '/templates/digium/default.cfg.dist';
        }
        if (!file_exists($path)) {
            return ['success' => false, 'error' => 'Default template not found.'];
        }
        $raw = file_get_contents($path);
        return ['success' => true, 'content' => $raw];
    }

    public function resetTemplate($brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $dist = __DIR__ . '/templates/' . $brand . '/default.cfg.dist';
        if (!file_exists($dist)) {
            $dist = __DIR__ . '/templates/digium/default.cfg.dist';
        }
        $target = __DIR__ . '/templates/' . $brand . '/default.cfg';
        if (file_exists($dist)) {
            copy($dist, $target);
            $this->addLog('settings', "$brand template reset to default", 'success');
            return ['success' => true];
        }
        return ['success' => false, 'error' => 'Default template not found.'];
    }

    // =====================
    // DISCOVERY HELPERS
    // =====================

    private function getSubnet() {
        $output = shell_exec("ip -o -f inet addr show 2>/dev/null");
        if (!$output) return '172.16.138.0/24';
        foreach (explode("\n", trim($output)) as $line) {
            if (preg_match('/inet (\d+\.\d+\.\d+\.\d+)\/(\d+)/', $line, $m)) {
                $ip = $m[1]; $prefix = (int)$m[2];
                if ($prefix < 8 || $prefix > 30) continue;
                if (strpos($ip, '127.') === 0 || strpos($ip, '169.254.') === 0) continue;
                $network = long2ip(ip2long($ip) & (-1 << (32 - $prefix)));
                return "$network/$prefix";
            }
        }
        return '172.16.138.0/24';
    }

    private function getAllSubnets() {
        $output = shell_exec("ip -o -f inet addr show 2>/dev/null");
        if (!$output) return ['172.16.138.0/24'];
        $subnets = [];
        foreach (explode("\n", trim($output)) as $line) {
            if (preg_match('/inet (\d+\.\d+\.\d+\.\d+)\/(\d+)/', $line, $m)) {
                $ip = $m[1]; $prefix = (int)$m[2];
                if ($prefix < 8 || $prefix > 30) continue;
                if (strpos($ip, '127.') === 0 || strpos($ip, '169.254.') === 0) continue;
                $network = long2ip(ip2long($ip) & (-1 << (32 - $prefix)));
                $subnets[] = "$network/$prefix";
            }
        }
        return $subnets ?: ['172.16.138.0/24'];
    }

    private function formatMac($mac) {
        $mac = preg_replace('/[^a-f0-9]/i', '', $mac);
        if (strlen($mac) !== 12) return $mac;
        return strtoupper(substr($mac, 0, 2)) . ':' . strtoupper(substr($mac, 2, 2)) . ':'
             . strtoupper(substr($mac, 4, 2)) . ':' . strtoupper(substr($mac, 6, 2)) . ':'
             . strtoupper(substr($mac, 8, 2)) . ':' . strtoupper(substr($mac, 10, 2));
    }

    private function getLocalIP() {
        try {
            $db = \FreePBX::Database();
            $stmt = $db->query("SELECT `values` FROM `endpoint_global` WHERE `key`='internal'");
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            if ($row && !empty($row['values'])) return $row['values'];
        } catch (\Exception $e) {}
        if (!empty($_SERVER['SERVER_ADDR'])) return $_SERVER['SERVER_ADDR'];
        $ip = gethostbyname(gethostname());
        return ($ip !== gethostname()) ? $ip : '192.168.1.1';
    }

    private function checkProvisioner($mac) {
        try {
            $db = \FreePBX::Database();
            $stmt = $db->prepare("SELECT id FROM provisioner_devices WHERE mac_address = ?");
            $stmt->execute([strtoupper(preg_replace('/[^a-f0-9]/', '', $mac))]);
            return (bool)$stmt->fetch(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            return false;
        }
    }

    private function resolveDeviceIpsLocal($subnets = null) {
        if ($subnets === null) $subnets = $this->getArpCapableSubnets();
        if (empty($subnets)) return [];

        $ping = trim(shell_exec('which ping 2>/dev/null'));
        if (!$ping) return [];

        foreach ($subnets as $subnet) {
            $this->pingSweepSubnet($subnet, $ping);
        }

        return $this->getCurrentArpMap();
    }

    private function pingSweepSubnet($subnet, $ping) {
        $subnet = trim($subnet);
        if (empty($subnet)) return;
        $parts = explode('/', $subnet);
        if (count($parts) !== 2) return;
        $prefix = (int)$parts[1];
        if ($prefix < 8 || $prefix > 30) return;
        $hostBits = 32 - $prefix;
        if ($hostBits > 10) return;

        shell_exec("ip neigh flush to " . escapeshellarg($subnet) . " 2>/dev/null");

        $base = ip2long($parts[0]) & (-1 << (32 - $prefix));
        $count = 1 << $hostBits;
        $hostList = [];
        for ($i = 1; $i < $count - 1; $i++) {
            $hostList[] = long2ip($base + $i);
        }

        $tmpDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $pingDir = $tmpDir . '/tmp';
        if (!is_dir($pingDir)) @mkdir($pingDir, 0755, true);
        $tmpfile = tempnam($pingDir, 'ping_');
        file_put_contents($tmpfile, implode("\n", $hostList));
        shell_exec("cat " . escapeshellarg($tmpfile) . " | xargs -P50 -n1 " . escapeshellcmd($ping) . " -c1 -W1 >/dev/null 2>&1");
        @unlink($tmpfile);
    }

    public function sendSipNotify($phoneIp, $mac, $phonePort = 5060) {
        $pbxIp = $this->getSetting('pbx_ip') ?: $this->getLocalIP();
        $python = $this->findPython3Binary();
        if (!$python) return ['success' => false, 'error' => 'Python 3 not found (checked python3 and python3.6)'];
        $script = __DIR__ . '/send_sip_notify.py';
        if (!is_readable($script)) return ['success' => false, 'error' => 'send_sip_notify.py not found'];
        $provPort = $this->getSetting('prov_port') ?: '2001';
        $macClean = strtolower($mac);
        $uri = "http://{$pbxIp}:{$provPort}/provisioning/";
        $cmd = escapeshellcmd($python) . ' ' . escapeshellarg($script)
            . ' ' . escapeshellarg($phoneIp)
            . ' ' . escapeshellarg($pbxIp)
            . ' ' . escapeshellarg($mac)
            . ' ' . escapeshellarg($uri)
            . ' ' . escapeshellarg((string)$phonePort)
            . ' 2>/dev/null';
        $output = shell_exec($cmd);
        $success = ($output !== null && trim($output) === 'OK');
        if ($mac) {
            try {
                if ($success) {
                    $this->db->prepare("UPDATE provisioner_devices SET ip_address=?, last_ack_at=NOW(), last_push_status='success', last_push_attempt_at=NOW(), needs_changes=0, previous_extension=NULL, previous_description=NULL WHERE mac_address=?")->execute([$phoneIp, $macClean]);
                } else {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW() WHERE mac_address=?")->execute([$macClean]);
                }
            } catch (\Exception $e) {}
        }
        $this->addLog('notify', ($success ? "NOTIFY success" : "NOTIFY failed") . " MAC:$macClean IP:$phoneIp — uri:$uri", $success ? 'success' : 'error');
        return ['success' => $success, 'output' => $output, 'uri' => $uri];
    }

    private function doNetworkScan($subnet) {
        $parts = explode('/', $subnet);
        $netIp = $parts[0];
        $prefix = isset($parts[1]) ? (int)$parts[1] : 24;
        $maskLong = -1 << (32 - $prefix);
        $netLong = ip2long($netIp) & $maskLong;

        $ping = trim(shell_exec('which ping 2>/dev/null'));
        if (!$ping) return ['error' => 'ping not found'];

        $this->pingSweepSubnet($subnet, $ping);

        $seen = [];
        $devices = [];
        $arpRaw = @file('/proc/net/arp');
        if ($arpRaw) {
            foreach ($arpRaw as $line) {
                if (!preg_match('/^(\d+\.\d+\.\d+\.\d+)\s+.*\s+([a-f0-9:]{17})\s/', $line, $m)) continue;
                $ip = $m[1];
                $mac = str_replace(':', '', strtolower($m[2]));
                if ($mac === '000000000000') continue;
                $ipLong = ip2long($ip);
                if ($ipLong === false || ($ipLong & $maskLong) !== $netLong) continue;
                if (isset($seen[$mac])) continue;
                $seen[$mac] = true;
                $brand = $this->getBrandByMac($mac);
                $supportedBrand = $this->getSupportedDiscoveryBrand($mac);
                $devices[] = [
                    'ip' => $ip,
                    'mac' => strtoupper($mac),
                    'mac_formatted' => $this->formatMac($mac),
                    'vendor' => $brand ? ucfirst($brand) : 'Unknown',
                    'brand' => $brand,
                    'model' => '-',
                    'source' => 'ARP:' . $subnet,
                    'is_phone' => $brand !== null,
                    'is_supported' => $supportedBrand !== null,
                    'in_provisioner' => $this->checkProvisioner($mac),
                ];
            }
        }
        return ['devices' => $devices];
    }

    public function scanNetwork($subnet = '') {
        set_time_limit(120);
        $subnet = trim($subnet);
        if (!$subnet) {
            return ['success' => false, 'error' => 'No subnet specified.'];
        }
        $result = $this->doNetworkScan($subnet);
        if (isset($result['error'])) {
            return ['success' => false, 'error' => $result['error']];
        }
        return ['success' => true, 'devices' => $result['devices'], 'count' => count($result['devices']), 'subnets' => [$subnet]];
    }

    public function autoDiscoverFromPjsip() {
        $pjsipOutput = shell_exec('asterisk -rx "pjsip show contacts" 2>/dev/null');
        if (!$pjsipOutput) {
            return ['success' => false, 'error' => 'Could not get PJSIP contacts'];
        }
        $ipToExt = [];
        foreach (explode("\n", $pjsipOutput) as $line) {
            if (preg_match('/^\s*Contact:\s+(\w+)\/sip:\1@(\d+\.\d+\.\d+\.\d+)/', $line, $m)) {
                $ipToExt[$m[2]] = $m[1];
            }
        }
        if (empty($ipToExt)) {
            return ['success' => false, 'error' => 'No PJSIP contacts found'];
        }

        $arpRaw = @file('/proc/net/arp');
        $matches = [];
        if ($arpRaw) {
            foreach ($arpRaw as $line) {
                if (!preg_match('/^(\d+\.\d+\.\d+\.\d+)\s+.*\s+([a-f0-9:]{17})\s/', $line, $m)) continue;
                $ip = $m[1];
                $ext = $ipToExt[$ip] ?? null;
                if (!$ext) continue;
                $mac = str_replace(':', '', strtolower($m[2]));
                if ($mac === '000000000000') continue;
                $brand = $this->getBrandByMac($mac);
                if (!$brand) continue;
                $supportedBrand = $this->getSupportedDiscoveryBrand($mac);
                $matches[] = [
                    'mac' => strtoupper($mac),
                    'ip' => $ip,
                    'extension' => $ext,
                    'vendor' => ucfirst($brand),
                    'brand' => $brand,
                    'is_supported' => $supportedBrand !== null,
                ];
            }
        }
        return [
            'success' => true,
            'matches' => $matches,
            'count' => count($matches),
        ];
    }

    private function pushConfigToPhonesBulk($macsWithIps, $finalize = true) {
        $pbxIp = $this->getSetting('pbx_ip') ?: $this->getLocalIP();
        $provPort = $this->getSetting('prov_port') ?: '2001';
        $python = $this->findPython3Binary();
        if (!$python) return ['success' => false, 'error' => 'Python 3 not found (checked python3 and python3.6)', 'sent' => [], 'failed' => $macsWithIps];

        $script = __DIR__ . '/send_sip_notify_bulk.py';
        if (!is_readable($script)) return ['success' => false, 'error' => 'send_sip_notify_bulk.py not found', 'sent' => [], 'failed' => $macsWithIps];

        $phones = [];
        $sources = [];
        foreach ($macsWithIps as $m) {
            $mac = strtolower($m['mac']);
            $sources[$mac] = $m['source'] ?? 'unknown';
            $uri = "http://{$pbxIp}:{$provPort}/provisioning/";
            $phones[] = [
                'phone_ip' => $m['ip'],
                'pbx_ip' => $pbxIp,
                'mac' => $mac,
                'uri' => $uri
            ];
        }

        if (empty($phones)) {
            return ['success' => true, 'sent' => [], 'failed' => []];
        }

        $tmpDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $tmpFileDir = $tmpDir . '/tmp';
        if (!is_dir($tmpFileDir)) @mkdir($tmpFileDir, 0755, true);
        $tmpFile = tempnam($tmpFileDir, 'prov_');
        file_put_contents($tmpFile, json_encode($phones));

        $cmd = escapeshellcmd($python) . ' ' . escapeshellarg($script) . ' ' . escapeshellarg($tmpFile) . ' 2>/dev/null';
        $output = shell_exec($cmd);
        @unlink($tmpFile);

        if (!$output) {
            return ['success' => false, 'error' => 'Bulk script returned no output', 'sent' => [], 'failed' => $macsWithIps];
        }

        $parsed = json_decode($output, true);
        if (!$parsed || !isset($parsed['results'])) {
            return ['success' => false, 'error' => 'Bulk script returned invalid JSON: ' . substr($output, 0, 200), 'sent' => [], 'failed' => $macsWithIps];
        }

        $sent = []; $failed = [];
        foreach ($parsed['results'] as $mac => $r) {
            $macClean = strtolower($mac);
            $source = $sources[$macClean] ?? 'unknown';
            if ($r['success']) {
                $sent[] = ['mac' => $mac, 'ip' => $r['ip'], 'source' => $source];
                try {
                    $sql = "UPDATE provisioner_devices SET ip_address=?, last_ack_at=NOW(), last_push_status='success', last_push_attempt_at=NOW()";
                    if ($finalize) $sql .= ", needs_changes=0, previous_extension=NULL, previous_description=NULL";
                    $sql .= " WHERE mac_address=?";
                    $this->db->prepare($sql)->execute([$r['ip'], $macClean]);
                } catch (\Exception $e) {}
                $this->addLog('notify', "NOTIFY success MAC:$macClean IP:{$r['ip']} source:$source — 200 OK", 'success');
            } else {
                $failed[] = ['mac' => $mac, 'ip' => $r['ip'], 'source' => $source, 'error' => 'no 200 OK'];
                try {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW(), needs_changes=1 WHERE mac_address=?")->execute([$macClean]);
                } catch (\Exception $e) {}
                $this->addLog('notify', "NOTIFY failed MAC:$macClean IP:{$r['ip']} source:$source — no 200 OK after 10 retries", 'error');
            }
        }

        return ['success' => true, 'sent' => $sent, 'failed' => $failed];
    }

    public function applyChangesWithNotify() {
        $targets = $this->resolveDeviceTargets(true);
        $result = $this->applyChanges(true, false, false);
        if (!$result['success']) return $result;

        if (empty($result['generated']) && empty($result['preserved_custom'])) {
            $result['generated'] = [];
            $result['affected'] = 0;
            $result['message'] = 'No pending changes — pushing current configs.';
        }

        $swapGroups = $this->getPendingExtensionSwapGroups();
        $swapByMac = [];
        foreach ($swapGroups as $index => $group) {
            foreach ($group as $mac) $swapByMac[$mac] = $index;
        }

        $generatedSet = array_fill_keys(array_map('strtolower', $result['generated']), true);
        $blockedGroups = [];
        foreach ($swapGroups as $index => $group) {
            foreach ($group as $mac) {
                if (empty($generatedSet[$mac]) || empty($targets[$mac]['selected_ip'])) {
                    $blockedGroups[$index] = true;
                    break;
                }
            }
        }

        $macsWithIps = [];
        $allMacs = array_values(array_unique(array_merge($result['generated'], $result['preserved_custom'] ?? [])));
        if (empty($allMacs)) {
            $stmt = $this->db->query("SELECT mac_address FROM provisioner_devices");
            $allMacs = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        }
        foreach ($allMacs as $mac) {
            $macClean = strtolower($mac);
            if (isset($swapByMac[$macClean]) && !empty($blockedGroups[$swapByMac[$macClean]])) continue;
            $target = $targets[$macClean] ?? [];
            $ip = $target['selected_ip'] ?? null;
            if (!$ip) continue;
            $macsWithIps[] = ['mac' => $mac, 'ip' => $ip, 'source' => $target['selected_source']];
        }

        $bulk = $this->pushConfigToPhonesBulk($macsWithIps, false);

        $successful = [];
        foreach ($bulk['sent'] as $sent) $successful[strtolower($sent['mac'])] = true;
        $finalize = [];
        foreach ($successful as $mac => $_) {
            if (!isset($swapByMac[$mac])) $finalize[] = $mac;
        }
        foreach ($swapGroups as $group) {
            $complete = true;
            foreach ($group as $mac) {
                if (empty($successful[$mac])) {
                    $complete = false;
                    break;
                }
            }
            if ($complete) $finalize = array_merge($finalize, $group);
        }
        if (!empty($finalize)) {
            $placeholders = implode(',', array_fill(0, count($finalize), '?'));
            $this->db->prepare("UPDATE provisioner_devices SET needs_changes=0, previous_extension=NULL, previous_description=NULL WHERE mac_address IN ($placeholders)")->execute(array_values(array_unique($finalize)));
        }

        $notifySkipped = [];
        foreach ($allMacs as $mac) {
            $macClean = strtolower($mac);
            $ip = $targets[$macClean]['selected_ip'] ?? null;
            $groupBlocked = isset($swapByMac[$macClean]) && !empty($blockedGroups[$swapByMac[$macClean]]);
            if (!$ip || $groupBlocked) {
                $notifySkipped[] = $macClean;
                try {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW(), needs_changes=1 WHERE mac_address=?")->execute([$macClean]);
                } catch (\Exception $e) {}
                if ($groupBlocked) $reason = 'extension swap group is incomplete or one member has no verified target';
                else $reason = !empty($targets[$macClean]['conflict']) ? $targets[$macClean]['conflict_message'] : 'no valid private IP candidate';
                $this->addLog('notify', "NOTIFY skipped MAC:$macClean — $reason", 'warning');
            }
        }

        $result['notify_sent'] = $bulk['sent'];
        $result['notify_failed'] = $bulk['failed'];
        $result['notify_skipped'] = $notifySkipped;
        return $result;
    }

    public function pushConfigToPhones() {
        $targets = $this->resolveDeviceTargets(true);

        $stmt = $this->db->query("SELECT mac_address, extension FROM provisioner_devices ORDER BY id");
        $devices = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $macsWithIps = [];
        foreach ($devices as $d) {
            $mac = strtolower($d['mac_address']);
            $target = $targets[$mac] ?? [];
            $ip = $target['selected_ip'] ?? null;
            if (!$ip) continue;
            $macsWithIps[] = ['mac' => $mac, 'ip' => $ip, 'source' => $target['selected_source']];
        }

        $bulk = $this->pushConfigToPhonesBulk($macsWithIps);

        $skipped = [];
        foreach ($devices as $d) {
            $mac = strtolower($d['mac_address']);
            if (empty($targets[$mac]['selected_ip'])) {
                $skipped[] = $mac;
                try {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW(), needs_changes=1 WHERE mac_address=?")->execute([$mac]);
                } catch (\Exception $e) {}
                $reason = !empty($targets[$mac]['conflict']) ? $targets[$mac]['conflict_message'] : 'no valid private IP candidate';
                $this->addLog('notify', "NOTIFY skipped MAC:$mac ext:{$d['extension']} — $reason", 'warning');
            }
        }

        $bulk['skipped'] = $skipped;
        return $bulk;
    }

    public function retryPushForPhones($macs) {
        if (!is_array($macs)) $macs = [$macs];
        $requested = array_map('strtolower', $macs);
        foreach ($this->getPendingExtensionSwapGroups() as $group) {
            if (array_intersect($requested, $group)) {
                return ['success' => false, 'error' => 'Pending extension swaps must be generated and pushed together using Apply Pending.', 'sent' => [], 'failed' => []];
            }
        }
        $targets = $this->resolveDeviceTargets(true);
        $macsWithIps = [];
        foreach ($macs as $mac) {
            $m = strtolower($mac);
            $target = $targets[$m] ?? [];
            $ip = $target['selected_ip'] ?? null;
            if ($ip) {
                $macsWithIps[] = ['mac' => $m, 'ip' => $ip, 'source' => $target['selected_source']];
            }
        }
        $result = $this->pushConfigToPhonesBulk($macsWithIps);
        foreach ($macs as $mac) {
            $m = strtolower($mac);
            if (empty($targets[$m]['selected_ip'])) {
                $result['failed'][] = ['mac' => $m, 'error' => !empty($targets[$m]['conflict']) ? $targets[$m]['conflict_message'] : 'IP not found'];
            }
        }
        $result['generated'] = $macs;
        return $result;
    }

    public function pushToPhones($macs = []) {
        if (!is_array($macs)) $macs = [$macs];
        $macs = array_map('strtolower', $macs);
        $macs = array_filter($macs);

        if (empty($macs)) {
            return $this->pushConfigToPhones();
        }

        foreach ($this->getPendingExtensionSwapGroups() as $group) {
            if (array_intersect($macs, $group)) {
                return ['success' => false, 'error' => 'Pending extension swaps must be generated and pushed together using Apply Pending.', 'sent' => [], 'failed' => []];
            }
        }

        $targets = $this->resolveDeviceTargets(true);
        $macsWithIps = [];
        foreach ($macs as $m) {
            $target = $targets[$m] ?? [];
            $ip = $target['selected_ip'] ?? null;
            if ($ip) {
                $macsWithIps[] = ['mac' => $m, 'ip' => $ip, 'source' => $target['selected_source']];
            }
        }

        $result = $this->pushConfigToPhonesBulk($macsWithIps);

        $notFound = [];
        foreach ($macs as $m) {
            if (empty($targets[$m]['selected_ip'])) {
                $reason = !empty($targets[$m]['conflict']) ? $targets[$m]['conflict_message'] : 'IP not found';
                $notFound[] = ['mac' => $m, 'error' => $reason];
                try {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW(), needs_changes=1 WHERE mac_address=?")->execute([$m]);
                } catch (\Exception $e) {}
                $this->addLog('notify', "NOTIFY skipped MAC:$m — $reason", 'warning');
            }
        }

        $result['failed'] = array_merge($result['failed'], $notFound);
        return $result;
    }

    public function addDiscoveredDeviceWithNotify($mac, $extension, $description = '', $ip = '') {
        $brand = $this->getBrandByMac(strtolower(preg_replace('/[^a-f0-9]/i', '', $mac)));
        $result = $this->addDevice($mac, $extension, $description, $brand, $ip);
        $notifyResult = null;
        if ($result['success']) {
            $this->applyChanges(true, false);
            if ($ip) {
                $notifyResult = $this->sendSipNotify($ip, $mac);
            }
        }
        $result['notify'] = $notifyResult;
        return $result;
    }

    // =====================
    // AJAX
    // =====================
    public function ajaxRequest($req, &$setting) {
        $allowed = [
            'getPhoneStatus', 'getPhoneStatusGrid', 'rebootPhone', 'rebootPhones', 'generateProvisioning',
            'getDevices', 'getDeviceGrid', 'getDeviceDiagnostics', 'addDevice', 'updateDevice', 'deleteDevice', 'deleteDevices',
            'bulkImport', 'getLogs', 'getLogGrid', 'clearLogs',
            'getSettings', 'saveSettings', 'getSipTransportInfo',
            'getPendingCount', 'applyChanges',
            'revertDevice', 'discardAllChanges',
            'getProvisioningInfo', 'generateAllConfigs', 'getConfigFiles', 'getConfigFileGrid', 'getConfigFileContent', 'saveConfigFile', 'deleteConfigFile', 'deleteSelectedConfigFiles', 'deleteAllConfigFiles',
            'getTemplateContent', 'saveTemplateContent',
            'getDefaultTemplateContent', 'resetTemplate',
            'addDiscoveredDevice', 'addDiscoveredDevices', 'autoAddSupportedDiscoveredDevices',
            'getBrands',
            'getExtensions', 'autoAssignExtensions', 'exportCsv', 'checkDhcpOption66', 'getDhcpLeases', 'checkFirewallProvisioning', 'getNetworkSubnets',
            'pullPhoneConfig', 'revertConfigTemplate', 'getCustomBackupInfo', 'restoreCustomBackup',
            'pullSelectedConfigFiles', 'revertSelectedConfigFiles',
            'fetchPhoneConfig', 'saveAsActiveConfig',
            'scanNetwork', 'autoDiscoverFromPjsip',
            'applyChangesWithNotify', 'pushConfigToPhones',
            'retryPushForPhones', 'pushToPhones'
        ];
        return in_array($req, $allowed);
    }

    public function ajaxHandler() {
        $command = $_REQUEST['command'];
        switch ($command) {
            case 'getPhoneStatus':
                return $this->getPhoneStatus();

            case 'getPhoneStatusGrid':
                return $this->getPhoneStatusGrid();

            case 'rebootPhone':
                return $this->rebootPhone($_REQUEST['extension']);

            case 'rebootPhones':
                return $this->rebootPhones($_REQUEST['extensions']);

            case 'getProvisioningInfo':
                return $this->getProvisioningInfo();

            case 'checkDhcpOption66':
                return $this->checkDhcpOption66();

            case 'getDhcpLeases':
                return $this->getDhcpLeases();

            case 'checkFirewallProvisioning':
                return $this->checkFirewallProvisioning();

            case 'getNetworkSubnets':
                return $this->getNetworkSubnets();

            case 'generateProvisioning':
                return $this->generateProvisioning();

            case 'generateAllConfigs':
                $replaceCustom = isset($_REQUEST['replace_custom']) && in_array($_REQUEST['replace_custom'], [true, 'true', '1', 1], true);
                return $this->generateAllConfigs($replaceCustom);

            case 'getDevices':
                return $this->getDevices();

            case 'getDeviceGrid':
                return $this->getDeviceGrid();

            case 'getDeviceDiagnostics':
                $active = isset($_REQUEST['active']) && in_array($_REQUEST['active'], [true, 1, '1', 'true'], true);
                return $this->getDeviceDiagnostics($_REQUEST['mac'] ?? '', $active);

            case 'deleteDevices':
                return $this->deleteDevices($_REQUEST['ids']);

            case 'addDevice':
                return $this->addDevice(
                    $_REQUEST['mac'],
                    $_REQUEST['extension'],
                    $_REQUEST['description'] ?? '',
                    $_REQUEST['brand'] ?? null,
                    $_REQUEST['ip'] ?? '',
                    $_REQUEST['static_ip'] ?? null,
                    $_REQUEST['static_mask'] ?? null,
                    $_REQUEST['static_gw'] ?? null
                );

            case 'updateDevice':
                return $this->updateDevice(
                    $_REQUEST['id'],
                    $_REQUEST['mac'],
                    $_REQUEST['extension'],
                    $_REQUEST['description'] ?? '',
                    $_REQUEST['brand'] ?? null,
                    $_REQUEST['ip'] ?? '',
                    $_REQUEST['static_ip'] ?? null,
                    $_REQUEST['static_mask'] ?? null,
                    $_REQUEST['static_gw'] ?? null
                );

            case 'deleteDevice':
                return $this->deleteDevice($_REQUEST['id']);

            case 'bulkImport':
                return $this->bulkImport($_REQUEST['csv_content']);

            case 'getLogs':
                return $this->getLogs(isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100);

            case 'getLogGrid':
                return $this->getLogGrid();

            case 'clearLogs':
                return $this->clearLogs();

            case 'getSettings':
                return $this->getSettings();

            case 'saveSettings':
                return $this->saveSettings($_REQUEST);

            case 'getSipTransportInfo':
                return $this->getSipTransportInfo();

            case 'getPendingCount':
                return $this->getPendingCount();

            case 'applyChanges':
                $generate = isset($_REQUEST['generate']) && ($_REQUEST['generate'] === true || $_REQUEST['generate'] === 'true' || $_REQUEST['generate'] === '1');
                $reboot   = isset($_REQUEST['reboot']) && ($_REQUEST['reboot'] === true || $_REQUEST['reboot'] === 'true' || $_REQUEST['reboot'] === '1');
                return $this->applyChanges($generate, $reboot);

            case 'revertDevice':
                return $this->revertDevice($_REQUEST['id']);

            case 'discardAllChanges':
                return $this->discardAllChanges();

            case 'getConfigFiles':
                return $this->getConfigFiles();

            case 'getConfigFileGrid':
                return $this->getConfigFileGrid();

            case 'getConfigFileContent':
                return $this->getConfigFileContent($_REQUEST['mac']);

            case 'getCustomBackupInfo':
                return $this->getCustomBackupInfo($_REQUEST['mac']);

            case 'restoreCustomBackup':
                $force = isset($_REQUEST['force']) && in_array($_REQUEST['force'], [true, 'true', '1', 1], true);
                return $this->restoreCustomBackup($_REQUEST['mac'], $force);

            case 'saveConfigFile':
                return $this->saveConfigFile($_REQUEST['mac'], $_REQUEST['content']);

            case 'deleteConfigFile':
                return $this->deleteConfigFile($_REQUEST['mac']);

            case 'deleteSelectedConfigFiles':
                return $this->deleteSelectedConfigFiles($_REQUEST['macs']);

            case 'deleteAllConfigFiles':
                return $this->deleteAllConfigFiles();

            case 'getTemplateContent':
                return $this->getTemplateContent($_REQUEST['brand'] ?? 'digium');

            case 'saveTemplateContent':
                return $this->saveTemplateContent($_REQUEST['content'], $_REQUEST['brand'] ?? 'digium');

            case 'getDefaultTemplateContent':
                return $this->getDefaultTemplateContent($_REQUEST['brand'] ?? 'digium');

            case 'resetTemplate':
                return $this->resetTemplate($_REQUEST['brand'] ?? 'digium');

            case 'getBrands':
                return $this->getBrands();

            case 'getExtensions':
                return $this->getExtensions();

            case 'autoAssignExtensions':
                return $this->autoAssignExtensions();

            case 'exportCsv':
                return $this->exportCsv();

            case 'addDiscoveredDevice':
                $mac = $_REQUEST['mac'] ?? '';
                $ext = $_REQUEST['extension'] ?? '';
                $desc = $_REQUEST['description'] ?? '';
                $ip = $_REQUEST['ip'] ?? '';
                if ($ext) {
                    return $this->addDiscoveredDeviceWithNotify($mac, $ext, $desc, $ip);
                }
                return $this->addDevice($mac, '', '', null, $ip);

            case 'addDiscoveredDevices':
                return $this->addDiscoveredDevices($_REQUEST['devices'] ?? []);

            case 'autoAddSupportedDiscoveredDevices':
                return $this->autoAddSupportedDiscoveredDevices($_REQUEST['devices'] ?? []);

            case 'pullPhoneConfig':
                return $this->pullPhoneConfig($_REQUEST['mac']);

            case 'revertConfigTemplate':
                return $this->revertConfigTemplate($_REQUEST['mac']);

            case 'pullSelectedConfigFiles':
                return $this->pullSelectedConfigFiles($_REQUEST['macs']);

            case 'revertSelectedConfigFiles':
                return $this->revertSelectedConfigFiles($_REQUEST['macs']);

            case 'fetchPhoneConfig':
                return $this->fetchPhoneConfig($_REQUEST['mac']);

            case 'saveAsActiveConfig':
                return $this->saveAsActiveConfig($_REQUEST['mac'], $_REQUEST['content']);

            case 'scanNetwork':
                $subnet = $_REQUEST['subnet'] ?? '';
                return $this->scanNetwork($subnet);

            case 'autoDiscoverFromPjsip':
                return $this->autoDiscoverFromPjsip();

            case 'applyChangesWithNotify':
                return $this->applyChangesWithNotify();

            case 'pushConfigToPhones':
                return $this->pushConfigToPhones();

            case 'retryPushForPhones':
                return $this->retryPushForPhones($_REQUEST['macs'] ?? []);

            case 'pushToPhones':
                $macs = $_REQUEST['macs'] ?? [];
                if (is_string($macs)) $macs = [$macs];
                return $this->pushToPhones($macs);

            default:
                return false;
        }
    }

    // =====================
    // PAGE
    // =====================
    public function showPage() {
        $vars = ['brands' => $this->getBrands()];
        return load_view(__DIR__ . '/views/main.php', $vars);
    }

    public function getActionBar($request) {
        return [];
    }

    public function getRightNav($request) {
        return '';
    }

    private function ensureTables() {
        $this->db->query("CREATE TABLE IF NOT EXISTS provisioner_devices (id INT AUTO_INCREMENT PRIMARY KEY, mac_address VARCHAR(12) NOT NULL UNIQUE, extension VARCHAR(20) NOT NULL, description VARCHAR(255) DEFAULT '', brand VARCHAR(50) DEFAULT 'digium', created_at DATETIME DEFAULT NULL, updated_at DATETIME DEFAULT NULL, needs_changes TINYINT(1) NOT NULL DEFAULT 1, previous_extension VARCHAR(20) DEFAULT NULL, previous_description VARCHAR(255) DEFAULT NULL, ip_address VARCHAR(45) DEFAULT NULL, last_ack_at DATETIME DEFAULT NULL, last_push_status VARCHAR(20) DEFAULT NULL, last_push_attempt_at DATETIME DEFAULT NULL, static_ip VARCHAR(45) DEFAULT NULL, static_mask VARCHAR(15) DEFAULT NULL, static_gw VARCHAR(45) DEFAULT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8");
        $this->db->query("CREATE TABLE IF NOT EXISTS provisioner_logs (id INT AUTO_INCREMENT PRIMARY KEY, timestamp DATETIME NOT NULL, action VARCHAR(255) NOT NULL, details TEXT, status VARCHAR(50)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
        $this->db->query("CREATE TABLE IF NOT EXISTS provisioner_settings (key_name VARCHAR(100) NOT NULL PRIMARY KEY, value TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    }
}

<?php

namespace FreePBX\modules;

class Provisioner implements \BMO {
    private $db;
    private $sipTransportCache;

    private static $ouiMap = [
        '0004f3' => 'digium',
        '000fd3' => 'digium',
        '00809f' => 'alcatel',
        '08005a' => 'alcatel',
        '001c0e' => 'alcatel',
        '00236a' => 'alcatel',
        '3c28a6' => 'alcatel',
        '00037f' => 'yealink',
        '001565' => 'yealink',
        '346671' => 'yealink',
        '5c116f' => 'yealink',
        '805ec0' => 'yealink',
        'c098e5' => 'yealink',
        'f40e22' => 'yealink',
        'fc0fe6' => 'yealink',
        '000c41' => 'polycom',
        '00904f' => 'polycom',
        '000e53' => 'snom',
        '000413' => 'cisco',
        '001681' => 'grandstream',
    ];

    public function getBrandByMac($mac) {
        $prefix = substr(strtolower(preg_replace('/[^a-f0-9]/i', '', $mac)), 0, 6);
        return self::$ouiMap[$prefix] ?? null;
    }

    public function getBrands() {
        $dirs = glob(__DIR__ . '/templates/*', GLOB_ONLYDIR);
        $brands = [];
        foreach ($dirs as $dir) {
            $name = basename($dir);
            if (file_exists("$dir/default.cfg")) $brands[] = $name;
        }
        sort($brands);
        return $brands;
    }

    public function getExtensions() {
        if (!class_exists('FreePBX') || !\FreePBX::Core()) return [];
        $users = \FreePBX::Core()->listUsers();
        $exts = [];
        foreach ($users as $u) {
            $exts[] = ['extension' => $u[0], 'name' => $u[1]];
        }
        return $exts;
    }

    public function autoAssignExtensions() {
        $stmt = $this->db->query("SELECT id, mac_address, extension FROM provisioner_devices ORDER BY mac_address ASC");
        $devices = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $assigned = array_column($devices, 'extension');
        $assigned = array_filter($assigned, fn($v) => $v !== '');

        if (!class_exists('FreePBX') || !\FreePBX::Core()) {
            return ['success' => false, 'error' => 'Cannot access FreePBX extensions'];
        }
        $users = \FreePBX::Core()->listUsers();
        $allExts = array_map(fn($u) => $u[0], $users);
        sort($allExts, SORT_NUMERIC);
        $freeExts = array_values(array_diff($allExts, $assigned));

        $assignments = [];
        foreach ($devices as $d) {
            if (empty($d['extension'])) {
                $ext = array_shift($freeExts);
                if ($ext === null) break;
                $assignments[] = ['id' => $d['id'], 'mac' => $d['mac_address'], 'extension' => $ext];
            }
        }

        if (!empty($_REQUEST['save'])) {
            $now = date('Y-m-d H:i:s');
            foreach ($assignments as $a) {
                $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, needs_changes=1, updated_at=? WHERE id=?");
                $stmt->execute([$a['extension'], $now, $a['id']]);
            }
            $this->addLog('device', "Auto-assigned " . count($assignments) . " extension(s)", 'success');
            $deployMode = $this->getSetting('deploy_mode') ?: 'dhcp';
            return ['success' => true, 'assignments' => $assignments, 'deploy_mode' => $deployMode];
        }

        return ['success' => true, 'assignments' => $assignments];
    }

    public function exportCsv() {
        $rows = $this->db->query("SELECT extension, mac_address, brand, description, static_ip, static_mask, static_gw FROM provisioner_devices ORDER BY extension ASC");
        $csv = "Extension,MAC,Brand,Description,Static IP,Subnet Mask,Gateway\n";
        while ($row = $rows->fetch(\PDO::FETCH_ASSOC)) {
            $csv .= '"' . $row['extension'] . '","' . $row['mac_address'] . '","' . ($row['brand'] ?: 'digium') . '","' . str_replace('"', '""', $row['description'] ?? '') . '","' . ($row['static_ip'] ?? '') . '","' . ($row['static_mask'] ?? '') . '","' . ($row['static_gw'] ?? '') . '"' . "\n";
        }
        return ['success' => true, 'csv' => $csv];
    }

    public function __construct($freepbx = null) {
        if ($freepbx) {
            $this->db = $freepbx->Database();
        }
    }

    public function install() {}
    public function uninstall() {}
    public function backup() {}
    public function restore($backup) {}
    public function doConfigPageInit($page) {}

    public function getSetting($key) {
        $stmt = $this->db->prepare("SELECT value FROM provisioner_settings WHERE key_name=?");
        $stmt->execute([$key]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $row['value'] : null;
    }

    public function setSetting($key, $value) {
        $stmt = $this->db->prepare("INSERT INTO provisioner_settings (key_name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value=?");
        $stmt->execute([$key, $value, $value]);
    }

    public function getSettings() {
        $stmt = $this->db->query("SELECT key_name, value FROM provisioner_settings");
        $settings = [];
        while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $settings[$row['key_name']] = $row['value'];
        }
        return $settings;
    }

    public function saveSettings($data) {
        $keys = ['pbx_ip', 'sip_port', 'transport', 'prov_dir', 'scan_subnets', 'phone_admin_pass', 'phone_admin_pass_alcatel', 'deploy_mode', 'vlan_id', 'vlan_data_id', 'dhcp_leases_file'];
        foreach ($keys as $key) {
            if (isset($data[$key])) {
                $this->setSetting($key, $data[$key]);
            }
        }
        $this->addLog('settings', 'Settings updated', 'success');
        return ['success' => true];
    }

    public function getSipTransportInfo() {
        if ($this->sipTransportCache !== null) return $this->sipTransportCache;
        $output = shell_exec('asterisk -rx "pjsip show transports" 2>/dev/null');
        $all = [];
        if ($output) {
            foreach (explode("\n", $output) as $line) {
                if (!preg_match('/^\s*Transport:\s+(\S+)\s+(udp|tcp|tls)\s+\S+\s+\S+\s+(\S+)\s*$/i', $line, $m)) continue;
                $bind = $m[3];
                if (!preg_match('/^(?:\[([^\]]+)\]|(.+)):(\d+)$/', $bind, $address)) continue;
                $protocol = strtoupper($m[2]);
                $all[$protocol][] = [
                    'id' => $m[1],
                    'protocol' => $protocol,
                    'bind_address' => $address[1] !== '' ? $address[1] : $address[2],
                    'port' => (int)$address[3]
                ];
            }
        }

        $pbxIp = $this->getSetting('pbx_ip') ?: '';
        $selected = [];
        foreach ($all as $protocol => $transports) {
            usort($transports, function ($a, $b) use ($pbxIp) {
                $rank = function ($transport) use ($pbxIp) {
                    if ($transport['bind_address'] === '0.0.0.0' || $transport['bind_address'] === '::') return 0;
                    if ($pbxIp && $transport['bind_address'] === $pbxIp) return 1;
                    return 2;
                };
                return $rank($a) <=> $rank($b);
            });
            $selected[$protocol] = $transports[0];
            $all[$protocol] = $transports;
        }

        $this->sipTransportCache = [
            'success' => !empty($selected),
            'source' => !empty($selected) ? 'Asterisk runtime' : 'Provisioner fallback',
            'transports' => $selected,
            'all' => $all,
            'fallback_port' => (int)($this->getSetting('sip_port') ?: 5060)
        ];
        return $this->sipTransportCache;
    }

    private function getDetectedSipPort($transport) {
        $protocol = strtoupper((string)$transport);
        $info = $this->getSipTransportInfo();
        if (!empty($info['transports'][$protocol]['port'])) return (string)$info['transports'][$protocol]['port'];
        return (string)($this->getSetting('sip_port') ?: '5060');
    }

    // =====================
    // PHONE STATUS
    // =====================
    private function isPhoneReachable($ip) {
        $arp = @file_get_contents('/proc/net/arp');
        if (!$arp) return false;
        foreach (explode("\n", $arp) as $line) {
            $parts = preg_split('/\s+/', trim($line));
            if (isset($parts[0]) && $parts[0] === $ip && isset($parts[3]) && $parts[3] === '0x2') {
                return true;
            }
        }
        return false;
    }

    private function isPrivateIp($ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return false;
        $parts = explode('.', $ip);
        $first = (int)$parts[0];
        $second = (int)$parts[1];
        if ($first === 10) return true;
        if ($first === 192 && $second === 168) return true;
        if ($first === 172 && $second >= 16 && $second <= 31) return true;
        if ($ip === '127.0.0.1') return true;
        return false;
    }

    private function getPjsipContacts($output = null) {
        if ($output === null) {
            $output = shell_exec('asterisk -rx "pjsip show contacts" 2>/dev/null');
        }
        $contacts = [];
        if (!$output) return $contacts;
        foreach (explode("\n", $output) as $line) {
            if (!preg_match('/^\s*Contact:\s+([^\/\s]+)\/sip:[^@\s]+@(\d+\.\d+\.\d+\.\d+)/i', $line, $m)) continue;
            $status = preg_match('/\b(Avail|Unavail)\b/i', $line, $state) ? ucfirst(strtolower($state[1])) : 'Unknown';
            $contacts[$m[1]] = [
                'ip' => $m[2],
                'status' => $status
            ];
        }
        return $contacts;
    }

    private function getCurrentArpMap() {
        $result = [];
        $arp = @file('/proc/net/arp');
        if (!$arp) return $result;
        foreach ($arp as $line) {
            $parts = preg_split('/\s+/', trim($line));
            if (count($parts) < 4 || $parts[2] !== '0x2') continue;
            $mac = strtolower(str_replace(':', '', $parts[3]));
            if (strlen($mac) === 12) $result[$mac] = $parts[0];
        }
        return $result;
    }

    private function getDhcpLeaseMap() {
        $result = [];
        if (($this->getSetting('deploy_mode') ?: 'dhcp') !== 'dhcp') return $result;
        $path = $this->getSetting('dhcp_leases_file') ?: '/var/lib/misc/dnsmasq.leases';
        $lines = @file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines) return $result;
        foreach ($lines as $line) {
            $parts = preg_split('/\s+/', trim($line));
            if (count($parts) < 3) continue;
            $mac = strtolower(preg_replace('/[^a-f0-9]/i', '', $parts[1]));
            if (strlen($mac) === 12 && filter_var($parts[2], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $result[$mac] = $parts[2];
            }
        }
        return $result;
    }

    private function resolveDeviceTarget($device, $contacts = null, $arpMap = null, $dhcpMap = null, $arpFresh = false, $localSubnets = null) {
        $contacts = is_array($contacts) ? $contacts : $this->getPjsipContacts();
        $arpMap = is_array($arpMap) ? $arpMap : $this->getCurrentArpMap();
        $dhcpMap = is_array($dhcpMap) ? $dhcpMap : $this->getDhcpLeaseMap();
        $localSubnets = is_array($localSubnets) ? $localSubnets : $this->getArpCapableSubnets();
        $mac = strtolower(preg_replace('/[^a-f0-9]/i', '', $device['mac_address'] ?? ''));
        $extensions = array_values(array_unique(array_filter([
            (string)($device['extension'] ?? ''),
            (string)($device['previous_extension'] ?? '')
        ], 'strlen')));
        $pjsipCandidate = null;
        foreach ($extensions as $extension) {
            if (!empty($contacts[$extension]['ip'])) {
                $pjsipCandidate = [
                    'source' => 'pjsip',
                    'label' => 'PJSIP contact (' . $extension . ')',
                    'ip' => $contacts[$extension]['ip'],
                    'status' => $contacts[$extension]['status'] ?? 'Unknown',
                    'stale' => false
                ];
                break;
            }
        }
        $arpCandidate = !empty($arpMap[$mac]) ? [
            'source' => 'arp',
            'label' => $arpFresh ? 'Fresh ARP (active sweep)' : 'ARP cache',
            'ip' => $arpMap[$mac],
            'stale' => !$arpFresh
        ] : null;
        $conflict = $arpFresh && $arpCandidate && $pjsipCandidate && $arpCandidate['ip'] !== $pjsipCandidate['ip'];

        $raw = [];
        if ($arpFresh && $arpCandidate) $raw[] = $arpCandidate;
        if ($pjsipCandidate) $raw[] = $pjsipCandidate;
        if (!empty($device['static_ip'])) $raw[] = ['source' => 'static_ip', 'label' => 'Static IP', 'ip' => $device['static_ip'], 'stale' => false];
        if (!empty($dhcpMap[$mac])) {
            $dhcpLocal = $this->ipInSubnets($dhcpMap[$mac], $localSubnets);
            $raw[] = [
                'source' => 'dhcp',
                'label' => 'DHCP lease',
                'ip' => $dhcpMap[$mac],
                'stale' => false,
                'eligible' => $dhcpLocal,
                'ignored_reason' => $dhcpLocal ? null : 'Lease is not on a directly connected subnet'
            ];
        }
        if (!$arpFresh && $arpCandidate) $raw[] = $arpCandidate;
        if (!empty($device['ip_address'])) $raw[] = ['source' => 'stored', 'label' => 'Stored last-known IP', 'ip' => $device['ip_address'], 'stale' => true];

        $candidates = [];
        $selectedIp = null;
        $selectedSource = null;
        foreach ($raw as $candidate) {
            $candidate['valid'] = $this->isPrivateIp($candidate['ip']);
            if (!isset($candidate['eligible'])) $candidate['eligible'] = true;
            $candidate['selected'] = false;
            if (!$conflict && $selectedIp === null && $candidate['valid'] && $candidate['eligible']) {
                $selectedIp = $candidate['ip'];
                $selectedSource = $candidate['source'];
                $candidate['selected'] = true;
            }
            $candidates[] = $candidate;
        }

        $confidence = 'unresolved';
        if ($conflict) {
            $confidence = 'conflict';
        } elseif ($selectedSource === 'arp' && $pjsipCandidate && $selectedIp === $pjsipCandidate['ip']) {
            $selectedSource = 'arp_pjsip';
            $confidence = 'verified';
            foreach ($candidates as &$candidate) {
                if ($candidate['ip'] === $selectedIp && in_array($candidate['source'], ['arp', 'pjsip'], true)) $candidate['selected'] = true;
            }
            unset($candidate);
        } elseif ($selectedSource === 'arp') {
            $confidence = $arpFresh ? 'mac_verified' : 'arp_cached';
        } elseif ($selectedSource === 'pjsip') {
            $confidence = 'cross_subnet';
        } elseif (in_array($selectedSource, ['static_ip', 'dhcp'], true)) {
            $confidence = 'configured';
        } elseif ($selectedSource === 'stored') {
            $confidence = 'stale';
        }

        return [
            'selected_ip' => $selectedIp,
            'selected_source' => $selectedSource,
            'is_stale_fallback' => $selectedSource === 'stored',
            'confidence' => $confidence,
            'conflict' => $conflict,
            'conflict_message' => $conflict ? 'Fresh ARP maps the configured MAC to ' . $arpCandidate['ip'] . ' but PJSIP maps extension ' . ($extensions[0] ?? '') . ' to ' . $pjsipCandidate['ip'] . '.' : null,
            'candidates' => $candidates,
            'pjsip_status' => $this->getDevicePjsipStatus($extensions, $contacts)
        ];
    }

    private function getDevicePjsipStatus($extensions, $contacts) {
        foreach ($extensions as $extension) {
            if (isset($contacts[$extension])) return $contacts[$extension]['status'] ?? 'Unknown';
        }
        return 'Not registered';
    }

    private function getArpCapableSubnets() {
        $links = shell_exec('ip -o link show 2>/dev/null');
        $addresses = shell_exec('ip -o -f inet addr show up 2>/dev/null');
        if (!$links || !$addresses) return [];
        $interfaces = [];
        foreach (explode("\n", trim($links)) as $line) {
            if (!preg_match('/^\d+:\s+([^:]+):\s+<([^>]+)>.*\bstate\s+(\w+)/', $line, $m)) continue;
            $flags = explode(',', $m[2]);
            if ($m[3] === 'UP' && in_array('BROADCAST', $flags, true) && in_array('UP', $flags, true) && in_array('LOWER_UP', $flags, true) && !in_array('NOARP', $flags, true)) {
                $interfaces[explode('@', $m[1], 2)[0]] = true;
            }
        }
        $subnets = [];
        foreach (explode("\n", trim($addresses)) as $line) {
            if (!preg_match('/^\d+:\s+(\S+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)\/(\d+)/', $line, $m)) continue;
            $interface = explode('@', $m[1], 2)[0];
            if (empty($interfaces[$interface])) continue;
            $prefix = (int)$m[3];
            if ($prefix < 8 || $prefix > 30) continue;
            $network = long2ip(ip2long($m[2]) & (-1 << (32 - $prefix)));
            $subnets[] = $network . '/' . $prefix;
        }
        return array_values(array_unique($subnets));
    }

    private function ipInSubnet($ip, $subnet) {
        if (!$this->isPrivateIp($ip) || strpos($subnet, '/') === false) return false;
        [$network, $prefix] = explode('/', $subnet, 2);
        $prefix = (int)$prefix;
        if (!filter_var($network, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) || $prefix < 0 || $prefix > 32) return false;
        $mask = $prefix === 0 ? 0 : (-1 << (32 - $prefix));
        return (ip2long($ip) & $mask) === (ip2long($network) & $mask);
    }

    private function ipInSubnets($ip, $subnets) {
        foreach ($subnets as $subnet) {
            if ($this->ipInSubnet($ip, $subnet)) return true;
        }
        return false;
    }

    private function annotateResolutionMode($target, $localSubnets) {
        if (!empty($target['conflict'])) $target['resolution_mode'] = 'conflict';
        elseif ($target['confidence'] === 'verified') $target['resolution_mode'] = 'local_verified';
        elseif ($target['confidence'] === 'mac_verified') $target['resolution_mode'] = 'local_mac_verified';
        elseif ($target['selected_source'] === 'pjsip') $target['resolution_mode'] = $this->ipInSubnets($target['selected_ip'], $localSubnets) ? 'local_unverified' : 'cross_subnet';
        elseif (in_array($target['selected_source'], ['static_ip', 'dhcp'], true)) $target['resolution_mode'] = $this->ipInSubnets($target['selected_ip'], $localSubnets) ? 'local_configured' : 'cross_subnet_configured';
        elseif ($target['selected_source'] === 'stored') $target['resolution_mode'] = 'stale';
        else $target['resolution_mode'] = 'unresolved';
        return $target;
    }

    private function resolveDeviceTargets($performScan = false, $onlyMac = null) {
        if ($onlyMac) {
            $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE mac_address=?");
            $stmt->execute([strtolower($onlyMac)]);
            $devices = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } else {
            $devices = $this->db->query("SELECT * FROM provisioner_devices")->fetchAll(\PDO::FETCH_ASSOC);
        }
        $contacts = $this->getPjsipContacts();
        $arpMap = $this->getCurrentArpMap();
        $dhcpMap = $this->getDhcpLeaseMap();
        $localSubnets = $this->getArpCapableSubnets();
        $targets = [];
        foreach ($devices as $device) {
            $mac = strtolower($device['mac_address']);
            $targets[$mac] = $this->annotateResolutionMode($this->resolveDeviceTarget($device, $contacts, $arpMap, $dhcpMap, false, $localSubnets), $localSubnets);
        }
        if ($performScan) {
            $scanSubnets = [];
            $hasCandidate = false;
            $scanAllLocal = false;
            foreach ($targets as $target) {
                if (empty($target['selected_ip']) || $target['selected_source'] === 'stored') $scanAllLocal = true;
                foreach ($target['candidates'] as $candidate) {
                    if (empty($candidate['valid'])) continue;
                    $hasCandidate = true;
                    foreach ($localSubnets as $subnet) {
                        if ($this->ipInSubnet($candidate['ip'], $subnet)) $scanSubnets[] = $subnet;
                    }
                }
            }
            if (!$hasCandidate || $scanAllLocal) $scanSubnets = $localSubnets;
            $scanSubnets = array_values(array_unique($scanSubnets));
            $arpMap = $scanSubnets ? $this->resolveDeviceIpsLocal($scanSubnets) : [];
            foreach ($devices as $device) {
                $mac = strtolower($device['mac_address']);
                $targets[$mac] = $this->annotateResolutionMode($this->resolveDeviceTarget($device, $contacts, $arpMap, $dhcpMap, true, $localSubnets), $localSubnets);
                $targets[$mac]['scan_performed'] = !empty($scanSubnets);
                $targets[$mac]['scan_subnets'] = $scanSubnets;
            }
        } else {
            foreach ($targets as &$target) {
                $target['scan_performed'] = false;
                $target['scan_subnets'] = [];
            }
            unset($target);
        }
        return $targets;
    }

    private function testTcpPort($ip, $port, $timeout = 1) {
        if (!$ip) return false;
        $socket = @fsockopen($ip, $port, $errno, $error, $timeout);
        if (!$socket) return false;
        fclose($socket);
        return true;
    }

    public function getDeviceDiagnostics($mac, $active = false) {
        $mac = strtolower(preg_replace('/[^a-f0-9]/i', '', $mac));
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) return ['success' => false, 'error' => 'Device not found'];

        $targets = $this->resolveDeviceTargets((bool)$active, $mac);
        $target = $targets[$mac] ?? $this->resolveDeviceTarget($device);
        $brand = $device['brand'] ?: 'digium';
        $port = $brand === 'alcatel' ? 443 : 80;
        $path = $this->getConfigFilePath($mac);
        $configExists = file_exists($path);
        $pbxIp = $this->getSetting('pbx_ip') ?: $this->getLocalIP();
        $provPort = $this->getSetting('prov_port') ?: '2001';

        return [
            'success' => true,
            'device' => [
                'mac' => $mac,
                'extension' => $device['extension'],
                'previous_extension' => $device['previous_extension'],
                'brand' => $brand,
                'description' => $device['description'],
                'static_ip' => $device['static_ip'],
                'stored_ip' => $device['ip_address']
            ],
            'target' => $target,
            'service' => [
                'port' => $port,
                'reachable' => $this->testTcpPort($target['selected_ip'], $port),
                'fetch_supported' => in_array($brand, ['digium', 'alcatel'], true)
            ],
            'config' => [
                'filename' => $this->getDeviceConfigFilename($mac),
                'path' => $path,
                'exists' => $configExists,
                'size' => $configExists ? filesize($path) : 0,
                'modified' => $configExists ? date('Y-m-d H:i:s', filemtime($path)) : null,
                'valid' => $configExists ? $this->isValidPhoneConfig($mac, file_get_contents($path)) : null,
                'custom' => !empty($device['custom_config'])
            ],
            'provisioning_url' => "http://{$pbxIp}:{$provPort}/provisioning/",
            'last_push' => [
                'status' => $device['last_push_status'],
                'attempt' => $device['last_push_attempt_at'],
                'ack' => $device['last_ack_at']
            ]
        ];
    }

    public function getPhoneStatus() {
        $devices = $this->getDevices();
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $contacts = $this->getPjsipContacts();
        $arpMap = $this->getCurrentArpMap();
        $dhcpMap = $this->getDhcpLeaseMap();
        $localSubnets = $this->getArpCapableSubnets();
        $results = [];

        foreach ($devices as $device) {
            $needsChanges = !empty($device['needs_changes']);

            $ext  = $device['extension'];
            $desc = $device['description'];
            $mac  = $device['mac_address'];

            if ($needsChanges) {
                $ext  = $device['previous_extension'] !== null ? $device['previous_extension'] : $ext;
                $desc = $device['previous_description'] !== null ? $device['previous_description'] : $desc;
            }

            $configExists = file_exists($provDir . '/' . $mac . '.cfg') || file_exists($provDir . '/config.' . $mac . '.xml');

            $targetDevice = $device;
            $targetDevice['extension'] = $ext;
            $target = $this->resolveDeviceTarget($targetDevice, $contacts, $arpMap, $dhcpMap, false, $localSubnets);
            $status = $target['pjsip_status'] === 'Not registered' ? 'Unavailable' : $target['pjsip_status'];
            $ip = $target['selected_ip'] ?: '';

            $results[] = [
                'extension'     => $ext,
                'mac'           => $mac,
                'description'   => $desc,
                'brand'         => $device['brand'] ?? 'digium',
                'ip'            => $ip,
                'status'        => $status,
                'needs_changes' => $needsChanges,
                'config_exists' => $configExists,
                'last_ack_at'   => $device['last_ack_at'] ?? null,
                'last_push_status' => $device['last_push_status'] ?? null,
                'ip_source'     => $target['selected_source'],
                'stale_ip'      => $target['is_stale_fallback']
            ];
        }

        return $results;
    }

    public function getPhoneStatusGrid() {
        $raw = $this->getPhoneStatus();
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $rows = [];
        foreach ($raw as $r) {
            $configExists = file_exists($provDir . '/' . $r['mac'] . '.cfg') || file_exists($provDir . '/config.' . $r['mac'] . '.xml');
            $isRegistered = $r['status'] === 'Avail' || $r['status'] === 'Unavail';
            $isAvail = $r['status'] === 'Avail';
            if ($r['needs_changes'] && $configExists) {
                $actions = '<a class="clickable reboot-btn" data-ext="' . $r['extension'] . '" title="Reboot"><i class="fa fa-power-off"></i></a>';
                $statusLabel = 'Apply Pending';
            } elseif ($r['needs_changes']) {
                $actions = '<span class="text-muted"><i class="fa fa-clock-o"></i> Push first</span>';
                $statusLabel = 'Config Pending';
            } elseif ($isAvail) {
                $actions = '<a class="clickable reboot-btn" data-ext="' . $r['extension'] . '" title="Reboot"><i class="fa fa-power-off"></i></a>';
                $statusLabel = 'Registered';
            } elseif (!$r['config_exists']) {
                $actions = '<span class="text-muted"><i class="fa fa-file-text-o"></i> Push config</span>';
                $statusLabel = 'No Config';
            } elseif ($isRegistered) {
                $actions = '<span class="text-muted"><i class="fa fa-power-off"></i></span>';
                $statusLabel = (!empty($r['ip']) && $this->isPhoneReachable($r['ip'])) ? 'Unreachable' : 'Offline';
            } elseif (!empty($r['ip'])) {
                $actions = '<a class="clickable reboot-btn" data-ext="' . $r['extension'] . '" title="Reboot"><i class="fa fa-power-off"></i></a>';
                $statusLabel = $this->isPhoneReachable($r['ip']) ? 'Online' : 'Offline';
            } else {
                $actions = '<span class="text-muted"><i class="fa fa-power-off"></i></span>';
                $statusLabel = 'Offline';
            }
            $actions .= ' <a class="clickable diagnostics-btn" data-mac="' . $r['mac'] . '" title="Device diagnostics"><i class="fa fa-stethoscope"></i></a>';
            $lastAck = $r['last_ack_at'] ?? null;
            if ($lastAck) {
                $ts = strtotime($lastAck);
                $ago = time() - $ts;
                if ($ago < 60) $ackLabel = 'Just now';
                elseif ($ago < 3600) $ackLabel = floor($ago / 60) . 'm ago';
                elseif ($ago < 86400) $ackLabel = floor($ago / 3600) . 'h ago';
                else $ackLabel = date('M j', $ts);
            } else {
                $ackLabel = 'Never';
            }

            $pushStatus = $r['last_push_status'] ?? null;
            if ($pushStatus === 'success') {
                $pushLabel = '<span class="text-success">OK</span>';
            } elseif ($pushStatus === 'failed') {
                $pushLabel = '<span class="text-danger">Failed</span> <a class="clickable retry-push-btn" data-mac="' . $r['mac'] . '" title="Retry push"><i class="fa fa-repeat"></i></a>';
            } else {
                $pushLabel = '<span class="text-muted">—</span>';
            }

            $rows[] = [
                'extension'   => $r['extension'],
                'mac'         => $r['mac'],
                'description' => $r['description'],
                'brand'       => ucfirst($r['brand']),
                'ip'          => $r['ip'],
                'status'      => $statusLabel,
                'push_status' => $pushLabel,
                'last_ack'    => $ackLabel,
                'actions'     => $actions
            ];
        }
        return $rows;
    }

    // =====================
    // REBOOT PHONE
    // =====================
    private function getBrandByExtension($extension) {
        $stmt = $this->db->prepare("SELECT brand FROM provisioner_devices WHERE extension=? OR previous_extension=?");
        $stmt->execute([$extension, $extension]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? ($row['brand'] ?? 'digium') : 'digium';
    }

    public function rebootPhone($extension) {
        $ext = preg_replace('/[^a-zA-Z0-9_-]/', '', $extension);
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE extension=? OR previous_extension=?");
        $stmt->execute([$ext, $ext]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        $target = $device ? $this->resolveDeviceTarget($device) : ['selected_ip' => null, 'selected_source' => null];
        $ip = $target['selected_ip'];
        $source = $target['selected_source'] ?: 'endpoint';
        if ($ip) {
            $output = shell_exec("asterisk -rx \"pjsip send notify sync-reboot-sangoma uri sip:$ip\" 2>/dev/null");
        } else {
            $output = shell_exec("asterisk -rx \"pjsip send notify sync-reboot-sangoma endpoint $ext\" 2>/dev/null");
        }
        $success = strpos($output, 'Sending NOTIFY') !== false;
        if ($success) {
            $this->db->prepare("UPDATE provisioner_devices SET needs_changes = 0, previous_extension = NULL, previous_description = NULL WHERE previous_extension = ? OR extension = ?")
                ->execute([$extension, $extension]);
        }
        $this->addLog('reboot', "Reboot sent to extension $extension" . ($ip ? " (IP:$ip source:$source)" : " (endpoint fallback)"), $success ? 'success' : 'error');
        return ['success' => $success, 'output' => $output, 'ip' => $ip, 'ip_source' => $source];
    }

    public function rebootPhones($extensions) {
        $results = [];
        foreach ($extensions as $ext) {
            $results[] = $this->rebootPhone($ext);
        }
        return ['success' => true, 'results' => $results];
    }

    // =====================
    // GENERATE PROVISIONING
    // =====================
    private function cleanDeviceConfig($mac, $provDir) {
        foreach ([$mac . '.cfg', 'config.' . $mac . '.xml'] as $file) {
            $path = $provDir . '/' . $file;
            if (file_exists($path)) unlink($path);
        }
    }

    private function generateDeviceConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $this->cleanDeviceConfig($device['mac_address'], $provDir);
        $brand = $device['brand'] ?? 'digium';
        $method = 'generate' . ucfirst($brand) . 'Config';
        if (method_exists($this, $method)) {
            return $this->$method($device, $template, $pbxIp, $sipPort, $transportVal, $provDir);
        }
        return null;
    }

    private function generateDigiumConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $ext = $device['extension'];
        $mac = $device['mac_address'];

        $stmt = $this->db->prepare("SELECT data FROM sip WHERE id = ? AND keyword = 'secret'");
        $stmt->execute([$ext]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            $stmt = $this->db->prepare("SELECT data FROM pjsip WHERE id = ? AND keyword = 'password'");
            $stmt->execute([$ext]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        }

        if (!$row) return null;

        $secret = $row['data'];
        $tcpUdp = $transportVal === '0' ? '0' : '1';

        $wanMode = empty($device['static_ip']) ? 'DHCP' : 'STATIC';
        $dhcpEnabled = empty($device['static_ip']) ? '1' : '0';
        $staticIp = $device['static_ip'] ?? null ?: '0.0.0.0';
        $staticMask = $device['static_mask'] ?? null ?: '0.0.0.0';
        $staticGw = $device['static_gw'] ?? null ?: '0.0.0.0';
        $staticDns = empty($device['static_ip']) ? '8.8.8.8' : ($device['static_gw'] ?: '8.8.8.8');
        $ntpServer = $pbxIp;
        $provPort = $this->getSetting('prov_port') ?: '2001';
        $provUrl = "http://{$pbxIp}:{$provPort}/provisioning/";
        $vlanId = $this->getSetting('vlan_id') ?: '';
        $vlanDataId = $this->getSetting('vlan_data_id') ?: '';
        $vlanEnabled = $vlanId ? '1' : '0';

        $config = str_replace(
            ['{{MAC}}', '{{EXTENSION}}', '{{PBX_IP}}', '{{SIP_PORT}}', '{{SECRET}}', '{{TCP_UDP}}',
             '{{WAN_MODE}}', '{{STATIC_IP}}', '{{STATIC_MASK}}', '{{STATIC_GW}}', '{{STATIC_DNS}}', '{{DHCP_ENABLED}}',
             '{{NTP_SERVER}}', '{{PROV_URL}}', '{{VLAN_ENABLED}}', '{{VLAN_ID}}', '{{DATA_VLAN_ID}}'],
            [$mac, $ext, $pbxIp, $sipPort, $secret, $tcpUdp,
             $wanMode, $staticIp, $staticMask, $staticGw, $staticDns, $dhcpEnabled,
             $ntpServer, $provUrl, $vlanEnabled, $vlanId, $vlanDataId],
            $template
        );

        file_put_contents($provDir . '/' . $mac . '.cfg', $config);
        return true;
    }

    private function generateAlcatelConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $ext = $device['extension'];
        $mac = $device['mac_address'];

        $stmt = $this->db->prepare("SELECT data FROM sip WHERE id = ? AND keyword = 'secret'");
        $stmt->execute([$ext]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            $stmt = $this->db->prepare("SELECT data FROM pjsip WHERE id = ? AND keyword = 'password'");
            $stmt->execute([$ext]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        }

        if (!$row) return null;

        $secret = $row['data'];
        $dhcpEnabled = empty($device['static_ip']) ? 'Dynamic' : 'Static';
        $staticIp = $device['static_ip'] ?? '';
        $staticMask = $device['static_mask'] ?? '';
        $staticGw = $device['static_gw'] ?? '';
        $staticDns = $staticIp ? ($staticGw ?: '8.8.8.8') : '';
        $adminPass = $this->getSetting('phone_admin_pass_alcatel') ?: '123456';
        $vlanId = $this->getSetting('vlan_id') ?: '';
        $vlanDataId = $this->getSetting('vlan_data_id') ?: '';
        $vlanEnabled = $vlanId ? 'true' : 'false';
        $dataVlanEnabled = $vlanDataId ? 'true' : 'false';
        $ntpServer = $pbxIp;

        $config = str_replace(
            ['{{MAC}}', '{{EXTENSION}}', '{{PBX_IP}}', '{{SIP_PORT}}', '{{USERNAME}}', '{{PASSWORD}}', '{{TRANSPORT}}',
             '{{DHCP_ENABLED}}', '{{STATIC_IP}}', '{{STATIC_MASK}}', '{{STATIC_GW}}', '{{STATIC_DNS}}',
             '{{ADMIN_PASS}}', '{{VLAN_ENABLED}}', '{{VLAN_ID}}', '{{DATA_VLAN_ENABLED}}', '{{DATA_VLAN_ID}}',
             '{{NTP_SERVER}}'],
            [$mac, $ext, $pbxIp, $sipPort, $ext, $secret, $transportVal === '0' ? '0' : '1',
             $dhcpEnabled, $staticIp, $staticMask, $staticGw, $staticDns,
             $adminPass, $vlanEnabled, $vlanId, $dataVlanEnabled, $vlanDataId,
             $ntpServer],
            $template
        );

        $file = 'config.' . $mac . '.xml';
        file_put_contents($provDir . '/' . $file, $config);
        return true;
    }

    private function generateYealinkConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $ext = $device['extension'];
        $mac = $device['mac_address'];

        $stmt = $this->db->prepare("SELECT data FROM sip WHERE id = ? AND keyword = 'secret'");
        $stmt->execute([$ext]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            $stmt = $this->db->prepare("SELECT data FROM pjsip WHERE id = ? AND keyword = 'password'");
            $stmt->execute([$ext]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        }

        if (!$row) return null;

        $secret = $row['data'];
        $displayName = $device['description'] ?: $ext;
        $wanType = empty($device['static_ip']) ? '0' : '2';
        $staticIp = $device['static_ip'] ?? '';
        $staticMask = $device['static_mask'] ?? '';
        $staticGw = $device['static_gw'] ?? '';
        $staticDns = $staticIp ? ($staticGw ?: '8.8.8.8') : '';
        $dnsEnable = $staticIp ? '1' : '0';
        $ntpServer = $this->getSetting('ntp_server') ?: $pbxIp;
        $vlanId = $this->getSetting('vlan_id') ?: '';
        $vlanDataId = $this->getSetting('vlan_data_id') ?: '';
        $vlanEnable = $vlanId ? '1' : '0';
        $dataVlanEnable = $vlanDataId ? '1' : '0';

        $config = str_replace(
            ['{ext}', '{display_name}', '{secret}', '{server_addr}', '{server_port}', '{transport}',
             '{wan_type}', '{static_ip}', '{static_mask}', '{static_gw}', '{static_dns}', '{dns_enable}',
             '{ntp_server}', '{vlan_enable}', '{vlan_id}', '{data_vlan_enable}', '{data_vlan_id}'],
            [$ext, $displayName, $secret, $pbxIp, $sipPort, $transportVal,
             $wanType, $staticIp, $staticMask, $staticGw, $staticDns, $dnsEnable,
             $ntpServer, $vlanEnable, $vlanId, $dataVlanEnable, $vlanDataId],
            $template
        );

        file_put_contents($provDir . '/' . $mac . '.cfg', $config);
        return true;
    }

    public function generateProvisioning() {
        $dir = '/var/www/html/provisioning';
        $output = shell_exec("chown -R asterisk:asterisk $dir 2>&1");
        return ['success' => true, 'output' => $output];
    }

    public function generateAllConfigs() {
        $pbxIp   = $this->getSetting('pbx_ip') ?: '192.168.0.10';
        $transport = $this->getSetting('transport') ?: 'UDP';
        $sipPort = $this->getDetectedSipPort($transport);
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';

        $transportMap = ['UDP' => '0', 'TCP' => '1', 'TLS' => '2', 'TCP/UDP' => '0'];
        $transportVal = isset($transportMap[$transport]) ? $transportMap[$transport] : '0';

        $devices = $this->getDevices();
        if (empty($devices)) {
            return ['success' => true, 'generated' => 0, 'message' => 'No devices in MAC Mapping.'];
        }

        if (!is_dir($provDir)) {
            mkdir($provDir, 0755, true);
            @chown($provDir, 'asterisk');
            @chgrp($provDir, 'asterisk');
        }

        $templates = [];
        $generated = [];
        foreach ($devices as $device) {
            if (!empty($device['custom_config'])) continue;
            $brand = $device['brand'] ?? 'digium';
            if (!isset($templates[$brand])) {
                $templateFile = __DIR__ . '/templates/' . $brand . '/default.cfg';
                $templates[$brand] = file_exists($templateFile) ? file_get_contents($templateFile) : null;
            }
            $template = $templates[$brand];
            if ($template) {
                $result = $this->generateDeviceConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir);
                if ($result) {
                    $generated[] = $device['mac_address'];
                }
            }
        }

        $this->addLog('apply', 'Generated configs for ' . count($generated) . ' devices (all)', 'success');
        return ['success' => true, 'generated' => count($generated)];
    }

    // =====================
    // MAC MAPPING / DEVICES
    // =====================
    public function getDevices() {
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices ORDER BY extension ASC");
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getDeviceGrid() {
        $devices = $this->getDevices();
        $rows = [];
        foreach ($devices as $d) {
            $isPending = !empty($d['needs_changes']);
            $actions = '';
            $brandBadge = $this->brandBadge($d['brand'] ?? 'digium');
            $staticIp = $d['static_ip'] ?? '';
            $staticLabel = $staticIp ? $staticIp : '';
            $actions .= '<a class="clickable edit-device-btn" data-id="' . $d['id'] . '" data-mac="' . $d['mac_address'] . '" data-ext="' . $d['extension'] . '" data-desc="' . htmlspecialchars($d['description'] ?? '', ENT_QUOTES) . '" data-brand="' . ($d['brand'] ?? 'digium') . '" data-static-ip="' . htmlspecialchars($staticIp, ENT_QUOTES) . '" data-static-mask="' . htmlspecialchars($d['static_mask'] ?? '', ENT_QUOTES) . '" data-static-gw="' . htmlspecialchars($d['static_gw'] ?? '', ENT_QUOTES) . '" title="Edit"><i class="fa fa-edit"></i></a> ';
            $actions .= '<a class="clickable diagnostics-btn" data-mac="' . $d['mac_address'] . '" title="Device diagnostics"><i class="fa fa-stethoscope"></i></a> ';
            if ($isPending) {
                $actions .= '<a class="clickable revert-device-btn" data-id="' . $d['id'] . '" title="Revert"><i class="fa fa-undo"></i></a> ';
            }
            $actions .= '<a class="clickable delete-device-btn" data-id="' . $d['id'] . '" data-ext="' . $d['extension'] . '" title="Delete"><i class="fa fa-trash"></i></a>';
            $rows[] = [
                'id'          => $d['id'],
                'extension'   => $d['extension'],
                'mac_address' => $d['mac_address'],
                'brand'       => $brandBadge,
                'description' => $d['description'] ?? '',
                'static_ip'   => $staticLabel,
                'is_pending'  => $isPending,
                'actions'     => $actions
            ];
        }
        return $rows;
    }

    private function brandBadge($brand) {
        $colors = ['digium' => 'primary', 'alcatel' => 'info', 'yealink' => 'success', 'polycom' => 'warning'];
        $color = $colors[$brand] ?? 'default';
        return '<span class="badge badge-' . $color . '">' . htmlspecialchars(ucfirst($brand)) . '</span>';
    }

    public function getPendingCount() {
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE needs_changes = 1");
        $stmt->execute();
        $macs = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        $count = count($macs);
        $deployMode = $this->getSetting('deploy_mode') ?: 'dhcp';
        if ($count === 0) {
            return ['count' => 0, 'needs_reboot' => false, 'deploy_mode' => $deployMode];
        }
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $allHaveConfig = true;
        foreach ($macs as $mac) {
            if (!file_exists($provDir . '/' . $mac . '.cfg') && !file_exists($provDir . '/config.' . $mac . '.xml')) {
                $allHaveConfig = false;
                break;
            }
        }
        return ['count' => $count, 'needs_reboot' => $allHaveConfig, 'deploy_mode' => $deployMode];
    }

    public function applyChanges($generate = true, $reboot = false) {
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE needs_changes = 1");
        $stmt->execute();
        $pending = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        if (empty($pending)) {
            return ['success' => true, 'affected' => 0, 'message' => 'No pending changes.'];
        }

        $generated = [];
        $rebootResults = [];

        if ($generate) {
            $pbxIp      = $this->getSetting('pbx_ip') ?: '192.168.0.10';
            $transport  = $this->getSetting('transport') ?: 'UDP';
            $sipPort    = $this->getDetectedSipPort($transport);
            $provDir    = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';

            $transportMap = ['UDP' => '0', 'TCP' => '1', 'TLS' => '2', 'TCP/UDP' => '0'];
            $transportVal = isset($transportMap[$transport]) ? $transportMap[$transport] : '0';

            $brands = [];
            foreach ($pending as $device) {
                if (!empty($device['custom_config'])) continue;
                $brand = $device['brand'] ?? 'digium';
                if (!isset($brands[$brand])) {
                    $templateFile = __DIR__ . '/templates/' . $brand . '/default.cfg';
                    $brands[$brand] = file_exists($templateFile) ? file_get_contents($templateFile) : null;
                }
            }

            if (!is_dir($provDir)) {
                mkdir($provDir, 0755, true);
                @chown($provDir, 'asterisk');
                @chgrp($provDir, 'asterisk');
            }

            foreach ($pending as $device) {
                if (!empty($device['custom_config'])) continue;
                $brand = $device['brand'] ?? 'digium';
                $template = $brands[$brand] ?? null;
                if ($template) {
                    $result = $this->generateDeviceConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir);
                    if ($result) {
                        $generated[] = $device['mac_address'];
                    }
                }
            }

            $this->addLog('apply', 'Generated configs for ' . count($generated) . ' devices', 'success');
        }

        $skippedReboot = 0;
        if ($reboot) {
            foreach ($pending as $device) {
                $rebootExt = $device['previous_extension'] !== null ? $device['previous_extension'] : $device['extension'];
                if ($rebootExt === null) {
                    $skippedReboot++;
                    continue;
                }
                $result = $this->rebootPhone($rebootExt);
                $rebootResults[] = [
                    'extension' => $rebootExt,
                    'success'   => $result['success']
                ];
            }
        }

        if ($generate || $reboot) {
            $this->db->query("UPDATE provisioner_devices SET needs_changes = 0 WHERE needs_changes = 1");
        }

        return [
            'success'        => true,
            'affected'       => count($pending),
            'generated'      => $generated,
            'reboots'        => $rebootResults,
            'skipped_reboot' => $skippedReboot
        ];
    }

    public function addDevice($mac, $extension, $description = '', $brand = null, $ip = '', $staticIp = null, $staticMask = null, $staticGw = null) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        if ($brand === null || !in_array($brand, $this->getBrands())) {
            $detected = $this->getBrandByMac($mac);
            $brand = $detected ?: 'digium';
        }
        if (strlen($mac) !== 12) {
            return ['success' => false, 'error' => 'Invalid MAC address — must be 12 hex characters'];
        }
        if ($ip && !filter_var($ip, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid IP address'];
        }
        $ip = $ip ?: null;
        if ($staticIp && !filter_var($staticIp, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid static IP address'];
        }
        if ($staticGw && !filter_var($staticGw, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid gateway IP address'];
        }

        $prevExt  = null;
        $prevDesc = null;
        $stmt = $this->db->prepare("SELECT id, extension, description, brand, ip_address, static_ip, previous_extension, previous_description FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $existing = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($existing) {
            if ($extension !== $existing['extension']) {
                $prevExt = $existing['extension'];
            }
            if ($description !== $existing['description']) {
                $prevDesc = $existing['description'];
            }
        }

        $now = date('Y-m-d H:i:s');
        try {
            if ($existing) {
                $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, brand=?, ip_address=NULLIF(?, ''), static_ip=NULLIF(?, ''), static_mask=NULLIF(?, ''), static_gw=NULLIF(?, ''), needs_changes=1, previous_extension=?, previous_description=?, updated_at=? WHERE mac_address=?");
                $stmt->execute([$extension, $description, $brand, $ip, $staticIp, $staticMask, $staticGw, $prevExt, $prevDesc, $now, $mac]);
            } else {
                $stmt = $this->db->prepare("INSERT INTO provisioner_devices (mac_address, extension, description, brand, needs_changes, previous_extension, previous_description, ip_address, static_ip, static_mask, static_gw, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$mac, $extension, $description, $brand, $prevExt, $prevDesc, $ip, $staticIp, $staticMask, $staticGw, $now, $now]);
            }
            $this->addLog('device', ($existing ? 'Updated' : 'Added') . " device MAC:$mac EXT:$extension BRAND:$brand" . ($ip ? " IP:$ip" : ''), 'success');
            return ['success' => true];
        } catch (\Exception $e) {
            try {
                $this->ensureTables();
                $now = date('Y-m-d H:i:s');
                if ($existing) {
                    $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, brand=?, ip_address=NULLIF(?, ''), static_ip=NULLIF(?, ''), static_mask=NULLIF(?, ''), static_gw=NULLIF(?, ''), needs_changes=1, previous_extension=?, previous_description=?, updated_at=? WHERE mac_address=?");
                    $stmt->execute([$extension, $description, $brand, $ip, $staticIp, $staticMask, $staticGw, $prevExt, $prevDesc, $now, $mac]);
                } else {
                    $stmt = $this->db->prepare("INSERT INTO provisioner_devices (mac_address, extension, description, brand, needs_changes, previous_extension, previous_description, ip_address, static_ip, static_mask, static_gw, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$mac, $extension, $description, $brand, $prevExt, $prevDesc, $ip, $staticIp, $staticMask, $staticGw, $now, $now]);
                }
                $this->addLog('device', ($existing ? 'Updated' : 'Added') . " device MAC:$mac EXT:$extension BRAND:$brand" . ($ip ? " IP:$ip" : ''), 'success');
                return ['success' => true];
            } catch (\Exception $e2) {
                $msg = $e2->getMessage();
                $this->addLog('device', "Failed to add device MAC:$mac EXT:$extension - $msg", 'error');
                return ['success' => false, 'error' => $msg];
            }
        }
    }

    public function addDiscoveredDevices($devices) {
        $added = 0;
        $errors = [];
        foreach ($devices as $d) {
            $mac  = is_array($d) ? ($d['mac'] ?? '') : $d;
            $ip   = is_array($d) ? ($d['ip'] ?? '') : '';
            $ext  = is_array($d) ? ($d['extension'] ?? '') : '';
            $clean = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
            if (strlen($clean) !== 12) {
                $errors[] = "$mac: invalid MAC";
                continue;
            }
            $stmt = $this->db->prepare("SELECT id FROM provisioner_devices WHERE mac_address=?");
            $stmt->execute([$clean]);
            if ($stmt->fetch()) {
                continue;
            }
            $result = $this->addDevice($mac, $ext, '', null, $ip);
            if ($result['success']) {
                $added++;
                if ($ext) {
                    $this->db->prepare("UPDATE provisioner_devices SET needs_changes=0 WHERE mac_address=?")->execute([$clean]);
                }
            } else {
                $errors[] = $mac . ': ' . $result['error'];
            }
        }
        $this->addLog('device', "Added $added discovered device(s) to MAC Mapping", 'success');
        return ['success' => true, 'added' => $added, 'errors' => $errors];
    }

    public function updateDevice($id, $mac, $extension, $description = '', $brand = null, $ip = '', $staticIp = null, $staticMask = null, $staticGw = null) {
        if ($brand !== null && !in_array($brand, $this->getBrands())) {
            $brand = 'digium';
        }
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        if (strlen($mac) !== 12) {
            return ['success' => false, 'error' => 'Invalid MAC address — must be 12 hex characters'];
        }
        if ($ip && !filter_var($ip, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid IP address'];
        }
        if ($staticIp && !filter_var($staticIp, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid static IP address'];
        }
        if ($staticGw && !filter_var($staticGw, FILTER_VALIDATE_IP)) {
            return ['success' => false, 'error' => 'Invalid gateway IP address'];
        }
        try {
            $stmt = $this->db->prepare("SELECT extension, description, ip_address, static_ip, previous_extension, previous_description FROM provisioner_devices WHERE id=?");
            $stmt->execute([$id]);
            $old = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$old) {
                return ['success' => false, 'error' => 'Device not found'];
            }

            $prevExt  = null;
            $prevDesc = null;
            if ($extension !== $old['extension']) {
                $prevExt = $old['extension'];
            }
            if ($description !== $old['description']) {
                $prevDesc = $old['description'];
            }

            $now = date('Y-m-d H:i:s');
            $sql = "UPDATE provisioner_devices SET mac_address=?, extension=?, description=?, ip_address=NULLIF(?, ''), static_ip=NULLIF(?, ''), static_mask=NULLIF(?, ''), static_gw=NULLIF(?, ''), needs_changes=1, previous_extension=?, previous_description=?, updated_at=? WHERE id=?";
            $params = [$mac, $extension, $description, $ip ?: null, $staticIp, $staticMask, $staticGw, $prevExt, $prevDesc, $now, $id];

            if ($brand !== null) {
                $sql = "UPDATE provisioner_devices SET mac_address=?, extension=?, description=?, brand=?, ip_address=NULLIF(?, ''), static_ip=NULLIF(?, ''), static_mask=NULLIF(?, ''), static_gw=NULLIF(?, ''), needs_changes=1, previous_extension=?, previous_description=?, updated_at=? WHERE id=?";
                $params = [$mac, $extension, $description, $brand, $ip ?: null, $staticIp, $staticMask, $staticGw, $prevExt, $prevDesc, $now, $id];
            }

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $this->addLog('device', "Updated device ID:$id", 'success');
            return ['success' => true];
        } catch (\Exception $e) {
            $this->addLog('device', "Failed to update device ID:$id - " . $e->getMessage(), 'error');
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function deleteDevice($id) {
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE id=?");
        $stmt->execute([$id]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        $stmt = $this->db->prepare("DELETE FROM provisioner_devices WHERE id=?");
        $stmt->execute([$id]);
        if ($row) {
            $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
            $this->cleanDeviceConfig($row['mac_address'], $provDir);
        }
        $this->addLog('device', "Deleted device ID:$id", 'warning');
        return ['success' => true];
    }

    public function deleteDevices($ids) {
        if (!is_array($ids)) $ids = [$ids];
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $macs = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        foreach ($macs as $mac) {
            $this->cleanDeviceConfig($mac, $provDir);
        }
        $stmt = $this->db->prepare("DELETE FROM provisioner_devices WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $this->addLog('device', "Deleted " . count($ids) . " device(s)", 'warning');
        return ['success' => true, 'deleted' => count($ids)];
    }

    public function bulkImport($csv) {
        $csv = str_replace(["\r\n", "\r"], "\n", $csv);
        $rows = explode("\n", trim($csv));
        $success = 0;
        $errors = [];
        foreach ($rows as $i => $line) {
            $line = trim($line);
            if (empty($line)) continue;
            if ($i === 0 && preg_match('/^(extension|mac|brand|description|static_ip)/i', $line)) continue;
            $parts = str_getcsv($line);
            if (count($parts) < 2) {
                $errors[] = "Row " . ($i + 1) . ": invalid format";
                continue;
            }
            $ext = trim($parts[0]);
            $mac = trim($parts[1]);
            $brand = isset($parts[2]) && trim($parts[2]) !== '' ? trim($parts[2]) : null;
            $desc = isset($parts[3]) ? trim($parts[3]) : '';
            $staticIp = isset($parts[4]) ? trim($parts[4]) : '';
            $staticMask = isset($parts[5]) ? trim($parts[5]) : '';
            $staticGw = isset($parts[6]) ? trim($parts[6]) : '';
            $result = $this->addDevice($mac, $ext, $desc, $brand, '', $staticIp ?: null, $staticMask ?: null, $staticGw ?: null);
            if ($result['success']) {
                $success++;
            } else {
                $errors[] = "Row " . ($i + 1) . ": " . $result['error'];
            }
        }
        $this->addLog('device', "Bulk imported $success devices", 'success');
        return ['success' => $success, 'errors' => $errors];
    }

    public function revertDevice($id) {
        $stmt = $this->db->prepare("SELECT extension, description, previous_extension, previous_description FROM provisioner_devices WHERE id=?");
        $stmt->execute([$id]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) {
            return ['success' => false, 'error' => 'Device not found'];
        }
        $newExt  = $device['previous_extension'] !== null ? $device['previous_extension'] : $device['extension'];
        $newDesc = $device['previous_description'] !== null ? $device['previous_description'] : $device['description'];
        $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, needs_changes=0, previous_extension=NULL, previous_description=NULL WHERE id=?");
        $stmt->execute([$newExt, $newDesc, $id]);
        $this->addLog('device', "Reverted device ID:$id", 'info');
        return ['success' => true];
    }

    public function discardAllChanges() {
        $stmt = $this->db->query("SELECT id, previous_extension, previous_description FROM provisioner_devices WHERE needs_changes = 1");
        $affected = 0;
        while ($device = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $newExt  = $device['previous_extension'] !== null ? $device['previous_extension'] : '';
            $newDesc = $device['previous_description'] !== null ? $device['previous_description'] : '';
            $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, needs_changes=0, previous_extension=NULL, previous_description=NULL WHERE id=?")
                ->execute([$newExt, $newDesc, $device['id']]);
            $affected++;
        }
        $this->addLog('device', "Discarded all changes for $affected device(s)", 'info');
        return ['success' => true, 'affected' => $affected];
    }

    // =====================
    // CONFIG FILES
    // =====================
    public function getConfigFiles() {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $files = [];
        if (!is_dir($provDir)) return $files;
        $dh = opendir($provDir);
        while (($file = readdir($dh)) !== false) {
            $ext = substr($file, -4);
            if ($ext === '.cfg') {
                $mac = substr($file, 0, -4);
            } elseif (preg_match('/^config\.([a-f0-9]{12})\.xml$/i', $file, $m)) {
                $mac = $m[1];
            } else {
                continue;
            }
            if (!preg_match('/^[a-f0-9]{12}$/i', $mac)) continue;
            if ($file === 'template.cfg' || $file === 'default.cfg') continue;
            if (preg_match('/^f0A\d+hw1\.100\.cfg$/', $file)) continue;
            $path = $provDir . '/' . $file;
            $files[] = [
                'mac'      => $mac,
                'file'     => $file,
                'size'     => filesize($path),
                'modified' => date('Y-m-d H:i:s', filemtime($path))
            ];
        }
        closedir($dh);
        return $files;
    }

    public function getConfigFileGrid() {
        $files = $this->getConfigFiles();
        $devices = $this->getDevices();
        $deviceMap = [];
        foreach ($devices as $d) {
            $deviceMap[$d['mac_address']] = $d;
        }
        $rows = [];
        foreach ($files as $f) {
            $ext = isset($deviceMap[$f['mac']]) ? $deviceMap[$f['mac']]['extension'] : '-';
            $desc = isset($deviceMap[$f['mac']]) ? $deviceMap[$f['mac']]['description'] : '-';
            $custom = isset($deviceMap[$f['mac']]) && !empty($deviceMap[$f['mac']]['custom_config']);
            $pullBtn = $custom
                ? '<a class="clickable revert-config-btn" data-mac="' . $f['mac'] . '" title="Revert to template-generated config"><i class="fa fa-undo"></i></a>'
                : '<a class="clickable fetch-config-btn" data-mac="' . $f['mac'] . '" title="Fetch current config from phone"><i class="fa fa-download"></i></a>';
            $badge = $custom ? ' <span class="badge badge-warning" style="font-size:10px;">Custom</span>' : '';
            $rows[] = [
                'mac'         => $f['mac'],
                'extension'   => $ext,
                'description' => $desc,
                'modified'    => $f['modified'],
                'actions'     => '<a class="clickable edit-config-btn" data-mac="' . $f['mac'] . '" data-ext="' . $ext . '" title="Edit"><i class="fa fa-edit"></i></a> '
                    . $pullBtn
                    . ' <a class="clickable delete-config-btn" data-mac="' . $f['mac'] . '" title="Delete"><i class="fa fa-trash"></i></a>'
            ];
        }
        return $rows;
    }

    private function getDeviceBrand($mac) {
        $stmt = $this->db->prepare("SELECT brand FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $row['brand'] : 'digium';
    }

    private function isValidPhoneConfig($mac, $content) {
        if (empty($content) || strlen($content) < 100) {
            return false;
        }
        if (preg_match('/<html|<head|<body|<title>/i', $content)) {
            return false;
        }
        if (stripos($content, '403 Forbidden') !== false || stripos($content, 'nginx') !== false || stripos($content, 'server too busy') !== false) {
            return false;
        }
        if (stripos($content, '<title>Logon</title>') !== false) {
            return false;
        }
        $brand = $this->getDeviceBrand($mac);
        if ($brand === 'digium') {
            if (strpos($content, '<<VOIP CONFIG FILE>>') === false) {
                return false;
            }
            if (strpos($content, '<SIP CONFIG MODULE>') === false && strpos($content, '<GLOBAL CONFIG MODULE>') === false) {
                return false;
            }
        } elseif ($brand === 'alcatel') {
            if (substr(trim($content), 0, 5) !== '<?xml') {
                return false;
            }
            $oldLibXml = libxml_use_internal_errors(true);
            $xml = simplexml_load_string($content);
            libxml_use_internal_errors($oldLibXml);
            if (!$xml) {
                return false;
            }
        } elseif ($brand === 'yealink') {
            if (strpos($content, '#!version:') !== 0 || !preg_match('/^\s*[a-zA-Z0-9_.-]+\s*=\s*/m', $content)) {
                return false;
            }
        }
        return true;
    }

    private function getDeviceConfigFilename($mac) {
        $mac = strtolower($mac);
        $brand = $this->getDeviceBrand($mac);
        return $brand === 'alcatel' ? 'config.' . $mac . '.xml' : $mac . '.cfg';
    }

    private function getConfigFilePath($mac) {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $path = $provDir . '/' . $this->getDeviceConfigFilename($mac);
        if (file_exists($path)) {
            return $path;
        }
        $dh = @opendir($provDir);
        if (!$dh) {
            return $path;
        }
        while (($file = readdir($dh)) !== false) {
            $ext = substr($file, -4);
            $fileMac = null;
            if ($ext === '.cfg') {
                $fileMac = substr($file, 0, -4);
            } elseif (preg_match('/^config\.([a-f0-9]{12})\.xml$/i', $file, $m)) {
                $fileMac = $m[1];
            }
            if ($fileMac !== null && strtolower($fileMac) === strtolower($mac)) {
                closedir($dh);
                return $provDir . '/' . $file;
            }
        }
        closedir($dh);
        return $path;
    }

    public function getConfigFileContent($mac) {
        $path = $this->getConfigFilePath($mac);
        if (!file_exists($path)) {
            return ['success' => false, 'error' => 'Config file not found'];
        }
        $ext = $this->getExtensionByMac($mac);
        return ['success' => true, 'content' => file_get_contents($path), 'extension' => $ext];
    }

    public function saveConfigFile($mac, $content) {
        $path = $this->getConfigFilePath($mac);
        $result = file_put_contents($path, $content);
        if ($result === false) {
            $this->addLog('config', "Failed to save config for $mac", 'error');
            return ['success' => false, 'error' => 'Failed to write config file'];
        }
        $this->addLog('config', "Saved config for $mac", 'success');
        return ['success' => true];
    }

    public function deleteConfigFile($mac) {
        $path = $this->getConfigFilePath($mac);
        if (file_exists($path)) {
            unlink($path);
        }
        $this->addLog('config', "Deleted config for $mac", 'warning');
        return ['success' => true];
    }

    public function deleteSelectedConfigFiles($macs) {
        $count = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $r = $this->deleteConfigFile($mac);
            if ($r['success']) $count++;
            else $errors[] = $mac;
        }
        $this->addLog('config', "Deleted $count config files", 'warning');
        return ['success' => true, 'deleted' => $count, 'errors' => $errors];
    }

    public function deleteAllConfigFiles() {
        $files = $this->getConfigFiles();
        $count = 0;
        foreach ($files as $f) {
            $this->deleteConfigFile($f['mac']);
            $count++;
        }
        $this->addLog('config', "Deleted all $count config files", 'warning');
        return ['success' => true, 'deleted' => $count];
    }

    private function runFetchScript($mac, $ext, $ip) {
        $brand = $this->getDeviceBrand($mac);
        if ($brand === 'alcatel') {
            $script = 'fetch_alcatel_config.py';
            $pass = $this->getSetting('phone_admin_pass_alcatel') ?: '123456';
        } else {
            $script = 'fetch_digium_config.py';
            $pass = $this->getSetting('phone_admin_pass') ?: '789';
        }
        $cmd = 'python3 ' . escapeshellarg(__DIR__ . '/' . $script)
             . ' ' . escapeshellarg($ip)
             . ' admin'
             . ' ' . escapeshellarg($pass) . ' 2>&1';
        $output = shell_exec($cmd);
        return json_decode($output, true);
    }

    public function pullPhoneConfig($mac) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) {
            return ['success' => false, 'error' => 'Device not found in MAC Mapping'];
        }
        $ext = $device['extension'];
        $target = $this->resolveDeviceTarget($device);
        $ip = $target['selected_ip'];
        $source = $target['selected_source'] ?: 'none';
        if (!$ip) {
            return ['success' => false, 'error' => "Could not determine IP for extension $ext — phone may not be registered or on DHCP"];
        }
        $result = $this->runFetchScript($mac, $ext, $ip);
        if (!$result || !$result['success']) {
            $error = $result['error'] ?? 'Script execution failed';
            $this->addLog('config', "Pull config failed for $mac (IP $ip): $error", 'error');
            return ['success' => false, 'error' => $error];
        }
        if (!$this->isValidPhoneConfig($mac, $result['config'])) {
            $errorMsg = 'Invalid config format — response does not match ' . $this->getDeviceBrand($mac) . ' phone config';
            $this->addLog('config', "Pull config failed for $mac (IP $ip): $errorMsg", 'error');
            return ['success' => false, 'error' => $errorMsg];
        }
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        if (!is_dir($provDir)) {
            mkdir($provDir, 0755, true);
            @chown($provDir, 'asterisk');
            @chgrp($provDir, 'asterisk');
        }
        $filename = $this->getDeviceConfigFilename($mac);
        $path = $provDir . '/' . $filename;
        $bakPath = $provDir . '/' . $filename . '.bak';
        if (file_exists($path)) {
            copy($path, $bakPath);
        }
        $written = file_put_contents($path, $result['config']);
        if ($written === false) {
            return ['success' => false, 'error' => 'Failed to write config file'];
        }
        $this->db->prepare("UPDATE provisioner_devices SET custom_config=1 WHERE mac_address=?")->execute([$mac]);
        $this->addLog('config', "Pulled config from phone for $mac (ext $ext) via $ip source:$source", 'success');
        return ['success' => true, 'message' => "Config pulled from phone ($ip, $source). The previous config was backed up.", 'ip' => $ip, 'ip_source' => $source];
    }

    public function fetchPhoneConfig($mac) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) {
            return ['success' => false, 'error' => 'Device not found in MAC Mapping'];
        }
        $ext = $device['extension'];
        $target = $this->resolveDeviceTarget($device);
        $ip = $target['selected_ip'];
        $source = $target['selected_source'] ?: 'none';
        if (!$ip) {
            return ['success' => false, 'error' => "Could not determine IP for extension $ext — phone may not be registered or on DHCP"];
        }
        $result = $this->runFetchScript($mac, $ext, $ip);
        if (!$result || !$result['success']) {
            $error = $result['error'] ?? 'Script execution failed';
            $this->addLog('config', "Fetch config failed for $mac: $error", 'error');
            return ['success' => false, 'error' => $error];
        }
        if (!$this->isValidPhoneConfig($mac, $result['config'])) {
            $errorMsg = 'Invalid config format — response does not match ' . $this->getDeviceBrand($mac) . ' phone config';
            $this->addLog('config', "Fetch config failed for $mac: $errorMsg", 'error');
            return ['success' => false, 'error' => $errorMsg];
        }
        $this->addLog('config', "Fetched config from phone for $mac (ext $ext) via $ip source:$source", 'info');
        return ['success' => true, 'config' => $result['config'], 'extension' => $ext, 'ip' => $ip, 'ip_source' => $source];
    }

    public function saveAsActiveConfig($mac, $content) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        if (!is_dir($provDir)) {
            mkdir($provDir, 0755, true);
            @chown($provDir, 'asterisk');
            @chgrp($provDir, 'asterisk');
        }
        $filename = $this->getDeviceConfigFilename($mac);
        $path = $provDir . '/' . $filename;
        $bakPath = $provDir . '/' . $filename . '.bak';
        if (file_exists($path)) {
            copy($path, $bakPath);
        }
        $written = file_put_contents($path, $content);
        if ($written === false) {
            return ['success' => false, 'error' => 'Failed to write config file'];
        }
        $this->db->prepare("UPDATE provisioner_devices SET custom_config=1 WHERE mac_address=?")->execute([$mac]);
        $this->addLog('config', "Saved fetched config for $mac (with backup)", 'success');
        return ['success' => true, 'message' => "Config saved as active config. Previous file backed up."];
    }

    public function revertConfigTemplate($mac) {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $filename = $this->getDeviceConfigFilename($mac);
        $cfgPath = $this->getConfigFilePath($mac);
        $bakPath = $provDir . '/' . $filename . '.bak';
        if (!file_exists($bakPath)) {
            $bakPath = $provDir . '/' . strtoupper($filename) . '.bak';
            if (!file_exists($bakPath)) {
                $dh = @opendir($provDir);
                if ($dh) {
                    while (($file = readdir($dh)) !== false) {
                        if (preg_match('/^' . preg_quote($filename, '/') . '\.bak$/i', $file)) {
                            $bakPath = $provDir . '/' . $file;
                            break;
                        }
                    }
                    closedir($dh);
                }
            }
        }
        $restored = false;
        if (file_exists($bakPath)) {
            rename($bakPath, $cfgPath);
            $restored = true;
        } else {
            if (file_exists($cfgPath)) {
                unlink($cfgPath);
            }
        }
        $this->db->prepare("UPDATE provisioner_devices SET custom_config=0 WHERE mac_address=?")->execute([$mac]);
        $msg = $restored
            ? 'Reverted to previous config by restoring from backup.'
            : 'Reverted to template. Config will be regenerated on next push.';
        $this->addLog('config', "Reverted $mac" . ($restored ? ' (restored from backup)' : ''), 'info');
        return ['success' => true, 'message' => $msg];
    }

    public function pullSelectedConfigFiles($macs) {
        $count = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $r = $this->pullPhoneConfig($mac);
            if ($r['success']) $count++;
            else $errors[] = ['mac' => $mac, 'error' => $r['error']];
        }
        $this->addLog('config', "Bulk pull: $count succeeded, " . count($errors) . " failed", $errors ? 'warning' : 'success');
        return ['success' => true, 'pulled' => $count, 'errors' => $errors];
    }

    public function revertSelectedConfigFiles($macs) {
        $count = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $r = $this->revertConfigTemplate($mac);
            if ($r['success']) $count++;
            else $errors[] = ['mac' => $mac, 'error' => $r['error']];
        }
        $this->addLog('config', "Bulk revert: $count succeeded, " . count($errors) . " failed", $errors ? 'warning' : 'success');
        return ['success' => true, 'reverted' => $count, 'errors' => $errors];
    }

    private function getExtensionByMac($mac) {
        $stmt = $this->db->prepare("SELECT extension FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $row['extension'] : '';
    }

    // =====================
    // PROVISIONING INFO
    // =====================
    public function getProvisioningInfo() {
        $pbxIp = $this->getSetting('pbx_ip') ?: '192.168.0.10';
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $isDir = is_dir($provDir);
        $writable = $isDir && is_writable($provDir) ? true : ($isDir ? false : 'missing');
        $deviceCount = 0;
        $modelFiles = [];
        if ($isDir) {
            $dh = opendir($provDir);
            while (($file = readdir($dh)) !== false) {
                $ext = substr($file, -4);
                $path = $provDir . '/' . $file;
                if ($ext === '.cfg') {
                    if (preg_match('/^f0A\d+hw1\.100\.cfg$/', $file)) {
                        $modelFiles[] = [
                            'name'     => $file,
                            'size'     => filesize($path),
                            'modified' => date('Y-m-d H:i:s', filemtime($path))
                        ];
                    } elseif ($file !== 'template.cfg' && preg_match('/^[a-f0-9]{12}\.cfg$/i', $file)) {
                        $deviceCount++;
                    }
                } elseif (preg_match('/^config\.[a-f0-9]{12}\.xml$/i', $file)) {
                    $deviceCount++;
                }
            }
            closedir($dh);
        }

        $modelCount = count($modelFiles);
        asort($modelFiles);

        return [
            'pbx_ip'       => $pbxIp,
            'prov_dir'     => $provDir,
            'dir_exists'   => $isDir,
            'dir_writable' => $writable,
            'device_count' => $deviceCount,
            'model_count'  => $modelCount,
            'model_files'  => array_values($modelFiles)
        ];
    }

    public function checkDhcpOption66() {
        $expected = 'http://' . ($this->getSetting('pbx_ip') ?: '192.168.0.10') . ':2001/provisioning/';
        $path = '/etc/asterisk/dnsmasq.conf';
        if (!file_exists($path) || !is_readable($path)) {
            return ['set' => false, 'correct' => false, 'value' => null, 'expected' => $expected];
        }
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (preg_match('/^dhcp-option\s*=\s*[^,]+,\s*66\s*,\s*(.*)$/i', trim($line), $m)) {
                $value = trim($m[1]);
                return ['set' => true, 'correct' => $value === $expected, 'value' => $value, 'expected' => $expected];
            }
        }
        return ['set' => false, 'correct' => false, 'value' => null, 'expected' => $expected];
    }

    public function getDhcpLeases() {
        if (($this->getSetting('deploy_mode') ?: 'dhcp') !== 'dhcp') {
            return ['success' => true, 'leases' => [], 'count' => 0, 'disabled' => true, 'message' => 'DHCP leases are disabled in SIP NOTIFY mode.'];
        }
        $path = $this->getSetting('dhcp_leases_file') ?: '/var/lib/misc/dnsmasq.leases';
        if (!is_readable($path)) {
            return ['success' => false, 'error' => "DHCP lease file not readable: $path"];
        }
        $lines = @file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines || !is_array($lines)) {
            return ['success' => false, 'error' => "Could not read DHCP lease file: $path"];
        }
        $leases = [];
        $seen = [];
        foreach ($lines as $line) {
            if (!preg_match('/^\d+\s+([a-f0-9:]{17})\s+(\d+\.\d+\.\d+\.\d+)\s/', trim($line), $m)) continue;
            $mac = str_replace(':', '', strtolower($m[1]));
            if (isset($seen[$mac])) continue;
            $seen[$mac] = true;
            $brand = $this->getBrandByMac($mac);
            $leases[] = [
                'mac' => strtoupper($mac),
                'mac_formatted' => $this->formatMac($mac),
                'ip' => $m[2],
                'vendor' => $brand ? ucfirst($brand) : 'Unknown',
                'model' => '-',
                'source' => 'DHCP:' . basename($path),
                'is_phone' => $brand !== null,
                'in_provisioner' => $this->checkProvisioner($mac),
            ];
        }
        return ['success' => true, 'leases' => $leases, 'count' => count($leases), 'file_path' => $path];
    }

    public function checkFirewallProvisioning() {
        $subnetsToCheck = [];

        $pbxIp = $this->getSetting('pbx_ip');
        if ($pbxIp) {
            $longIp = ip2long($pbxIp);
            if ($longIp !== false) {
                foreach ($this->getAllSubnets() as $cidr) {
                    $parts = explode('/', $cidr);
                    $net = $parts[0];
                    $prefix = (int)($parts[1] ?? 24);
                    $mask = -1 << (32 - $prefix);
                    if (($longIp & $mask) === (ip2long($net) & $mask)) {
                        $subnetsToCheck[] = $cidr;
                        break;
                    }
                }
            }
        }

        $trusted = [];
        $internal = [];
        exec('fwconsole firewall list trusted 2>/dev/null', $t);
        exec('fwconsole firewall list internal 2>/dev/null', $i);

        foreach ($t as $l) {
            if (preg_match('/^\d+\.\d+\.\d+\.\d+\/\d+/', trim($l), $m)) {
                $trusted[] = $m[0];
            }
        }
        foreach ($i as $l) {
            if (preg_match('/^\d+\.\d+\.\d+\.\d+\/\d+/', trim($l), $m)) {
                $internal[] = $m[0];
            }
        }

        $blocked = [];
        foreach ($subnetsToCheck as $s) {
            if (in_array($s, $trusted) || in_array($s, $internal)) {
                continue;
            }
            $blocked[] = $s;
        }

        if (empty($blocked)) {
            return [
                'blocked' => false,
                'message' => 'Phone subnet(s) are registered in firewall zones and provisioning should work.'
            ];
        }

        return [
            'blocked' => true,
            'blocked_subnets' => $blocked,
            'message' => implode(', ', $blocked) . ' not found in firewall trusted or internal zones and may be blocked. '
                . '<a href="./config.php?display=firewall&tab=networks" target="_blank">Add to Firewall &rarr; Networks</a>.'
        ];
    }

    public function getNetworkSubnets() {
        return ['success' => true, 'subnets' => $this->getAllSubnets(), 'interfaces' => $this->getNetworkInterfaces()];
    }

    private function getNetworkInterfaces() {
        $output = shell_exec("ip -o -f inet addr show 2>/dev/null");
        $interfaces = [];
        if ($output) {
            foreach (explode("\n", trim($output)) as $line) {
                if (preg_match('/^(\d+):\s+(\S+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)\/(\d+)/', $line, $m)) {
                    $ip = $m[3]; $prefix = (int)$m[4];
                    if ($prefix < 8 || $prefix > 30) continue;
                    if (strpos($ip, '127.') === 0 || strpos($ip, '169.254.') === 0) continue;
                    $network = long2ip(ip2long($ip) & (-1 << (32 - $prefix)));
                    $subnet = "$network/$prefix";
                    $interfaces[] = [
                        'name' => $m[2],
                        'ip' => $ip,
                        'subnet' => $subnet,
                        'label' => $m[2] . ' (' . $subnet . ')',
                    ];
                }
            }
        }
        return $interfaces;
    }

    // =====================
    // LOGS
    // =====================
    public function addLog($action, $details, $status = 'info') {
        try {
            $stmt = $this->db->prepare("INSERT INTO provisioner_logs (timestamp, action, details, status) VALUES (NOW(), ?, ?, ?)");
            $stmt->execute([$action, $details, $status]);
        } catch (\Exception $e) {}
    }

    public function getLogs($limit = 100) {
        $stmt = $this->db->prepare("SELECT * FROM provisioner_logs ORDER BY id DESC LIMIT ?");
        $stmt->bindValue(1, (int)$limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getLogGrid() {
        $rows = $this->getLogs(200);
        $result = [];
        foreach ($rows as $r) {
            $statusClass = $r['status'] === 'success' ? 'text-success' : ($r['status'] === 'error' ? 'text-danger' : 'text-muted');
            $result[] = [
                'timestamp' => $r['timestamp'],
                'action'    => $r['action'],
                'details'   => $r['details'],
                'status'    => '<span class="' . $statusClass . '">' . ucfirst($r['status']) . '</span>'
            ];
        }
        return $result;
    }

    public function clearLogs() {
        $this->db->query("DELETE FROM provisioner_logs");
        $this->addLog('logs', 'Logs cleared', 'warning');
        return ['success' => true];
    }

    // =====================
    // TEMPLATE
    // =====================
    public function getTemplateContent($brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $path = __DIR__ . '/templates/' . $brand . '/default.cfg';
        if (!file_exists($path)) {
            // Fallback to digium
            $path = __DIR__ . '/templates/digium/default.cfg';
        }
        if (!file_exists($path)) {
            return ['success' => false, 'error' => 'Template file not found.'];
        }
        $raw = file_get_contents($path);
        if ($raw === false) {
            return ['success' => false, 'error' => 'Failed to read template.'];
        }
        $passKey = $this->getBrandPassKey($brand);
        $password = $passKey ? ($this->getSetting($passKey) ?: '') : '';
        return ['success' => true, 'content' => $raw, 'password' => $password];
    }

    public function saveTemplateContent($content, $brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $path = __DIR__ . '/templates/' . $brand . '/default.cfg';
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $result = file_put_contents($path, $content);
        if ($result === false) {
            return ['success' => false, 'error' => 'Failed to write template.'];
        }
        $passKey = $this->getBrandPassKey($brand);
        if ($passKey && isset($_REQUEST['password'])) {
            $this->setSetting($passKey, $_REQUEST['password']);
        }
        $this->addLog('settings', "$brand template saved", 'success');
        return ['success' => true];
    }

    private function getBrandPassKey($brand) {
        $map = [
            'digium' => 'phone_admin_pass',
            'alcatel' => 'phone_admin_pass_alcatel',
        ];
        return $map[$brand] ?? null;
    }

    public function getDefaultTemplateContent($brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $path = __DIR__ . '/templates/' . $brand . '/default.cfg.dist';
        if (!file_exists($path)) {
            $path = __DIR__ . '/templates/digium/default.cfg.dist';
        }
        if (!file_exists($path)) {
            return ['success' => false, 'error' => 'Default template not found.'];
        }
        $raw = file_get_contents($path);
        return ['success' => true, 'content' => $raw];
    }

    public function resetTemplate($brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $dist = __DIR__ . '/templates/' . $brand . '/default.cfg.dist';
        if (!file_exists($dist)) {
            $dist = __DIR__ . '/templates/digium/default.cfg.dist';
        }
        $target = __DIR__ . '/templates/' . $brand . '/default.cfg';
        if (file_exists($dist)) {
            copy($dist, $target);
            $this->addLog('settings', "$brand template reset to default", 'success');
            return ['success' => true];
        }
        return ['success' => false, 'error' => 'Default template not found.'];
    }

    // =====================
    // DISCOVERY HELPERS
    // =====================

    private function getSubnet() {
        $output = shell_exec("ip -o -f inet addr show 2>/dev/null");
        if (!$output) return '172.16.138.0/24';
        foreach (explode("\n", trim($output)) as $line) {
            if (preg_match('/inet (\d+\.\d+\.\d+\.\d+)\/(\d+)/', $line, $m)) {
                $ip = $m[1]; $prefix = (int)$m[2];
                if ($prefix < 8 || $prefix > 30) continue;
                if (strpos($ip, '127.') === 0 || strpos($ip, '169.254.') === 0) continue;
                $network = long2ip(ip2long($ip) & (-1 << (32 - $prefix)));
                return "$network/$prefix";
            }
        }
        return '172.16.138.0/24';
    }

    private function getAllSubnets() {
        $output = shell_exec("ip -o -f inet addr show 2>/dev/null");
        if (!$output) return ['172.16.138.0/24'];
        $subnets = [];
        foreach (explode("\n", trim($output)) as $line) {
            if (preg_match('/inet (\d+\.\d+\.\d+\.\d+)\/(\d+)/', $line, $m)) {
                $ip = $m[1]; $prefix = (int)$m[2];
                if ($prefix < 8 || $prefix > 30) continue;
                if (strpos($ip, '127.') === 0 || strpos($ip, '169.254.') === 0) continue;
                $network = long2ip(ip2long($ip) & (-1 << (32 - $prefix)));
                $subnets[] = "$network/$prefix";
            }
        }
        return $subnets ?: ['172.16.138.0/24'];
    }

    private function formatMac($mac) {
        $mac = preg_replace('/[^a-f0-9]/i', '', $mac);
        if (strlen($mac) !== 12) return $mac;
        return strtoupper(substr($mac, 0, 2)) . ':' . strtoupper(substr($mac, 2, 2)) . ':'
             . strtoupper(substr($mac, 4, 2)) . ':' . strtoupper(substr($mac, 6, 2)) . ':'
             . strtoupper(substr($mac, 8, 2)) . ':' . strtoupper(substr($mac, 10, 2));
    }

    private function getLocalIP() {
        try {
            $db = \FreePBX::Database();
            $stmt = $db->query("SELECT `values` FROM `endpoint_global` WHERE `key`='internal'");
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            if ($row && !empty($row['values'])) return $row['values'];
        } catch (\Exception $e) {}
        if (!empty($_SERVER['SERVER_ADDR'])) return $_SERVER['SERVER_ADDR'];
        $ip = gethostbyname(gethostname());
        return ($ip !== gethostname()) ? $ip : '192.168.1.1';
    }

    private function checkProvisioner($mac) {
        try {
            $db = \FreePBX::Database();
            $stmt = $db->prepare("SELECT id FROM provisioner_devices WHERE mac_address = ?");
            $stmt->execute([strtoupper(preg_replace('/[^a-f0-9]/', '', $mac))]);
            return (bool)$stmt->fetch(\PDO::FETCH_ASSOC);
        } catch (\Exception $e) {
            return false;
        }
    }

    private function resolveDeviceIpsLocal($subnets = null) {
        if ($subnets === null) $subnets = $this->getArpCapableSubnets();
        if (empty($subnets)) return [];

        $ping = trim(shell_exec('which ping 2>/dev/null'));
        if (!$ping) return [];

        foreach ($subnets as $subnet) {
            $this->pingSweepSubnet($subnet, $ping);
        }

        return $this->getCurrentArpMap();
    }

    private function pingSweepSubnet($subnet, $ping) {
        $subnet = trim($subnet);
        if (empty($subnet)) return;
        $parts = explode('/', $subnet);
        if (count($parts) !== 2) return;
        $prefix = (int)$parts[1];
        if ($prefix < 8 || $prefix > 30) return;
        $hostBits = 32 - $prefix;
        if ($hostBits > 10) return;

        shell_exec("ip neigh flush to " . escapeshellarg($subnet) . " 2>/dev/null");

        $base = ip2long($parts[0]) & (-1 << (32 - $prefix));
        $count = 1 << $hostBits;
        $hostList = [];
        for ($i = 1; $i < $count - 1; $i++) {
            $hostList[] = long2ip($base + $i);
        }

        $tmpDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $pingDir = $tmpDir . '/tmp';
        if (!is_dir($pingDir)) @mkdir($pingDir, 0755, true);
        $tmpfile = tempnam($pingDir, 'ping_');
        file_put_contents($tmpfile, implode("\n", $hostList));
        shell_exec("cat " . escapeshellarg($tmpfile) . " | xargs -P50 -n1 " . escapeshellcmd($ping) . " -c1 -W1 >/dev/null 2>&1");
        @unlink($tmpfile);
    }

    public function sendSipNotify($phoneIp, $mac, $phonePort = 5060) {
        $pbxIp = $this->getSetting('pbx_ip') ?: $this->getLocalIP();
        $python = trim(shell_exec('which python3 2>/dev/null'));
        if (!$python) return ['success' => false, 'error' => 'python3 not found'];
        $script = __DIR__ . '/send_sip_notify.py';
        if (!is_readable($script)) return ['success' => false, 'error' => 'send_sip_notify.py not found'];
        $provPort = $this->getSetting('prov_port') ?: '2001';
        $macClean = strtolower($mac);
        $uri = "http://{$pbxIp}:{$provPort}/provisioning/";
        $cmd = escapeshellcmd($python) . ' ' . escapeshellarg($script)
            . ' ' . escapeshellarg($phoneIp)
            . ' ' . escapeshellarg($pbxIp)
            . ' ' . escapeshellarg($mac)
            . ' ' . escapeshellarg($uri)
            . ' ' . escapeshellarg((string)$phonePort)
            . ' 2>/dev/null';
        $output = shell_exec($cmd);
        $success = ($output !== null && trim($output) === 'OK');
        if ($mac) {
            try {
                if ($success) {
                    $this->db->prepare("UPDATE provisioner_devices SET ip_address=?, last_ack_at=NOW(), last_push_status='success', last_push_attempt_at=NOW(), needs_changes=0 WHERE mac_address=?")->execute([$phoneIp, $macClean]);
                } else {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW() WHERE mac_address=?")->execute([$macClean]);
                }
            } catch (\Exception $e) {}
        }
        $this->addLog('notify', ($success ? "NOTIFY success" : "NOTIFY failed") . " MAC:$macClean IP:$phoneIp — uri:$uri", $success ? 'success' : 'error');
        return ['success' => $success, 'output' => $output, 'uri' => $uri];
    }

    private function doNetworkScan($subnet) {
        $parts = explode('/', $subnet);
        $netIp = $parts[0];
        $prefix = isset($parts[1]) ? (int)$parts[1] : 24;
        $maskLong = -1 << (32 - $prefix);
        $netLong = ip2long($netIp) & $maskLong;

        $ping = trim(shell_exec('which ping 2>/dev/null'));
        if (!$ping) return ['error' => 'ping not found'];

        $this->pingSweepSubnet($subnet, $ping);

        $seen = [];
        $devices = [];
        $arpRaw = @file('/proc/net/arp');
        if ($arpRaw) {
            foreach ($arpRaw as $line) {
                if (!preg_match('/^(\d+\.\d+\.\d+\.\d+)\s+.*\s+([a-f0-9:]{17})\s/', $line, $m)) continue;
                $ip = $m[1];
                $mac = str_replace(':', '', strtolower($m[2]));
                if ($mac === '000000000000') continue;
                $ipLong = ip2long($ip);
                if ($ipLong === false || ($ipLong & $maskLong) !== $netLong) continue;
                if (isset($seen[$mac])) continue;
                $seen[$mac] = true;
                $brand = $this->getBrandByMac($mac);
                $devices[] = [
                    'ip' => $ip,
                    'mac' => strtoupper($mac),
                    'mac_formatted' => $this->formatMac($mac),
                    'vendor' => $brand ? ucfirst($brand) : 'Unknown',
                    'model' => '-',
                    'source' => 'ARP:' . $subnet,
                    'is_phone' => $brand !== null,
                    'in_provisioner' => $this->checkProvisioner($mac),
                ];
            }
        }
        return ['devices' => $devices];
    }

    public function scanNetwork($subnet = '') {
        set_time_limit(120);
        $subnet = trim($subnet);
        if (!$subnet) {
            return ['success' => false, 'error' => 'No subnet specified.'];
        }
        $result = $this->doNetworkScan($subnet);
        if (isset($result['error'])) {
            return ['success' => false, 'error' => $result['error']];
        }
        return ['success' => true, 'devices' => $result['devices'], 'count' => count($result['devices']), 'subnets' => [$subnet]];
    }

    public function autoDiscoverFromPjsip() {
        $pjsipOutput = shell_exec('asterisk -rx "pjsip show contacts" 2>/dev/null');
        if (!$pjsipOutput) {
            return ['success' => false, 'error' => 'Could not get PJSIP contacts'];
        }
        $ipToExt = [];
        foreach (explode("\n", $pjsipOutput) as $line) {
            if (preg_match('/^\s*Contact:\s+(\w+)\/sip:\1@(\d+\.\d+\.\d+\.\d+)/', $line, $m)) {
                $ipToExt[$m[2]] = $m[1];
            }
        }
        if (empty($ipToExt)) {
            return ['success' => false, 'error' => 'No PJSIP contacts found'];
        }

        $arpRaw = @file('/proc/net/arp');
        $matches = [];
        if ($arpRaw) {
            foreach ($arpRaw as $line) {
                if (!preg_match('/^(\d+\.\d+\.\d+\.\d+)\s+.*\s+([a-f0-9:]{17})\s/', $line, $m)) continue;
                $ip = $m[1];
                $ext = $ipToExt[$ip] ?? null;
                if (!$ext) continue;
                $mac = str_replace(':', '', strtolower($m[2]));
                if ($mac === '000000000000') continue;
                $brand = $this->getBrandByMac($mac);
                if (!$brand) continue;
                $matches[] = [
                    'mac' => strtoupper($mac),
                    'ip' => $ip,
                    'extension' => $ext,
                    'vendor' => ucfirst($brand),
                ];
            }
        }
        return [
            'success' => true,
            'matches' => $matches,
            'count' => count($matches),
        ];
    }

    private function pushConfigToPhonesBulk($macsWithIps) {
        $pbxIp = $this->getSetting('pbx_ip') ?: $this->getLocalIP();
        $provPort = $this->getSetting('prov_port') ?: '2001';
        $python = trim(shell_exec('which python3 2>/dev/null'));
        if (!$python) return ['success' => false, 'error' => 'python3 not found', 'sent' => [], 'failed' => $macsWithIps];

        $script = __DIR__ . '/send_sip_notify_bulk.py';
        if (!is_readable($script)) return ['success' => false, 'error' => 'send_sip_notify_bulk.py not found', 'sent' => [], 'failed' => $macsWithIps];

        $phones = [];
        $sources = [];
        foreach ($macsWithIps as $m) {
            $mac = strtolower($m['mac']);
            $sources[$mac] = $m['source'] ?? 'unknown';
            $uri = "http://{$pbxIp}:{$provPort}/provisioning/";
            $phones[] = [
                'phone_ip' => $m['ip'],
                'pbx_ip' => $pbxIp,
                'mac' => $mac,
                'uri' => $uri
            ];
        }

        if (empty($phones)) {
            return ['success' => true, 'sent' => [], 'failed' => []];
        }

        $tmpDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $tmpFileDir = $tmpDir . '/tmp';
        if (!is_dir($tmpFileDir)) @mkdir($tmpFileDir, 0755, true);
        $tmpFile = tempnam($tmpFileDir, 'prov_');
        file_put_contents($tmpFile, json_encode($phones));

        $cmd = escapeshellcmd($python) . ' ' . escapeshellarg($script) . ' ' . escapeshellarg($tmpFile) . ' 2>/dev/null';
        $output = shell_exec($cmd);
        @unlink($tmpFile);

        if (!$output) {
            return ['success' => false, 'error' => 'Bulk script returned no output', 'sent' => [], 'failed' => $macsWithIps];
        }

        $parsed = json_decode($output, true);
        if (!$parsed || !isset($parsed['results'])) {
            return ['success' => false, 'error' => 'Bulk script returned invalid JSON: ' . substr($output, 0, 200), 'sent' => [], 'failed' => $macsWithIps];
        }

        $sent = []; $failed = [];
        foreach ($parsed['results'] as $mac => $r) {
            $macClean = strtolower($mac);
            $source = $sources[$macClean] ?? 'unknown';
            if ($r['success']) {
                $sent[] = ['mac' => $mac, 'ip' => $r['ip'], 'source' => $source];
                try {
                    $this->db->prepare("UPDATE provisioner_devices SET ip_address=?, last_ack_at=NOW(), last_push_status='success', last_push_attempt_at=NOW(), needs_changes=0 WHERE mac_address=?")->execute([$r['ip'], $macClean]);
                } catch (\Exception $e) {}
                $this->addLog('notify', "NOTIFY success MAC:$macClean IP:{$r['ip']} source:$source — 200 OK", 'success');
            } else {
                $failed[] = ['mac' => $mac, 'ip' => $r['ip'], 'source' => $source, 'error' => 'no 200 OK'];
                try {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW(), needs_changes=1 WHERE mac_address=?")->execute([$macClean]);
                } catch (\Exception $e) {}
                $this->addLog('notify', "NOTIFY failed MAC:$macClean IP:{$r['ip']} source:$source — no 200 OK after 10 retries", 'error');
            }
        }

        return ['success' => true, 'sent' => $sent, 'failed' => $failed];
    }

    public function applyChangesWithNotify() {
        $result = $this->applyChanges(true, false);
        if (!$result['success']) return $result;

        if (empty($result['generated'])) {
            $result['generated'] = [];
            $result['affected'] = 0;
            $result['message'] = 'No pending changes — pushing current configs.';
        }

        $targets = $this->resolveDeviceTargets(true);

        $macsWithIps = [];
        $allMacs = $result['generated'];
        if (empty($allMacs)) {
            $stmt = $this->db->query("SELECT mac_address FROM provisioner_devices");
            $allMacs = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        }
        foreach ($allMacs as $mac) {
            $target = $targets[strtolower($mac)] ?? [];
            $ip = $target['selected_ip'] ?? null;
            if (!$ip) continue;
            $macsWithIps[] = ['mac' => $mac, 'ip' => $ip, 'source' => $target['selected_source']];
        }

        $bulk = $this->pushConfigToPhonesBulk($macsWithIps);

        $notifySkipped = [];
        foreach ($allMacs as $mac) {
            $macClean = strtolower($mac);
            $ip = $targets[$macClean]['selected_ip'] ?? null;
            if (!$ip) {
                $notifySkipped[] = $macClean;
                try {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW(), needs_changes=1 WHERE mac_address=?")->execute([$macClean]);
                } catch (\Exception $e) {}
                $reason = !empty($targets[$macClean]['conflict']) ? $targets[$macClean]['conflict_message'] : 'no valid private IP candidate';
                $this->addLog('notify', "NOTIFY skipped MAC:$macClean — $reason", 'warning');
            }
        }

        $result['notify_sent'] = $bulk['sent'];
        $result['notify_failed'] = $bulk['failed'];
        $result['notify_skipped'] = $notifySkipped;
        return $result;
    }

    public function pushConfigToPhones() {
        $targets = $this->resolveDeviceTargets(true);

        $stmt = $this->db->query("SELECT mac_address, extension FROM provisioner_devices ORDER BY id");
        $devices = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $macsWithIps = [];
        foreach ($devices as $d) {
            $mac = strtolower($d['mac_address']);
            $target = $targets[$mac] ?? [];
            $ip = $target['selected_ip'] ?? null;
            if (!$ip) continue;
            $macsWithIps[] = ['mac' => $mac, 'ip' => $ip, 'source' => $target['selected_source']];
        }

        $bulk = $this->pushConfigToPhonesBulk($macsWithIps);

        $skipped = [];
        foreach ($devices as $d) {
            $mac = strtolower($d['mac_address']);
            if (empty($targets[$mac]['selected_ip'])) {
                $skipped[] = $mac;
                try {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW(), needs_changes=1 WHERE mac_address=?")->execute([$mac]);
                } catch (\Exception $e) {}
                $reason = !empty($targets[$mac]['conflict']) ? $targets[$mac]['conflict_message'] : 'no valid private IP candidate';
                $this->addLog('notify', "NOTIFY skipped MAC:$mac ext:{$d['extension']} — $reason", 'warning');
            }
        }

        $bulk['skipped'] = $skipped;
        return $bulk;
    }

    public function retryPushForPhones($macs) {
        if (!is_array($macs)) $macs = [$macs];
        $targets = $this->resolveDeviceTargets(true);
        $macsWithIps = [];
        foreach ($macs as $mac) {
            $m = strtolower($mac);
            $target = $targets[$m] ?? [];
            $ip = $target['selected_ip'] ?? null;
            if ($ip) {
                $macsWithIps[] = ['mac' => $m, 'ip' => $ip, 'source' => $target['selected_source']];
            }
        }
        $result = $this->pushConfigToPhonesBulk($macsWithIps);
        foreach ($macs as $mac) {
            $m = strtolower($mac);
            if (empty($targets[$m]['selected_ip'])) {
                $result['failed'][] = ['mac' => $m, 'error' => !empty($targets[$m]['conflict']) ? $targets[$m]['conflict_message'] : 'IP not found'];
            }
        }
        $result['generated'] = $macs;
        return $result;
    }

    public function pushToPhones($macs = []) {
        if (!is_array($macs)) $macs = [$macs];
        $macs = array_map('strtolower', $macs);
        $macs = array_filter($macs);

        if (empty($macs)) {
            return $this->pushConfigToPhones();
        }

        $targets = $this->resolveDeviceTargets(true);
        $macsWithIps = [];
        foreach ($macs as $m) {
            $target = $targets[$m] ?? [];
            $ip = $target['selected_ip'] ?? null;
            if ($ip) {
                $macsWithIps[] = ['mac' => $m, 'ip' => $ip, 'source' => $target['selected_source']];
            }
        }

        $result = $this->pushConfigToPhonesBulk($macsWithIps);

        $notFound = [];
        foreach ($macs as $m) {
            if (empty($targets[$m]['selected_ip'])) {
                $reason = !empty($targets[$m]['conflict']) ? $targets[$m]['conflict_message'] : 'IP not found';
                $notFound[] = ['mac' => $m, 'error' => $reason];
                try {
                    $this->db->prepare("UPDATE provisioner_devices SET last_push_status='failed', last_push_attempt_at=NOW(), needs_changes=1 WHERE mac_address=?")->execute([$m]);
                } catch (\Exception $e) {}
                $this->addLog('notify', "NOTIFY skipped MAC:$m — $reason", 'warning');
            }
        }

        $result['failed'] = array_merge($result['failed'], $notFound);
        return $result;
    }

    public function addDiscoveredDeviceWithNotify($mac, $extension, $description = '', $ip = '') {
        $brand = $this->getBrandByMac(strtolower(preg_replace('/[^a-f0-9]/i', '', $mac)));
        $result = $this->addDevice($mac, $extension, $description, $brand, $ip);
        $notifyResult = null;
        if ($result['success']) {
            $this->applyChanges(true, false);
            if ($ip) {
                $notifyResult = $this->sendSipNotify($ip, $mac);
            }
        }
        $result['notify'] = $notifyResult;
        return $result;
    }

    // =====================
    // AJAX
    // =====================
    public function ajaxRequest($req, &$setting) {
        $allowed = [
            'getPhoneStatus', 'getPhoneStatusGrid', 'rebootPhone', 'rebootPhones', 'generateProvisioning',
            'getDevices', 'getDeviceGrid', 'getDeviceDiagnostics', 'addDevice', 'updateDevice', 'deleteDevice', 'deleteDevices',
            'bulkImport', 'getLogs', 'getLogGrid', 'clearLogs',
            'getSettings', 'saveSettings', 'getSipTransportInfo',
            'getPendingCount', 'applyChanges',
            'revertDevice', 'discardAllChanges',
            'getProvisioningInfo', 'generateAllConfigs', 'getConfigFiles', 'getConfigFileGrid', 'getConfigFileContent', 'saveConfigFile', 'deleteConfigFile', 'deleteSelectedConfigFiles', 'deleteAllConfigFiles',
            'getTemplateContent', 'saveTemplateContent',
            'getDefaultTemplateContent', 'resetTemplate',
            'addDiscoveredDevice', 'addDiscoveredDevices',
            'getBrands',
            'getExtensions', 'autoAssignExtensions', 'exportCsv', 'checkDhcpOption66', 'getDhcpLeases', 'checkFirewallProvisioning', 'getNetworkSubnets',
            'pullPhoneConfig', 'revertConfigTemplate',
            'pullSelectedConfigFiles', 'revertSelectedConfigFiles',
            'fetchPhoneConfig', 'saveAsActiveConfig',
            'scanNetwork', 'autoDiscoverFromPjsip',
            'applyChangesWithNotify', 'pushConfigToPhones',
            'retryPushForPhones', 'pushToPhones'
        ];
        return in_array($req, $allowed);
    }

    public function ajaxHandler() {
        $command = $_REQUEST['command'];
        switch ($command) {
            case 'getPhoneStatus':
                return $this->getPhoneStatus();

            case 'getPhoneStatusGrid':
                return $this->getPhoneStatusGrid();

            case 'rebootPhone':
                return $this->rebootPhone($_REQUEST['extension']);

            case 'rebootPhones':
                return $this->rebootPhones($_REQUEST['extensions']);

            case 'getProvisioningInfo':
                return $this->getProvisioningInfo();

            case 'checkDhcpOption66':
                return $this->checkDhcpOption66();

            case 'getDhcpLeases':
                return $this->getDhcpLeases();

            case 'checkFirewallProvisioning':
                return $this->checkFirewallProvisioning();

            case 'getNetworkSubnets':
                return $this->getNetworkSubnets();

            case 'generateProvisioning':
                return $this->generateProvisioning();

            case 'generateAllConfigs':
                return $this->generateAllConfigs();

            case 'getDevices':
                return $this->getDevices();

            case 'getDeviceGrid':
                return $this->getDeviceGrid();

            case 'getDeviceDiagnostics':
                $active = isset($_REQUEST['active']) && in_array($_REQUEST['active'], [true, 1, '1', 'true'], true);
                return $this->getDeviceDiagnostics($_REQUEST['mac'] ?? '', $active);

            case 'deleteDevices':
                return $this->deleteDevices($_REQUEST['ids']);

            case 'addDevice':
                return $this->addDevice(
                    $_REQUEST['mac'],
                    $_REQUEST['extension'],
                    $_REQUEST['description'] ?? '',
                    $_REQUEST['brand'] ?? null,
                    $_REQUEST['ip'] ?? '',
                    $_REQUEST['static_ip'] ?? null,
                    $_REQUEST['static_mask'] ?? null,
                    $_REQUEST['static_gw'] ?? null
                );

            case 'updateDevice':
                return $this->updateDevice(
                    $_REQUEST['id'],
                    $_REQUEST['mac'],
                    $_REQUEST['extension'],
                    $_REQUEST['description'] ?? '',
                    $_REQUEST['brand'] ?? null,
                    $_REQUEST['ip'] ?? '',
                    $_REQUEST['static_ip'] ?? null,
                    $_REQUEST['static_mask'] ?? null,
                    $_REQUEST['static_gw'] ?? null
                );

            case 'deleteDevice':
                return $this->deleteDevice($_REQUEST['id']);

            case 'bulkImport':
                return $this->bulkImport($_REQUEST['csv_content']);

            case 'getLogs':
                return $this->getLogs(isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100);

            case 'getLogGrid':
                return $this->getLogGrid();

            case 'clearLogs':
                return $this->clearLogs();

            case 'getSettings':
                return $this->getSettings();

            case 'saveSettings':
                return $this->saveSettings($_REQUEST);

            case 'getSipTransportInfo':
                return $this->getSipTransportInfo();

            case 'getPendingCount':
                return $this->getPendingCount();

            case 'applyChanges':
                $generate = isset($_REQUEST['generate']) && ($_REQUEST['generate'] === true || $_REQUEST['generate'] === 'true' || $_REQUEST['generate'] === '1');
                $reboot   = isset($_REQUEST['reboot']) && ($_REQUEST['reboot'] === true || $_REQUEST['reboot'] === 'true' || $_REQUEST['reboot'] === '1');
                return $this->applyChanges($generate, $reboot);

            case 'revertDevice':
                return $this->revertDevice($_REQUEST['id']);

            case 'discardAllChanges':
                return $this->discardAllChanges();

            case 'getConfigFiles':
                return $this->getConfigFiles();

            case 'getConfigFileGrid':
                return $this->getConfigFileGrid();

            case 'getConfigFileContent':
                return $this->getConfigFileContent($_REQUEST['mac']);

            case 'saveConfigFile':
                return $this->saveConfigFile($_REQUEST['mac'], $_REQUEST['content']);

            case 'deleteConfigFile':
                return $this->deleteConfigFile($_REQUEST['mac']);

            case 'deleteSelectedConfigFiles':
                return $this->deleteSelectedConfigFiles($_REQUEST['macs']);

            case 'deleteAllConfigFiles':
                return $this->deleteAllConfigFiles();

            case 'getTemplateContent':
                return $this->getTemplateContent($_REQUEST['brand'] ?? 'digium');

            case 'saveTemplateContent':
                return $this->saveTemplateContent($_REQUEST['content'], $_REQUEST['brand'] ?? 'digium');

            case 'getDefaultTemplateContent':
                return $this->getDefaultTemplateContent($_REQUEST['brand'] ?? 'digium');

            case 'resetTemplate':
                return $this->resetTemplate($_REQUEST['brand'] ?? 'digium');

            case 'getBrands':
                return $this->getBrands();

            case 'getExtensions':
                return $this->getExtensions();

            case 'autoAssignExtensions':
                return $this->autoAssignExtensions();

            case 'exportCsv':
                return $this->exportCsv();

            case 'addDiscoveredDevice':
                $mac = $_REQUEST['mac'] ?? '';
                $ext = $_REQUEST['extension'] ?? '';
                $desc = $_REQUEST['description'] ?? '';
                $ip = $_REQUEST['ip'] ?? '';
                if ($ext) {
                    return $this->addDiscoveredDeviceWithNotify($mac, $ext, $desc, $ip);
                }
                return $this->addDevice($mac, '', '', null, $ip);

            case 'addDiscoveredDevices':
                return $this->addDiscoveredDevices($_REQUEST['devices'] ?? []);

            case 'pullPhoneConfig':
                return $this->pullPhoneConfig($_REQUEST['mac']);

            case 'revertConfigTemplate':
                return $this->revertConfigTemplate($_REQUEST['mac']);

            case 'pullSelectedConfigFiles':
                return $this->pullSelectedConfigFiles($_REQUEST['macs']);

            case 'revertSelectedConfigFiles':
                return $this->revertSelectedConfigFiles($_REQUEST['macs']);

            case 'fetchPhoneConfig':
                return $this->fetchPhoneConfig($_REQUEST['mac']);

            case 'saveAsActiveConfig':
                return $this->saveAsActiveConfig($_REQUEST['mac'], $_REQUEST['content']);

            case 'scanNetwork':
                $subnet = $_REQUEST['subnet'] ?? '';
                return $this->scanNetwork($subnet);

            case 'autoDiscoverFromPjsip':
                return $this->autoDiscoverFromPjsip();

            case 'applyChangesWithNotify':
                return $this->applyChangesWithNotify();

            case 'pushConfigToPhones':
                return $this->pushConfigToPhones();

            case 'retryPushForPhones':
                return $this->retryPushForPhones($_REQUEST['macs'] ?? []);

            case 'pushToPhones':
                $macs = $_REQUEST['macs'] ?? [];
                if (is_string($macs)) $macs = [$macs];
                return $this->pushToPhones($macs);

            default:
                return false;
        }
    }

    // =====================
    // PAGE
    // =====================
    public function showPage() {
        $vars = ['brands' => $this->getBrands()];
        return load_view(__DIR__ . '/views/main.php', $vars);
    }

    public function getActionBar($request) {
        return [];
    }

    public function getRightNav($request) {
        return '';
    }

    private function ensureTables() {
        $this->db->query("CREATE TABLE IF NOT EXISTS provisioner_devices (id INT AUTO_INCREMENT PRIMARY KEY, mac_address VARCHAR(12) NOT NULL UNIQUE, extension VARCHAR(20) NOT NULL, description VARCHAR(255) DEFAULT '', brand VARCHAR(50) DEFAULT 'digium', created_at DATETIME DEFAULT NULL, updated_at DATETIME DEFAULT NULL, needs_changes TINYINT(1) NOT NULL DEFAULT 1, previous_extension VARCHAR(20) DEFAULT NULL, previous_description VARCHAR(255) DEFAULT NULL, ip_address VARCHAR(45) DEFAULT NULL, last_ack_at DATETIME DEFAULT NULL, last_push_status VARCHAR(20) DEFAULT NULL, last_push_attempt_at DATETIME DEFAULT NULL, static_ip VARCHAR(45) DEFAULT NULL, static_mask VARCHAR(15) DEFAULT NULL, static_gw VARCHAR(45) DEFAULT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8");
        $this->db->query("CREATE TABLE IF NOT EXISTS provisioner_logs (id INT AUTO_INCREMENT PRIMARY KEY, timestamp DATETIME NOT NULL, action VARCHAR(255) NOT NULL, details TEXT, status VARCHAR(50)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
        $this->db->query("CREATE TABLE IF NOT EXISTS provisioner_settings (key_name VARCHAR(100) NOT NULL PRIMARY KEY, value TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    }
}

<?php

interface BMO {}

require_once dirname(__DIR__) . '/Provisioner.class.php';

use FreePBX\modules\Provisioner;

final class TestFreePBX {
    private $db;
    public function __construct($db) { $this->db = $db; }
    public function Database() { return $this->db; }
}

$tests = [];
$tempDirs = [];

function test($name, $callback) {
    global $tests;
    $tests[$name] = $callback;
}

function assertTrue($condition, $message = 'Expected condition to be true') {
    if (!$condition) throw new RuntimeException($message);
}

function assertSame($expected, $actual, $message = '') {
    if ($expected !== $actual) {
        throw new RuntimeException(($message ? $message . ': ' : '') . 'expected ' . var_export($expected, true) . ', got ' . var_export($actual, true));
    }
}

function invokePrivate($object, $method, ...$args) {
    $reflection = new ReflectionMethod($object, $method);
    $reflection->setAccessible(true);
    return $reflection->invokeArgs($object, $args);
}

function makeFixture() {
    global $tempDirs;
    $dir = sys_get_temp_dir() . '/provisioner-tests-' . bin2hex(random_bytes(6));
    if (!mkdir($dir, 0770, true)) throw new RuntimeException('Could not create fixture directory');
    $tempDirs[] = $dir;
    $db = new PDO('sqlite::memory:');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->sqliteCreateFunction('NOW', function () { return date('Y-m-d H:i:s'); });
    $db->exec("CREATE TABLE provisioner_settings (key_name TEXT PRIMARY KEY, value TEXT)");
    $db->exec("CREATE TABLE provisioner_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, action TEXT, details TEXT, status TEXT)");
    $db->exec("CREATE TABLE provisioner_devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT, mac_address TEXT UNIQUE, extension TEXT, description TEXT,
        brand TEXT DEFAULT 'digium', created_at TEXT, updated_at TEXT, needs_changes INTEGER DEFAULT 1,
        previous_extension TEXT, previous_description TEXT, custom_config INTEGER DEFAULT 0,
        ip_address TEXT, last_ack_at TEXT, last_push_status TEXT, last_push_attempt_at TEXT,
        static_ip TEXT, static_mask TEXT, static_gw TEXT
    )");
    $db->exec("CREATE TABLE sip (id TEXT, keyword TEXT, data TEXT)");
    $db->exec("CREATE TABLE pjsip (id TEXT, keyword TEXT, data TEXT)");
    $stmt = $db->prepare("INSERT INTO provisioner_settings (key_name, value) VALUES (?, ?)");
    foreach ([['prov_dir', $dir], ['pbx_ip', '192.0.2.10'], ['sip_port', '5060'], ['transport', 'UDP'], ['deploy_mode', 'dhcp']] as $setting) {
        $stmt->execute($setting);
    }
    return [new Provisioner(new TestFreePBX($db)), $db, $dir];
}

function insertDevice($db, $mac, $extension, $brand = 'digium', $custom = 0, $pending = 0) {
    $stmt = $db->prepare("INSERT INTO provisioner_devices (mac_address, extension, description, brand, custom_config, needs_changes) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$mac, $extension, 'Test phone', $brand, $custom, $pending]);
}

function digiumConfig($extension) {
    return "<<VOIP CONFIG FILE>>\n<GLOBAL CONFIG MODULE>\nAccount Label : Test\n<SIP CONFIG MODULE>\nSIP1 Register User : $extension\nSIP1 Phone Number : $extension\n" . str_repeat('Padding : value\n', 8) . "<<END OF FILE>>\n";
}

function removeTree($path) {
    if (!is_dir($path)) return;
    foreach (scandir($path) as $item) {
        if ($item !== '.' && $item !== '..') {
            $target = $path . '/' . $item;
            is_dir($target) ? removeTree($target) : @unlink($target);
        }
    }
    @rmdir($path);
}

test('brand detection and supported brands', function () {
    [$module] = makeFixture();
    assertSame('digium', $module->getBrandByMac('00:0F:D3:00:00:01'));
    assertSame('alcatel', $module->getBrandByMac('00-80-9F-00-00-01'));
    assertSame('yealink', $module->getBrandByMac('80:5e:c0:00:00:01'));
    assertSame(null, $module->getBrandByMac('12:34:56:00:00:01'));
    assertTrue(in_array('digium', $module->getBrands(), true));
});

test('brand-specific validation and extension extraction', function () {
    [$module, $db] = makeFixture();
    insertDevice($db, '000fd3000001', '1000', 'digium');
    insertDevice($db, '00809f000001', '2000', 'alcatel');
    insertDevice($db, '805ec0000001', '3000', 'yealink');
    $alcatel = '<?xml version="1.0"?><settings><group>' . str_repeat('<setting id="Padding" value="value"/>', 4)
        . '<setting id="SIPGroup1AuthenticationName" value="2000"/></group></settings>';
    $yealink = "#!version:1.0.0.1\naccount.1.user_name = 3000\n" . str_repeat("account.1.label = Test Phone\n", 5);
    foreach ([
        ['000fd3000001', digiumConfig('1000'), '1000'],
        ['00809f000001', $alcatel, '2000'],
        ['805ec0000001', $yealink, '3000']
    ] as $case) {
        assertTrue(invokePrivate($module, 'isValidPhoneConfig', $case[0], $case[1]));
        assertSame($case[2], invokePrivate($module, 'extractConfigExtension', $case[0], $case[1]));
    }
    assertTrue(!invokePrivate($module, 'isValidPhoneConfig', '000fd3000001', '<html>' . str_repeat('x', 150) . '</html>'));
});

test('custom regeneration archives pulled config', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000002';
    insertDevice($db, $mac, '1000', 'digium', 1, 0);
    $db->prepare("INSERT INTO pjsip (id, keyword, data) VALUES (?, 'password', ?)")->execute(['1000', 'secret-value']);
    $custom = digiumConfig('1000');
    file_put_contents("$dir/$mac.cfg", $custom);
    $confirm = $module->generateAllConfigs(false);
    assertTrue(!empty($confirm['requires_confirmation']));
    $result = $module->generateAllConfigs(true);
    assertTrue($result['success']);
    assertSame(1, $result['custom_replaced']);
    assertSame($custom, file_get_contents("$dir/$mac.cfg.custom.bak"));
    assertTrue(file_get_contents("$dir/$mac.cfg") !== $custom);
    assertSame('0', (string)$db->query("SELECT custom_config FROM provisioner_devices")->fetchColumn());
});

test('matching restore preserves archive and marks device pending', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000003';
    insertDevice($db, $mac, '1000');
    $generated = digiumConfig('1000') . 'Generated : yes\n';
    $archive = digiumConfig('1000') . 'Pulled : yes\n';
    file_put_contents("$dir/$mac.cfg", $generated);
    file_put_contents("$dir/$mac.cfg.custom.bak", $archive);
    $info = $module->getCustomBackupInfo($mac);
    assertTrue($info['success'] && $info['valid'] && $info['extension_matches']);
    $result = $module->restoreCustomBackup($mac);
    assertTrue($result['success']);
    assertSame($archive, file_get_contents("$dir/$mac.cfg"));
    assertSame($archive, file_get_contents("$dir/$mac.cfg.custom.bak"));
    assertSame($generated, file_get_contents("$dir/$mac.cfg.bak"));
    $row = $db->query("SELECT custom_config, needs_changes FROM provisioner_devices")->fetch(PDO::FETCH_ASSOC);
    assertSame('1', (string)$row['custom_config']);
    assertSame('1', (string)$row['needs_changes']);
});

test('mismatched restore requires force and remains atomic', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000004';
    insertDevice($db, $mac, '2000');
    $generated = digiumConfig('2000');
    $archive = digiumConfig('1000');
    file_put_contents("$dir/$mac.cfg", $generated);
    file_put_contents("$dir/$mac.cfg.custom.bak", $archive);
    $blocked = $module->restoreCustomBackup($mac);
    assertTrue(!$blocked['success'] && $blocked['requires_confirmation']);
    assertSame($generated, file_get_contents("$dir/$mac.cfg"));
    assertSame('0', (string)$db->query("SELECT custom_config FROM provisioner_devices")->fetchColumn());
    $forced = $module->restoreCustomBackup($mac, true);
    assertTrue($forced['success']);
    assertSame($archive, file_get_contents("$dir/$mac.cfg"));
});

test('invalid archive cannot be restored', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000005';
    insertDevice($db, $mac, '1000');
    $active = digiumConfig('1000');
    file_put_contents("$dir/$mac.cfg", $active);
    file_put_contents("$dir/$mac.cfg.custom.bak", '<html>' . str_repeat('x', 200) . '</html>');
    $result = $module->restoreCustomBackup($mac, true);
    assertTrue(!$result['success']);
    assertSame($active, file_get_contents("$dir/$mac.cfg"));
});

test('revert restores generated backup and marks pending', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000006';
    insertDevice($db, $mac, '1000', 'digium', 1, 0);
    $generated = digiumConfig('1000') . 'Generated : yes\n';
    file_put_contents("$dir/$mac.cfg", digiumConfig('1000') . 'Custom : yes\n');
    file_put_contents("$dir/$mac.cfg.bak", $generated);
    $result = $module->revertConfigTemplate($mac);
    assertTrue($result['success']);
    assertSame($generated, file_get_contents("$dir/$mac.cfg"));
    $row = $db->query("SELECT custom_config, needs_changes FROM provisioner_devices")->fetch(PDO::FETCH_ASSOC);
    assertSame('0', (string)$row['custom_config']);
    assertSame('1', (string)$row['needs_changes']);
    assertSame($generated, file_get_contents("$dir/$mac.cfg.bak"));
    assertSame([], glob($dir . '/.revert-*'));
});

test('revert without backup safely removes active config', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000008';
    insertDevice($db, $mac, '1000', 'digium', 1, 0);
    file_put_contents("$dir/$mac.cfg", digiumConfig('1000') . 'Custom : yes\n');
    $result = $module->revertConfigTemplate($mac);
    assertTrue($result['success']);
    assertTrue(!file_exists("$dir/$mac.cfg"));
    $row = $db->query("SELECT custom_config, needs_changes FROM provisioner_devices")->fetch(PDO::FETCH_ASSOC);
    assertSame('0', (string)$row['custom_config']);
    assertSame('1', (string)$row['needs_changes']);
    assertSame([], glob($dir . '/.revert-*'));
});

test('revert rejects invalid generated backup without state changes', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000009';
    insertDevice($db, $mac, '1000', 'digium', 1, 0);
    $custom = digiumConfig('1000') . 'Custom : yes\n';
    file_put_contents("$dir/$mac.cfg", $custom);
    file_put_contents("$dir/$mac.cfg.bak", '<html>' . str_repeat('x', 200) . '</html>');
    $result = $module->revertConfigTemplate($mac);
    assertTrue(!$result['success']);
    assertSame($custom, file_get_contents("$dir/$mac.cfg"));
    assertSame('1', (string)$db->query("SELECT custom_config FROM provisioner_devices")->fetchColumn());
    assertSame([], glob($dir . '/.revert-*'));
});

test('revert filesystem failure leaves database state unchanged', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000010';
    insertDevice($db, $mac, '1000', 'digium', 1, 0);
    mkdir("$dir/$mac.cfg");
    file_put_contents("$dir/$mac.cfg.bak", digiumConfig('1000'));
    $result = $module->revertConfigTemplate($mac);
    assertTrue(!$result['success']);
    assertTrue(is_dir("$dir/$mac.cfg"));
    $row = $db->query("SELECT custom_config, needs_changes FROM provisioner_devices")->fetch(PDO::FETCH_ASSOC);
    assertSame('1', (string)$row['custom_config']);
    assertSame('0', (string)$row['needs_changes']);
    assertSame([], glob($dir . '/.revert-*'));
});

test('revert database failure restores original active config', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000011';
    insertDevice($db, $mac, '1000', 'digium', 1, 0);
    $custom = digiumConfig('1000') . 'Custom : yes\n';
    $generated = digiumConfig('1000') . 'Generated : yes\n';
    file_put_contents("$dir/$mac.cfg", $custom);
    file_put_contents("$dir/$mac.cfg.bak", $generated);
    $db->exec("CREATE TRIGGER fail_revert BEFORE UPDATE OF custom_config ON provisioner_devices WHEN NEW.custom_config=0 BEGIN SELECT RAISE(FAIL, 'forced update failure'); END");
    $result = $module->revertConfigTemplate($mac);
    assertTrue(!$result['success']);
    assertTrue(strpos($result['error'], 'active custom config was restored') !== false);
    assertSame($custom, file_get_contents("$dir/$mac.cfg"));
    assertSame($generated, file_get_contents("$dir/$mac.cfg.bak"));
    $row = $db->query("SELECT custom_config, needs_changes FROM provisioner_devices")->fetch(PDO::FETCH_ASSOC);
    assertSame('1', (string)$row['custom_config']);
    assertSame('0', (string)$row['needs_changes']);
    assertSame([], glob($dir . '/.revert-*'));
});

test('revert refuses concurrent phone operation', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000012';
    insertDevice($db, $mac, '1000', 'digium', 1, 0);
    $custom = digiumConfig('1000') . 'Custom : yes\n';
    file_put_contents("$dir/$mac.cfg", $custom);
    file_put_contents("$dir/$mac.cfg.bak", digiumConfig('1000'));
    $uid = function_exists('posix_geteuid') ? posix_geteuid() : getmyuid();
    $lock = fopen(sys_get_temp_dir() . "/provisioner-fetch-$uid-$mac.lock", 'c');
    assertTrue($lock !== false && flock($lock, LOCK_EX | LOCK_NB));
    try {
        $result = $module->revertConfigTemplate($mac);
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
    assertTrue(!$result['success']);
    assertSame($custom, file_get_contents("$dir/$mac.cfg"));
    assertSame('1', (string)$db->query("SELECT custom_config FROM provisioner_devices")->fetchColumn());
});

test('config grid exposes state and restore action', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000007';
    insertDevice($db, $mac, '1000');
    file_put_contents("$dir/$mac.cfg", digiumConfig('1000'));
    file_put_contents("$dir/$mac.cfg.custom.bak", digiumConfig('1000'));
    $rows = $module->getConfigFileGrid();
    assertSame(1, count($rows));
    assertSame('1000', (string)$rows[0]['assigned_extension']);
    assertSame('1000', (string)$rows[0]['config_extension']);
    assertTrue(strpos($rows[0]['state'], 'Extension match') !== false);
    assertTrue(strpos($rows[0]['state'], 'Pulled backup') !== false);
    assertTrue(strpos($rows[0]['actions'], 'restore-pulled-btn') !== false);
});

test('config grid reads assigned and file extensions for every brand', function () {
    [$module, $db, $dir] = makeFixture();
    insertDevice($db, '000fd3000020', '1000', 'digium');
    insertDevice($db, '00809f000020', '2000', 'alcatel');
    insertDevice($db, '805ec0000020', '3000', 'yealink');
    file_put_contents("$dir/000fd3000020.cfg", digiumConfig('1000'));
    $alcatel = '<?xml version="1.0"?><settings><group>' . str_repeat('<setting id="Padding" value="value"/>', 4)
        . '<setting id="SIPGroup1AuthenticationName" value="2000"/></group></settings>';
    file_put_contents("$dir/config.00809f000020.xml", $alcatel);
    $yealink = "#!version:1.0.0.1\naccount.1.auth_name = 3000\n" . str_repeat("account.1.label = Test Phone\n", 5);
    file_put_contents("$dir/805ec0000020.cfg", $yealink);
    $rows = [];
    foreach ($module->getConfigFileGrid() as $row) $rows[$row['mac']] = $row;
    assertSame('1000', (string)$rows['000fd3000020']['config_extension']);
    assertSame('2000', (string)$rows['00809f000020']['config_extension']);
    assertSame('3000', (string)$rows['805ec0000020']['config_extension']);
    foreach ($rows as $row) assertTrue(strpos($row['state'], 'Extension match') !== false);
});

test('pending extension change shows old to new and generated push target', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000021';
    insertDevice($db, $mac, '2000', 'digium', 0, 1);
    $db->prepare("UPDATE provisioner_devices SET previous_extension=? WHERE mac_address=?")->execute(['1000', $mac]);
    file_put_contents("$dir/$mac.cfg", digiumConfig('1000'));
    $device = $module->getDeviceGrid()[0];
    assertTrue(strpos($device['extension_display'], '1000') !== false && strpos($device['extension_display'], '2000') !== false);
    assertTrue(strpos($device['config_sync'], 'Will generate 2000 on Push') !== false);
    $config = $module->getConfigFileGrid()[0];
    assertSame('2000', (string)$config['assigned_extension']);
    assertSame('1000', (string)$config['config_extension']);
    assertTrue(strpos($config['state'], 'Will generate 2000 on Push') !== false);
});

test('custom extension mismatch identifies value that push will use', function () {
    [$module, $db, $dir] = makeFixture();
    $mac = '000fd3000022';
    insertDevice($db, $mac, '2000', 'digium', 1, 1);
    file_put_contents("$dir/$mac.cfg", digiumConfig('1000'));
    $device = $module->getDeviceGrid()[0];
    assertTrue(strpos($device['config_sync'], 'Custom Mismatch: file uses 1000') !== false);
    $config = $module->getConfigFileGrid()[0];
    assertSame('2000', (string)$config['assigned_extension']);
    assertSame('1000', (string)$config['config_extension']);
    assertTrue(strpos($config['state'], 'Push uses config 1000') !== false);
});

test('mapping grid reports missing and unknown config extensions', function () {
    [$module, $db, $dir] = makeFixture();
    insertDevice($db, '000fd3000023', '1000', 'digium');
    insertDevice($db, '000fd3000024', '2000', 'digium');
    $unknown = "<<VOIP CONFIG FILE>>\n<GLOBAL CONFIG MODULE>\n<SIP CONFIG MODULE>\n" . str_repeat('Padding : value\n', 8) . "<<END OF FILE>>\n";
    file_put_contents("$dir/000fd3000024.cfg", $unknown);
    $rows = [];
    foreach ($module->getDeviceGrid() as $row) $rows[$row['mac_address']] = $row;
    assertTrue(strpos($rows['000fd3000023']['config_sync'], 'Config Missing') !== false);
    assertTrue(strpos($rows['000fd3000024']['config_sync'], 'Extension Unknown') !== false);
    $config = $module->getConfigFileGrid()[0];
    assertTrue(strpos($config['config_extension'], 'Unknown') !== false);
});

test('swap grouping detects rotations but rejects duplicate origins', function () {
    [$module] = makeFixture();
    $rotation = [
        ['mac_address' => 'a', 'previous_extension' => '1000', 'extension' => '2000'],
        ['mac_address' => 'b', 'previous_extension' => '2000', 'extension' => '3000'],
        ['mac_address' => 'c', 'previous_extension' => '3000', 'extension' => '1000']
    ];
    assertSame([['a', 'b', 'c']], invokePrivate($module, 'getPendingExtensionSwapGroups', $rotation));
    $rotation[] = ['mac_address' => 'd', 'previous_extension' => '1000', 'extension' => '4000'];
    assertSame([], invokePrivate($module, 'getPendingExtensionSwapGroups', $rotation));
});

test('subnet normalization and AJAX commands are guarded', function () {
    [$module] = makeFixture();
    assertSame(['192.168.10.0/24', '10.0.0.0/8'], invokePrivate($module, 'normalizeScanSubnets', '192.168.10.77/24, 10.4.5.6/8'));
    assertSame(null, invokePrivate($module, 'normalizeScanSubnets', '192.168.1.1/99'));
    $setting = null;
    assertTrue($module->ajaxRequest('restoreCustomBackup', $setting));
    assertTrue($module->ajaxRequest('autoAddSupportedDiscoveredDevices', $setting));
    assertTrue(!$module->ajaxRequest('arbitraryCommand', $setting));
});

test('auto add support is limited to provisionable phone brands', function () {
    [$module] = makeFixture();
    assertSame('digium', invokePrivate($module, 'getSupportedDiscoveryBrand', '000fd3000030'));
    assertSame('alcatel', invokePrivate($module, 'getSupportedDiscoveryBrand', '00809f000030'));
    assertSame('yealink', invokePrivate($module, 'getSupportedDiscoveryBrand', '805ec0000030'));
    assertSame(null, invokePrivate($module, 'getSupportedDiscoveryBrand', '000c41000030'));
    assertSame(null, invokePrivate($module, 'getSupportedDiscoveryBrand', '123456000030'));
});

test('auto add is rejected outside SIP NOTIFY mode', function () {
    [$module] = makeFixture();
    $result = $module->autoAddSupportedDiscoveredDevices([
        ['mac' => '000fd3000031', 'ip' => '192.0.2.31']
    ], []);
    assertTrue(!$result['success']);
    assertTrue(strpos($result['error'], 'SIP NOTIFY') !== false);
});

test('auto add includes supported unmatched phones and skips unsupported devices', function () {
    [$module, $db] = makeFixture();
    $db->exec("UPDATE provisioner_settings SET value='sip_notify' WHERE key_name='deploy_mode'");
    $devices = [
        ['mac' => '000fd3000032', 'ip' => '192.0.2.32'],
        ['mac' => '00809f000032', 'ip' => '192.0.2.33'],
        ['mac' => '805ec0000032', 'ip' => '192.0.2.34'],
        ['mac' => '000c41000032', 'ip' => '192.0.2.35'],
        ['mac' => '123456000032', 'ip' => '192.0.2.36']
    ];
    $matches = [
        ['mac' => '000fd3000032', 'extension' => '1000'],
        ['mac' => '805ec0000032', 'extension' => '3000']
    ];
    $result = $module->autoAddSupportedDiscoveredDevices($devices, $matches);
    assertTrue($result['success']);
    assertSame(3, $result['added_count']);
    assertSame(2, $result['added_with_extension']);
    assertSame(1, $result['added_without_extension']);
    assertSame(2, $result['unsupported_count']);
    $rows = $db->query("SELECT mac_address, extension, brand, needs_changes FROM provisioner_devices ORDER BY mac_address")->fetchAll(PDO::FETCH_ASSOC);
    assertSame(3, count($rows));
    $byMac = [];
    foreach ($rows as $row) $byMac[$row['mac_address']] = $row;
    assertSame('1000', $byMac['000fd3000032']['extension']);
    assertSame('', $byMac['00809f000032']['extension']);
    assertSame('3000', $byMac['805ec0000032']['extension']);
    assertSame('alcatel', $byMac['00809f000032']['brand']);
    foreach ($rows as $row) assertSame('1', (string)$row['needs_changes']);
});

test('auto add leaves conflicting PJSIP extensions unassigned', function () {
    [$module, $db] = makeFixture();
    $db->exec("UPDATE provisioner_settings SET value='sip_notify' WHERE key_name='deploy_mode'");
    insertDevice($db, '000fd3000040', '1000', 'digium', 0, 0);
    $devices = [
        ['mac' => '000fd3000041', 'ip' => '192.0.2.41'],
        ['mac' => '000fd3000042', 'ip' => '192.0.2.42'],
        ['mac' => '000fd3000043', 'ip' => '192.0.2.43']
    ];
    $matches = [
        ['mac' => '000fd3000041', 'extension' => '1000'],
        ['mac' => '000fd3000042', 'extension' => '2000'],
        ['mac' => '000fd3000043', 'extension' => '2000']
    ];
    $result = $module->autoAddSupportedDiscoveredDevices($devices, $matches);
    assertSame(3, $result['added_count']);
    assertSame(0, $result['added_with_extension']);
    assertSame(3, count($result['extension_conflicts']));
    $extensions = $db->query("SELECT extension FROM provisioner_devices WHERE mac_address <> '000fd3000040'")->fetchAll(PDO::FETCH_COLUMN);
    assertSame(['', '', ''], $extensions);
});

test('auto add refreshes only the IP of existing mappings', function () {
    [$module, $db] = makeFixture();
    $db->exec("UPDATE provisioner_settings SET value='sip_notify' WHERE key_name='deploy_mode'");
    insertDevice($db, '000fd3000050', '5000', 'digium', 1, 1);
    $db->exec("UPDATE provisioner_devices SET ip_address='192.0.2.50', previous_extension='4000', description='Preserve me' WHERE mac_address='000fd3000050'");
    $result = $module->autoAddSupportedDiscoveredDevices([
        ['mac' => '000fd3000050', 'ip' => '192.0.2.51']
    ], [['mac' => '000fd3000050', 'extension' => '9999']]);
    assertSame(0, $result['added_count']);
    assertSame(1, $result['refreshed_count']);
    $row = $db->query("SELECT extension, description, brand, ip_address, custom_config, needs_changes, previous_extension FROM provisioner_devices")->fetch(PDO::FETCH_ASSOC);
    assertSame('5000', $row['extension']);
    assertSame('Preserve me', $row['description']);
    assertSame('digium', $row['brand']);
    assertSame('192.0.2.51', $row['ip_address']);
    assertSame('1', (string)$row['custom_config']);
    assertSame('1', (string)$row['needs_changes']);
    assertSame('4000', $row['previous_extension']);
});

test('auto add discovery controls are SIP mode aware', function () {
    $root = dirname(__DIR__);
    $view = file_get_contents($root . '/views/main.php');
    $javascript = file_get_contents($root . '/assets/js/provisioner.js');
    assertTrue(strpos($view, 'id="autoAddSupportedBtn"') !== false);
    assertTrue(strpos($javascript, "discoveryMode === 'sip_notify'") !== false);
    assertTrue(strpos($javascript, 'autoAddSupportedDiscoveredDevices') !== false);
    assertTrue(strpos($javascript, 'Review MAC Mapping') !== false);
});

test('module and installer versions agree', function () {
    $root = dirname(__DIR__);
    $xml = simplexml_load_file($root . '/module.xml');
    $version = (string)$xml->version;
    foreach (['install.php', 'upgrade.php'] as $file) {
        $content = file_get_contents($root . '/' . $file);
        $pattern = '/\$version\s*=\s*[\'\"]' . preg_quote($version, '/') . '[\'\"]/';
        assertTrue((bool)preg_match($pattern, $content), "$file version differs from module.xml");
    }
});

$passed = 0;
$failed = 0;
foreach ($tests as $name => $callback) {
    try {
        $callback();
        echo "PASS $name\n";
        $passed++;
    } catch (Throwable $error) {
        echo "FAIL $name: " . $error->getMessage() . "\n";
        $failed++;
    }
}
foreach ($tempDirs as $dir) removeTree($dir);
echo "\n$passed passed, $failed failed\n";
exit($failed === 0 ? 0 : 1);

$(document).ready(function () {

  const ajax = function (command, data, callback) {
    data = data || {};
    data.module = 'provisioner';
    return $.post('ajax.php?module=provisioner&command=' + command, data, function (res) {
      callback(res);
    }, 'json').fail(function (xhr) {
      if (xhr.statusText === 'abort') return;
      console.error('AJAX error:', xhr.responseText);
      callback({ error: 'Request failed' });
    });
  };

  // =====================
  // IP SORTER
  // =====================
  window.ipSorter = function (a, b) {
    if (!a) return -1;
    if (!b) return 1;
    var aa = a.split('.').map(function (n) { return ('000' + n).slice(-3); }).join('');
    var bb = b.split('.').map(function (n) { return ('000' + n).slice(-3); }).join('');
    return aa.localeCompare(bb);
  };

  // =====================
  // PENDING CHANGES COUNT
  // =====================
  var pendingNeedsReboot = false;

  function loadPendingCount(callback) {
    ajax('getPendingCount', {}, function (res) {
      var count = res && res.count ? res.count : 0;
      var badge = $('#pendingBadge');
      var btn = $('#applyChangesBtn');
      var badgePhone = $('#pendingBadgePhone');
      var btnPhone = $('#applyChangesPhoneBtn');
      var discard = $('#discardAllBtn');
      pendingNeedsReboot = res && res.needs_reboot ? true : false;
      var isSipNotify = res && res.deploy_mode === 'sip_notify';
      if (count > 0) {
        badge.text(count).show();
        btn.prop('disabled', false);
        badgePhone.text(count).show();
        btnPhone.show();
        discard.show();
      } else if (isSipNotify) {
        badge.text('Push').removeClass('badge-primary badge-danger badge-warning badge-info').addClass('badge-info').show();
        btn.prop('disabled', false);
        badgePhone.text('Push').removeClass('badge-primary badge-danger badge-warning badge-info').addClass('badge-info').show();
        btnPhone.show();
        discard.hide();
      } else {
        badge.hide();
        btn.prop('disabled', true);
        badgePhone.hide();
        btnPhone.hide();
        discard.hide();
      }
      if (callback) callback(count);
    });
  }

  // =====================
  // TABLE SELECTION TRACKING
  // =====================
  var selectedExtensions = [];
  var selectedDeviceIds = [];
  var selectedConfigMacs = [];
  var selectedDhcpMacs = [];
  var discoveredRows = [];
  var discoveryMode = 'dhcp';
  var scanCompleted = false;
  var liveInterval = null;
  var autoRefreshCountdown = 5;

  function onTableSelect(tableId, field, store, preserveSelection) {
    function syncSelection() {
      store.length = 0;
      var selections = $('#' + tableId).bootstrapTable('getSelections');
      $.each(selections, function (i, row) {
        store.push(row[field]);
      });
      updateButtonStates();
    }
    $('#' + tableId).on('check.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table',
      syncSelection
    );
    $('#' + tableId).on('page-change.bs.table', function () {
      if (preserveSelection) {
        setTimeout(syncSelection, 0);
        return;
      }
      store.length = 0;
      updateButtonStates();
    });
    if (preserveSelection) $('#' + tableId).on('search.bs.table', function () { setTimeout(syncSelection, 0); });
  }

  function updateButtonStates() {
    $('#rebootSelectedBtn').prop('disabled', selectedExtensions.length === 0);
    $('#deleteSelectedBtn').prop('disabled', selectedDeviceIds.length === 0);
    $('#deleteSelectedConfigBtn').prop('disabled', selectedConfigMacs.length === 0);
    $('#pullSelectedConfigBtn').prop('disabled', selectedConfigMacs.length === 0);
    $('#revertSelectedConfigBtn').prop('disabled', selectedConfigMacs.length === 0);
    var hasNewDiscoverySelection = selectedDhcpMacs.some(function (mac) {
      var row = discoveredRows.find(function (candidate) { return candidate.mac === mac; });
      return row && row.status === 'new';
    });
    $('#addSelectedDiscoveryBtn').prop('disabled', !hasNewDiscoverySelection);
  }

  // =====================
  // TABLE EVENT INIT
  // =====================
  onTableSelect('phoneStatusTable', 'extension', selectedExtensions, true);

  $('#phoneStatusTable').on('post-body.bs.table', function () {
    $('.reboot-btn').off('click').on('click', function () {
      var ext = $(this).data('ext');
      showConfirm('Reboot Phone', 'Reboot extension ' + ext + '?', function () {
        ajax('rebootPhone', { extension: ext }, function (res) {
          if (res && res.success) {
            showAlert('success', 'Reboot sent to extension ' + ext);
            $('#phoneStatusTable').bootstrapTable('refresh');
          } else {
            showAlert('danger', 'Reboot failed for extension ' + ext);
          }
        });
      });
    });
    $('.retry-push-btn').off('click').on('click', function () {
      var btn = $(this);
      btn.html('<i class="fa fa-spinner fa-spin"></i>');
      var mac = btn.data('mac');
      ajax('retryPushForPhones', { macs: [mac] }, function (res) {
        if (res && res.success) {
          var sent = (res.sent || []).length;
          var failed = (res.failed || []).length;
          var msg = 'Retry done. ' + sent + ' sent, ' + failed + ' failed.';
          showAlert(sent > 0 ? 'success' : 'warning', msg);
        } else {
          showAlert('danger', 'Retry failed: ' + (res ? res.error : 'Unknown error'));
        }
        $('#phoneStatusTable').bootstrapTable('refresh');
      });
    });
    showRetryFailedBtn();
  });

  function diagnosticsEsc(value) {
    return $('<div>').text(value == null || value === '' ? '—' : value).html();
  }

  function loadDeviceDiagnostics(mac, active) {
    var loadingText = active ? 'Running fresh ARP verification...' : 'Loading diagnostics...';
    $('#deviceDiagnosticsBody').html('<p class="text-muted"><i class="fa fa-spinner fa-spin"></i> ' + loadingText + '</p>');
    $('#runFreshDiagnosticsBtn').prop('disabled', true);
    $.ajax({
      url: 'ajax.php?module=provisioner&command=getDeviceDiagnostics',
      type: 'POST',
      data: { module: 'provisioner', mac: mac, active: active ? 1 : 0 },
      dataType: 'json',
      timeout: active ? 30000 : 8000
    }).done(function (res) {
      $('#runFreshDiagnosticsBtn').prop('disabled', false);
      if (!res || !res.success) {
        $('#deviceDiagnosticsBody').html('<div class="alert alert-danger">' + diagnosticsEsc(res ? res.error : 'Diagnostics request failed') + '</div>');
        return;
      }
      var device = res.device || {};
      var target = res.target || {};
      var service = res.service || {};
      var config = res.config || {};
      var lastPush = res.last_push || {};
      var arpUnavailable = target.resolution_mode === 'cross_subnet' || target.resolution_mode === 'cross_subnet_configured';
      $('#runFreshDiagnosticsBtn')
        .prop('disabled', arpUnavailable)
        .attr('title', arpUnavailable ? 'ARP verification is only available for devices on a directly connected subnet.' : 'Run an active local subnet sweep and verify the phone MAC in ARP.')
        .html(arpUnavailable ? '<i class="fa fa-ban"></i> ARP Unavailable (Cross-Subnet)' : '<i class="fa fa-refresh"></i> Run Fresh ARP Check');
      var selected = target.selected_ip ? diagnosticsEsc(target.selected_ip) + ' <span class="label label-primary">' + diagnosticsEsc(target.selected_source) + '</span>' : '<span class="text-danger">No valid target</span>';
      var html = target.conflict ? '<div class="alert alert-danger"><strong>Extension/MAC conflict:</strong> ' + diagnosticsEsc(target.conflict_message) + ' Push is blocked until the mapping agrees.</div>' : '';
      html += '<div class="row"><div class="col-md-6"><dl class="dl-horizontal">' +
        '<dt>MAC</dt><dd>' + diagnosticsEsc(device.mac) + '</dd>' +
        '<dt>Extension</dt><dd>' + diagnosticsEsc(device.extension) + '</dd>' +
        '<dt>Brand</dt><dd>' + diagnosticsEsc(device.brand) + '</dd>' +
        '<dt>Selected Target</dt><dd>' + selected + (target.is_stale_fallback ? ' <span class="label label-warning">stale fallback</span>' : '') + '</dd>' +
        '<dt>Confidence</dt><dd>' + diagnosticsEsc(target.confidence) + '</dd>' +
        '<dt>Resolution Mode</dt><dd>' + diagnosticsEsc(target.resolution_mode) + '</dd>' +
        '<dt>ARP Verification</dt><dd>' + (target.scan_performed ? 'Fresh scan: ' + diagnosticsEsc((target.scan_subnets || []).join(', ')) : '<span class="text-muted">Not run</span>') + '</dd>' +
        '<dt>PJSIP</dt><dd>' + diagnosticsEsc(target.pjsip_status) + '</dd>' +
        '<dt>Phone Service</dt><dd>' + (service.reachable ? '<span class="text-success">TCP ' + diagnosticsEsc(service.port) + ' reachable</span>' : '<span class="text-danger">TCP ' + diagnosticsEsc(service.port) + ' unavailable</span>') + '</dd>' +
        '</dl></div><div class="col-md-6"><dl class="dl-horizontal">' +
        '<dt>Config File</dt><dd>' + diagnosticsEsc(config.filename) + '</dd>' +
        '<dt>Config State</dt><dd>' + (config.exists ? diagnosticsEsc(config.size) + ' bytes, ' + diagnosticsEsc(config.modified) + (config.valid ? ' <span class="label label-success">valid</span>' : ' <span class="label label-danger">invalid</span>') : '<span class="text-muted">Not generated</span>') + (config.custom ? ' <span class="label label-info">custom</span>' : '') + '</dd>' +
        '<dt>Provisioning URL</dt><dd><code>' + diagnosticsEsc(res.provisioning_url) + '</code></dd>' +
        '<dt>Last Push</dt><dd>' + diagnosticsEsc(lastPush.status) + '</dd>' +
        '<dt>Last Attempt</dt><dd>' + diagnosticsEsc(lastPush.attempt) + '</dd>' +
        '<dt>Last ACK</dt><dd>' + diagnosticsEsc(lastPush.ack) + '</dd>' +
        '</dl></div></div>';
      html += '<h5>IP Candidates</h5><div class="table-responsive"><table class="table table-condensed table-striped"><thead><tr><th>Source</th><th>IP</th><th>Status</th></tr></thead><tbody>';
      (target.candidates || []).forEach(function (candidate) {
        var state;
        if (candidate.eligible === false) state = '<span class="text-warning">Ignored: ' + diagnosticsEsc(candidate.ignored_reason) + '</span>';
        else state = candidate.valid ? '<span class="text-success">Valid private IP</span>' : '<span class="text-danger">Rejected</span>';
        if (candidate.selected) state += ' <span class="label label-primary">selected</span>';
        if (candidate.stale) state += ' <span class="label label-warning">last-known</span>';
        html += '<tr><td>' + diagnosticsEsc(candidate.label) + '</td><td><code>' + diagnosticsEsc(candidate.ip) + '</code></td><td>' + state + '</td></tr>';
      });
      if (!target.candidates || target.candidates.length === 0) html += '<tr><td colspan="3" class="text-muted">No IP candidates found.</td></tr>';
      html += '</tbody></table></div>';
      if (!service.fetch_supported) html += '<div class="alert alert-warning">Config fetch is not supported for this brand.</div>';
      $('#deviceDiagnosticsBody').html(html);
    }).fail(function (xhr, status) {
      $('#runFreshDiagnosticsBtn')
        .prop('disabled', false)
        .attr('title', 'Retry fresh ARP verification.')
        .html('<i class="fa fa-refresh"></i> Run Fresh ARP Check');
      var message = status === 'timeout' ? 'Diagnostics timed out. Try the quick view again or verify the configured scan subnet.' : 'Diagnostics request failed.';
      $('#deviceDiagnosticsBody').html('<div class="alert alert-danger">' + diagnosticsEsc(message) + '</div>');
    });
  }

  $(document).off('click.provisionerDiagnostics', '.diagnostics-btn').on('click.provisionerDiagnostics', '.diagnostics-btn', function () {
    var mac = $(this).data('mac');
    $('#deviceDiagnosticsTitle').text('Device Diagnostics — ' + mac);
    $('#runFreshDiagnosticsBtn')
      .data('mac', mac)
      .prop('disabled', true)
      .attr('title', 'Loading device resolution mode...')
      .html('<i class="fa fa-refresh"></i> Run Fresh ARP Check');
    $('#deviceDiagnosticsModal').modal('show');
    loadDeviceDiagnostics(mac, false);
  });

  $('#runFreshDiagnosticsBtn').off('click').on('click', function () {
    var mac = $(this).data('mac');
    if (mac) loadDeviceDiagnostics(mac, true);
  });

  $('#rebootSelectedBtn').off('click').on('click', function () {
    if (selectedExtensions.length === 0) return;
    var allRows = $('#phoneStatusTable').bootstrapTable('getData', { unfiltered: true });
    var onlineExts = [];
    $.each(allRows, function (i, r) {
      if ((r.status === 'Registered' || r.status === 'Online' || r.status === 'Reboot Required' || r.status === 'Apply Pending') && selectedExtensions.indexOf(r.extension) !== -1) {
        onlineExts.push(r.extension);
      }
    });
    if (onlineExts.length === 0) {
      showAlert('warning', 'No selected phones are online and eligible for reboot.');
      return;
    }
    var skipped = selectedExtensions.length - onlineExts.length;
    var msg = 'Reboot ' + onlineExts.length + ' phone(s)?';
    if (skipped > 0) msg += ' (' + skipped + ' offline phone(s) will be skipped.)';
    showConfirm('Reboot Extensions', msg, function () {
      ajax('rebootPhones', { extensions: onlineExts }, function (res) {
        if (res && res.success) {
          showAlert('success', 'Reboot sent to ' + onlineExts.length + ' phone(s).');
          $('#phoneStatusTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Reboot failed.');
        }
      });
    });
  });

  function showRetryFailedBtn() {
    var allRows = $('#phoneStatusTable').bootstrapTable('getData', { unfiltered: true });
    var hasFailed = false;
    $.each(allRows, function (i, r) {
      if (r.push_status && r.push_status.indexOf('Failed') !== -1) {
        hasFailed = true;
        return false;
      }
    });
    $('#retryFailedBtn').toggle(hasFailed);
  }

  $('#retryFailedBtn').off('click').on('click', function () {
    var allRows = $('#phoneStatusTable').bootstrapTable('getData', { unfiltered: true });
    var failedMacs = [];
    $.each(allRows, function (i, r) {
      if (r.push_status && r.push_status.indexOf('Failed') !== -1) {
        failedMacs.push(r.mac);
      }
    });
    if (failedMacs.length === 0) return;
    showConfirm('Retry Push', 'Retry push for ' + failedMacs.length + ' failed phone(s)?', function () {
      $('#retryFailedBtn').prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Retrying...');
      ajax('retryPushForPhones', { macs: failedMacs }, function (res) {
        $('#retryFailedBtn').prop('disabled', false).html('<i class="fa fa-repeat"></i> Retry Failed');
        if (res && res.success) {
          var sent = (res.sent || []).length;
          var failed = (res.failed || []).length;
          showAlert('success', 'Retry done. ' + sent + ' sent, ' + failed + ' failed.');
        } else {
          showAlert('danger', 'Retry failed: ' + (res ? res.error : 'Unknown error'));
        }
        $('#phoneStatusTable').bootstrapTable('refresh');
      });
    });
  });

  // MAC Mapping — bulk delete
  onTableSelect('devicesTable', 'id', selectedDeviceIds, true);

  $('#devicesTable').on('post-body.bs.table', function () {
    $('.edit-device-btn').off('click').on('click', function () {
      $('#deviceModalTitle').text('Edit Device');
      $('#deviceId').val($(this).data('id'));
      var curExt = $(this).attr('data-ext');
      $('#deviceMac').val($(this).data('mac'));
      $('#deviceBrand').val($(this).data('brand'));
      $('#deviceDescription').val($(this).data('desc'));
      var staticIp = $(this).data('static-ip') || '';
      if (staticIp) {
        $('#deviceIpMode').val('static');
        $('#staticFields').show();
      } else {
        $('#deviceIpMode').val('dhcp');
        $('#staticFields').hide();
      }
      $('#deviceStaticIp').val(staticIp);
      $('#deviceStaticMask').val($(this).data('static-mask') || '').trigger('input');
      $('#deviceStaticGw').val($(this).data('static-gw') || '');
      $('#deviceModalError').hide();
      loadExtensions(curExt, function () { $('#deviceModal').modal('show'); });
    });
    $('.revert-device-btn').off('click').on('click', function () {
      if ($(this).data('digium-busy')) return;
      var id = $(this).data('id');
      showConfirm('Revert Device', 'Restore this device to its previous values?', function () {
        ajax('revertDevice', { id: id }, function (res) {
          if (res && res.success) {
            showAlert('success', 'Device reverted.');
            $('#devicesTable').bootstrapTable('refresh');
            loadPendingCount();
          } else {
            showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
    });
    $('.delete-device-btn').off('click').on('click', function () {
      var btn = $(this);
      if (btn.data('digium-busy')) return;
      var id = $(this).data('id');
      var ext = $(this).data('ext');
      showConfirm('Delete Device', 'Delete extension ' + ext + '? This cannot be undone.', function () {
        btn.data('digium-busy', true);
        ajax('deleteDevice', { id: id }, function (res) {
          btn.data('digium-busy', false);
          if (res && res.success) {
            showAlert('success', 'Device deleted.');
            $('#devicesTable').bootstrapTable('refresh');
            $('#phoneStatusTable').bootstrapTable('refresh');
            loadPendingCount();
          } else {
            showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
    });
  });

  // Config Files — bulk delete
  onTableSelect('configFilesTable', 'mac', selectedConfigMacs, true);
  var individualConfigFetches = {};
  var configModalRequestSequence = 0;
  var savingActiveConfig = false;

  $('#configFilesTable').on('post-body.bs.table', function () {
    $('.edit-config-btn').off('click').on('click', function () {
      var mac = $(this).data('mac');
      var ext = $(this).data('ext');
      var token = ++configModalRequestSequence;
      $('#configEditModal').data('configExt', ext);
      $('#configEditModal').data('requestToken', token);
      $('#configEditMac').val(mac);
      $('#configEditTitle').text('Edit Config File — ' + mac);
      $('#configEditContent').val('Loading...');
      $('#configEditModal').modal('show');
      ajax('getConfigFileContent', { mac: mac }, function (res) {
        if ($('#configEditModal').data('requestToken') !== token || $('#configEditMac').val() !== mac) return;
        if (res && res.success) {
          $('#configEditContent').val(res.content);
          $('#configEditModal').data('configExt', res.extension);
        } else {
          $('#configEditContent').val('Error loading config.');
        }
      });
    });
    $('.delete-config-btn').off('click').on('click', function () {
      var btn = $(this);
      if (btn.data('digium-busy')) return;
      var mac = $(this).data('mac');
      showConfirm('Delete Config File', 'Delete config for ' + mac + '? (MAC Mapping entries will not be deleted.)', function () {
        btn.data('digium-busy', true);
        ajax('deleteConfigFile', { mac: mac }, function (res) {
          btn.data('digium-busy', false);
          if (res && res.success) {
            showAlert('success', 'Deleted ' + mac + '.cfg');
            $('#configFilesTable').bootstrapTable('refresh');
          } else {
            showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
    });
    $('.fetch-config-btn').off('click').on('click', function () {
      var btn = $(this);
      var mac = $(this).data('mac');
      if (individualConfigFetches[mac]) {
        showAlert('info', 'A config fetch is already in progress for ' + mac + '.');
        return;
      }
      var token = ++configModalRequestSequence;
      individualConfigFetches[mac] = token;
      btn.data('original-html', btn.html()).addClass('disabled').html('<i class="fa fa-spinner fa-spin"></i>');
      $('#configEditMac').val(mac);
      $('#configEditTitle').text('Config from Phone — ' + mac + ' (Loading...)');
      $('#configEditContent').val('Fetching config from phone...').prop('readonly', true);
      $('#saveConfigBtn').hide();
      $('#saveActiveConfigBtn').hide();
      $('#configEditAlert').remove();
      $('#configEditModal').data('requestToken', token).modal('show');
      $.ajax({
        url: 'ajax.php?module=provisioner&command=fetchPhoneConfig',
        type: 'POST',
        data: { mac: mac },
        dataType: 'json',
        timeout: 120000
      }).done(function (res) {
        if ($('#configEditModal').data('requestToken') !== token || $('#configEditMac').val() !== mac) return;
        if (res && res.success) {
          var fetchState = res.session_reused ? 'session reused' : 'new session';
          $('#configEditTitle').text('Config from Phone — ' + mac + ' (' + fetchState + ')');
          $('#configEditContent').val(res.config).prop('readonly', true);
          $('#saveActiveConfigBtn').show().data('mac', mac);
        } else {
          var error = res ? res.error : 'Unknown error';
          var hint = /auth|credential|password/i.test(error) ? '\n\nCheck Phone Admin credentials in Settings.' : '\n\nWait briefly before retrying if the phone reports that its web interface is busy.';
          $('#configEditTitle').text('Config from Phone — ' + mac + ' (Failed)');
          $('#configEditContent').val('Failed to fetch config:\n' + error + hint).prop('readonly', true);
        }
      }).fail(function (xhr) {
        if ($('#configEditModal').data('requestToken') !== token || $('#configEditMac').val() !== mac) return;
        var error = xhr.statusText === 'timeout' ? 'Fetch timed out. The phone may be busy; wait before retrying.' : 'HTTP request failed.';
        $('#configEditTitle').text('Config from Phone — ' + mac + ' (Failed)');
        $('#configEditContent').val(error).prop('readonly', true);
      }).always(function () {
        if (individualConfigFetches[mac] === token) delete individualConfigFetches[mac];
        btn.removeClass('disabled').html(btn.data('original-html') || '<i class="fa fa-download"></i>');
      });
    });
    $('.revert-config-btn').off('click').on('click', function () {
      var btn = $(this);
      if (btn.data('digium-busy')) return;
      var mac = $(this).data('mac');
      showConfirm('Revert to Template', 'Restore the backed-up config (if available) and revert to template-generated config for next push?', function () {
        btn.data('digium-busy', true);
        ajax('revertConfigTemplate', { mac: mac }, function (res) {
          btn.data('digium-busy', false);
          if (res && res.success) {
            showAlert('success', res.message);
            $('#configFilesTable').bootstrapTable('refresh');
          } else {
            showAlert('danger', 'Revert failed: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
    });
    $('.restore-pulled-btn').off('click').on('click', function () {
      var btn = $(this);
      if (btn.data('digium-busy')) return;
      var mac = btn.data('mac');
      btn.data('digium-busy', true);
      ajax('getCustomBackupInfo', { mac: mac }, function (info) {
        if (!info || !info.success) {
          btn.data('digium-busy', false);
          showAlert('danger', 'Restore failed: ' + (info ? info.error : 'Unknown error'));
          return;
        }
        btn.data('digium-busy', false);
        var esc = function (value) { return $('<div>').text(value === null || value === undefined ? 'Unknown' : String(value)).html(); };
        var mismatch = !info.extension_matches;
        var message = '<p>Restore the archived pulled config for <strong>' + esc(mac) + '</strong>?</p>'
          + '<dl class="dl-horizontal">'
          + '<dt>Archive</dt><dd>' + esc(info.file) + '</dd>'
          + '<dt>Archived extension</dt><dd>' + esc(info.archived_extension) + '</dd>'
          + '<dt>Current extension</dt><dd>' + esc(info.current_extension) + '</dd>'
          + '<dt>Modified</dt><dd>' + esc(info.modified) + '</dd>'
          + '</dl>'
          + '<p>The active generated config will be saved as <code>.bak</code>. The pulled archive will be preserved.</p>';
        if (mismatch) message += '<div class="alert alert-warning">The archived and current extensions do not match. Continuing will require a second confirmation.</div>';
        showConfirm('Restore Pulled Config', message, function () {
          btn.data('digium-busy', true);
          restorePulledConfig(btn, mac, false);
        }, null, 'Continue');
      });
    });
  });

  function restorePulledConfig(btn, mac, force) {
    ajax('restoreCustomBackup', { mac: mac, force: force ? 1 : 0 }, function (res) {
      if (res && res.requires_confirmation && !force) {
        btn.data('digium-busy', false);
        var archived = $('<div>').text(res.archived_extension === null ? 'Unknown' : String(res.archived_extension)).html();
        var current = $('<div>').text(res.current_extension === null ? 'Unknown' : String(res.current_extension)).html();
        var warning = '<div class="alert alert-danger"><strong>High-risk restore:</strong> The archive is for extension <strong>'
          + archived + '</strong>, but this phone is currently mapped to <strong>' + current + '</strong>.</div>'
          + '<p>Force restoration anyway? The phone may register with the archived account until the config is corrected.</p>';
        showConfirm('Confirm Extension Mismatch', warning, function () {
          btn.data('digium-busy', true);
          restorePulledConfig(btn, mac, true);
        }, null, 'Force Restore');
        return;
      }
      btn.data('digium-busy', false);
      if (res && res.success) {
        showAlert('success', res.message);
        $('#configFilesTable').bootstrapTable('refresh');
        $('#devicesTable').bootstrapTable('refresh');
        loadPendingCount();
      } else {
        showAlert('danger', 'Restore failed: ' + (res ? res.error : 'Unknown error'));
      }
    });
  }

  $('#deleteSelectedConfigBtn').off('click').on('click', function () {
    if (selectedConfigMacs.length === 0) return;
    showConfirm('Delete Configs', 'Delete ' + selectedConfigMacs.length + ' config file(s)? (MAC Mapping entries will not be deleted.)', function () {
      ajax('deleteSelectedConfigFiles', { macs: selectedConfigMacs }, function (res) {
        if (res && res.success) {
          showAlert('success', 'Deleted ' + res.deleted + ' file(s).');
          $('#configFilesTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  $('#pullSelectedConfigBtn').off('click').on('click', function () {
    if (selectedConfigMacs.length === 0) return;
    showConfirm('Pull Configs', 'Download config from ' + selectedConfigMacs.length + ' phone(s) and override their template configs? Current configs will be backed up. Only one backup kept per phone.', function () {
      ajax('pullSelectedConfigFiles', { macs: selectedConfigMacs }, function (res) {
        if (res && res.success) {
          var msg = 'Config pulled from ' + res.pulled + ' phone(s).';
          if (res.errors.length) msg += ' ' + res.errors.length + ' failed.';
          showAlert('success', msg);
          $('#configFilesTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Pull failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  $('#revertSelectedConfigBtn').off('click').on('click', function () {
    if (selectedConfigMacs.length === 0) return;
    showConfirm('Revert Configs', 'Restore backed-up config for ' + selectedConfigMacs.length + ' device(s) and revert to template-generated config?', function () {
      ajax('revertSelectedConfigFiles', { macs: selectedConfigMacs }, function (res) {
        if (res && res.success) {
          var msg = 'Reverted ' + res.reverted + ' device(s).';
          if (res.errors.length) msg += ' ' + res.errors.length + ' failed.';
          showAlert('success', msg);
          $('#configFilesTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Revert failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  $('#saveActiveConfigBtn').off('click').on('click', function () {
    if (savingActiveConfig) return;
    var btn = $(this);
    var mac = $(this).data('mac');
    var content = $('#configEditContent').val();
    showConfirm('Override Active Config', 'Override the current ' + mac + '.cfg with the config from phone? Current file will be backed up.', function () {
      if (savingActiveConfig) return;
      savingActiveConfig = true;
      btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Saving...');
      ajax('saveAsActiveConfig', { mac: mac, content: content }, function (res) {
        savingActiveConfig = false;
        btn.prop('disabled', false).html('<i class="fa fa-save"></i> Override Active Config');
        if (res && res.success) {
          showAlert('success', res.message);
          $('#configFilesTable').bootstrapTable('refresh');
          $('#configEditModal').modal('hide');
        } else {
          showAlert('danger', 'Save failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  $('#configEditModal').on('hidden.bs.modal', function () {
    $(this).removeData('requestToken');
    $('#saveActiveConfigBtn').hide();
    $('#saveConfigBtn').show();
    $('#configEditContent').prop('readonly', false);
  });

  $('#saveConfigBtn').off('click').on('click', function () {
    var mac = $('#configEditMac').val();
    var content = $('#configEditContent').val();
    ajax('saveConfigFile', {
      mac: mac,
      content: content
    }, function (res) {
      if (res && res.success) {
        showAlert('success', 'Config file saved.');
        $('#configFilesTable').bootstrapTable('refresh');
        var cfgExt = $('#configEditModal').data('configExt');
        if (cfgExt) {
            showConfirm('Push & Reboot', 'Reboot extension ' + cfgExt + ' now to load the new config?', function () {
            ajax('rebootPhone', { extension: cfgExt }, function (r) {
              if (r && r.success) {
                showAlert('success', 'Reboot sent to extension ' + cfgExt);
              } else {
                showAlert('danger', 'Reboot failed for extension ' + cfgExt);
              }
            });
          });
        }
      } else {
        showAlert('danger', 'Save failed: ' + (res ? res.error : 'Unknown error'));
      }
    });
  });

  // =====================
  // REFRESH
  // =====================
  $('#refreshPhoneBtn').off('click').on('click', function () {
    $('#phoneStatusTable').bootstrapTable('refresh');
    loadPendingCount();
  });

  function startLiveRefresh() {
    if (liveInterval) clearInterval(liveInterval);
    autoRefreshCountdown = 5;
    $('#liveToggleBtn').removeClass('btn-secondary').addClass('btn-success').html('<i class="fa fa-refresh fa-spin"></i> Auto-Refresh ' + autoRefreshCountdown + 's').data('active', true).attr('title', 'Auto-refreshing every 5 seconds. Click to stop.');
    refreshPhoneTable();
    liveInterval = setInterval(function () {
      if ($('.modal.show').length > 0 || $('.bootbox.modal').length > 0) return;
      autoRefreshCountdown--;
      if (autoRefreshCountdown < 1) {
        autoRefreshCountdown = 5;
        refreshPhoneTable();
      }
      $('#liveToggleBtn').html('<i class="fa fa-refresh fa-spin"></i> Auto-Refresh ' + autoRefreshCountdown + 's');
    }, 1000);
  }

  function stopLiveRefresh() {
    if (liveInterval) {
      clearInterval(liveInterval);
      liveInterval = null;
    }
    $('#liveToggleBtn').removeClass('btn-success').addClass('btn-secondary').html('<i class="fa fa-refresh"></i> Auto-Refresh').data('active', false).attr('title', 'Auto-refresh the table every 5 seconds');
  }

  function refreshPhoneTable() {
    $('#phoneStatusTable').bootstrapTable('refresh');
    loadPendingCount();
  }

  $('#liveToggleBtn').off('click').on('click', function () {
    if ($(this).data('active')) {
      stopLiveRefresh();
    } else {
      startLiveRefresh();
    }
  });

  // =====================
  // REBOOT ALL
  // =====================
  $('#rebootAllBtn').off('click').on('click', function () {
    var rows = $('#phoneStatusTable').bootstrapTable('getData', { unfiltered: true });
    var exts = [];
    $.each(rows, function (i, r) {
      if (r.status === 'Registered' || r.status === 'Online' || r.status === 'Reboot Required' || r.status === 'Apply Pending') {
        exts.push(r.extension);
      }
    });
    if (exts.length === 0) {
      showAlert('info', 'No phones to reboot.');
      return;
    }
    showConfirm('Reboot All Phones', 'Are you sure you want to reboot ALL phones listed below?', function () {
      ajax('rebootPhones', { extensions: exts }, function (res) {
        if (res && res.success) {
          showAlert('success', 'Reboot sent to ' + exts.length + ' phone(s).');
          $('#phoneStatusTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Reboot failed.');
        }
      });
    });
  });

  // =====================
  // ADD / EDIT DEVICE
  // =====================
  function loadExtensions(selectedExt, callback) {
    var sel = $('#deviceExtension');
    sel.empty().append('<option value="">Loading extensions...</option>');
    ajax('getExtensions', {}, function (exts) {
      sel.empty().append('<option value="">-- Select Extension --</option>');
      if (exts && exts.length) {
        $.each(exts, function (i, e) {
          var opt = $('<option>').val(e.extension).text(e.extension + ' (' + e.name + ')');
          if (selectedExt && e.extension === selectedExt) opt.prop('selected', true);
          sel.append(opt);
        });
      }
      if (callback) callback();
    });
  }

  $('#addDeviceBtn').off('click').on('click', function () {
    $('#deviceModalTitle').text('Add Device');
    $('#deviceId').val('');
    $('#deviceMac').val('');
    $('#deviceBrand').val($('#deviceBrand option:first').val());
    $('#deviceDescription').val('');
    $('#deviceIpMode').val('dhcp');
    $('#staticFields').hide();
    $('#deviceStaticIp').val('');
    $('#deviceStaticMask').val('');
    $('#deviceStaticGw').val('');
    $('#deviceModalError').hide();
    loadExtensions('', function () { $('#deviceModal').modal('show'); });
  });

  function cidrToMask(val) {
    if (!val) return null;
    if (/^\d{1,2}$/.test(val)) {
      var n = parseInt(val);
      if (n >= 0 && n <= 32) {
        var mask = ~(Math.pow(2, 32 - n) - 1) >>> 0;
        return [(mask >>> 24), (mask >> 16 & 255), (mask >> 8 & 255), (mask & 255)].join('.');
      }
    }
    return val;
  }

  function maskToCidr(val) {
    if (!val) return '';
    if (/^\d{1,2}$/.test(val)) return val;
    var parts = val.split('.').map(Number);
    if (parts.length !== 4 || parts.some(function(p) { return isNaN(p) || p < 0 || p > 255; })) return '';
    var bin = parts.map(function(p) { return (p >>> 0).toString(2).padStart(8, '0'); }).join('');
    if (!/^1+0*$/.test(bin)) return '';
    return bin.indexOf('0') === -1 ? '32' : String(bin.indexOf('0'));
  }

  $('#deviceIpMode').on('change', function () {
    $('#staticFields').toggle($(this).val() === 'static');
  });

  $('#maskPresets').on('change', function () {
    if ($(this).val()) {
      $('#deviceStaticMask').val($(this).val());
    }
  });

  $('#deviceStaticMask').on('input', function () {
    var cidr = maskToCidr($(this).val());
    $('#maskPresets').val(cidr || '');
  });

  var saving = false;
  $('#saveDeviceBtn').off('click').on('click', function () {
    if (saving) return;
    var id   = $('#deviceId').val();
    var mac  = $('#deviceMac').val().trim();
    var ext  = $('#deviceExtension').val().trim();
    var brand = $('#deviceBrand').val();
    var desc = $('#deviceDescription').val().trim();
    if (!mac || !ext) {
      $('#deviceModalError').text('MAC address and extension are required.').show();
      return;
    }
    saving = true;
    var command = id ? 'updateDevice' : 'addDevice';
    var isStatic = $('#deviceIpMode').val() === 'static';
    var staticIp  = isStatic ? $('#deviceStaticIp').val().trim() || null : null;
    var staticMask = isStatic ? cidrToMask($('#deviceStaticMask').val().trim()) : null;
    var staticGw  = isStatic ? $('#deviceStaticGw').val().trim() || null : null;
    var data    = { mac: mac, extension: ext, description: desc, brand: brand, static_ip: staticIp, static_mask: staticMask, static_gw: staticGw };
    if (id) data.id = id;
    ajax(command, data, function (res) {
      saving = false;
      if (res && res.success) {
        $('#deviceModal').modal('hide');
        showAlert('success', 'Device saved. Use Push Config to generate configs and reboot.');
        $('#devicesTable').bootstrapTable('refresh');
        loadPendingCount();
      } else {
        $('#deviceModalError').text('Error: ' + (res ? res.error : 'Unknown error')).show();
      }
    });
  });

  // =====================
  // DISCARD ALL
  // =====================
  var discarding = false;
  $('#discardAllBtn').off('click').on('click', function () {
    if (discarding) return;
    showConfirm('Discard All Changes', 'Revert ALL pending devices to their previous values? This cannot be undone.', function () {
      discarding = true;
      ajax('discardAllChanges', {}, function (res) {
        discarding = false;
        if (res && res.success) {
          showAlert('success', 'Discarded changes for ' + res.affected + ' device(s).');
          $('#devicesTable').bootstrapTable('refresh');
          loadPendingCount();
        } else {
          showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  // =====================
  // DELETE SELECTED
  // =====================
  $('#deleteSelectedBtn').off('click').on('click', function () {
    if (selectedDeviceIds.length === 0) return;
    showConfirm('Delete Devices', 'Delete ' + selectedDeviceIds.length + ' device(s)? This cannot be undone.', function () {
      ajax('deleteDevices', { ids: selectedDeviceIds }, function (res) {
        if (res && res.success) {
          showAlert('success', 'Deleted ' + res.deleted + ' device(s).');
          $('#devicesTable').bootstrapTable('refresh');
          $('#phoneStatusTable').bootstrapTable('refresh');
          loadPendingCount();
        } else {
          showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  // =====================
  // AUTO-ASSIGN EXTENSIONS
  // =====================
  $('#autoAssignBtn').off('click').on('click', function () {
    var btn = $(this);
    btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Loading...');
    ajax('autoAssignExtensions', {}, function (res) {
      btn.prop('disabled', false).html('<i class="fa fa-magic"></i> Auto-Assign');
      if (!res || res.error) {
        showAlert('danger', res && res.error ? res.error : 'Auto-assign request failed.');
        return;
      }
      if (!res.success || !res.assignments || res.assignments.length === 0) {
        showAlert('info', 'No devices without extensions to assign.');
        return;
      }
      var html = '<p>Assign the following extensions?</p><table class="table table-condensed"><thead><tr><th>MAC</th><th>Extension</th></tr></thead><tbody>';
      $.each(res.assignments, function (i, a) {
        html += '<tr><td>' + a.mac + '</td><td><strong>' + a.extension + '</strong></td></tr>';
      });
      html += '</tbody></table>';
      showConfirm('Auto-Assign Extensions (' + res.assignments.length + ')', html, function () {
        btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Assigning...');
        ajax('autoAssignExtensions', { save: true }, function (res2) {
          btn.prop('disabled', false).html('<i class="fa fa-magic"></i> Auto-Assign');
          if (res2 && res2.success) {
            showAlert('success', 'Assigned ' + res2.assignments.length + ' extension(s). Review and start the pending config push.');
            $('#devicesTable').bootstrapTable('refresh');
            $('#phoneStatusTable').bootstrapTable('refresh');
            loadPendingCount(function () {
              selectedPushMacs = [];
              openApplyModal();
            });
          } else {
            showAlert('danger', 'Assignment failed: ' + (res2 ? res2.error : 'Unknown error'));
          }
        });
      });
    });
  });

  $('#discoverPjsipBtn').off('click').on('click', function () {
    if (!scanCompleted) {
      showAlert('warning', 'Run a scan first to discover devices.');
      return;
    }
    var btn = $(this);
    btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Matching...');
    ajax('autoDiscoverFromPjsip', {}, function (res) {
      btn.prop('disabled', false).html('<i class="fa fa-phone"></i> Discover from PJSIP');
      if (!res || !res.success) {
        showAlert('warning', res ? res.error : 'PJSIP discovery failed.');
        return;
      }
      var matches = res.matches || [];
      if (matches.length === 0) {
        showAlert('info', 'No PJSIP registrations matched devices in ARP.');
        return;
      }
      var updated = 0;
      $.each(matches, function (i, m) {
        var mac = String(m.mac || '').replace(/[^a-f0-9]/gi, '').toUpperCase();
        var row = discoveredRows.find(function (r) { return r.mac === mac; });
        if (row) {
          row.extension = m.extension;
          $('#discoveredTable').bootstrapTable('updateByUniqueId', { id: mac, row: { extension: m.extension } });
          updated++;
        }
      });
      var msg = 'Matched <strong>' + updated + '</strong> of ' + matches.length + ' PJSIP registration(s) to devices in the table.';
      showAlert('success', msg);
    });
  });

  // =====================
  // BULK HANDLER TAB PILLS
  // =====================
  $(document).on('click', '.bulk-pill', function (e) {
    e.preventDefault();
    var target = $(this).attr('href');
    $('.bulk-pill').removeClass('active');
    $('.bulk-pill').closest('li').removeClass('active');
    $(this).addClass('active');
    $(this).closest('li').addClass('active');
    $('#import .bulk-handler-section').hide();
    $(target).show();
  });

  // =====================
  // BULK IMPORT
  // =====================
  // File upload handler — read CSV into textarea
  $('#importCsvFile').off('change').on('change', function () {
    var file = this.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function (e) {
      $('#importCsv').val(e.target.result);
    };
    reader.readAsText(file);
  });

  $('#importBtn').off('click').on('click', function () {
    var csv = $('#importCsv').val().trim();
    if (!csv) { showAlert('danger', 'Please provide CSV content.'); return; }
    ajax('bulkImport', { csv_content: csv }, function (res) {
      if (!res || res.error) {
        showAlert('danger', res && res.error ? 'Import failed: ' + res.error : 'Import failed.');
        return;
      }
    if (res.success > 0) {
        if (res.errors && res.errors.length > 0) {
          var html = '<div class="alert alert-warning"><strong>' + res.success + ' device(s) imported successfully with errors:</strong><ul style="margin-top:8px;">';
          $.each(res.errors, function (i, err) { html += '<li>' + err + '</li>'; });
          html += '</ul></div>';
          $('#importResults').html(html).show();
        } else {
          showAlert('success', res.success + ' device(s) imported successfully.');
        }
        $('#devicesTable').bootstrapTable('refresh');
        loadPendingCount(function () { openApplyModal(); });
      } else {
        var errHtml = 'Import failed: no devices imported.';
        if (res.errors && res.errors.length > 0) {
          errHtml += '<ul style="margin-top:8px;">';
          $.each(res.errors, function (i, err) { errHtml += '<li>' + err + '</li>'; });
          errHtml += '</ul>';
        }
        $('#importResults').html('<div class="alert alert-danger">' + errHtml + '</div>').show();
        $('#devicesTable').bootstrapTable('refresh');
    }
    });
  });

  // =====================
  // EXPORT CSV
  // =====================
  $('#exportCsvBtn').off('click').on('click', function () {
    ajax('exportCsv', {}, function (res) {
      if (res && res.success && res.csv) {
        var blob = new Blob([res.csv], { type: 'text/csv;charset=utf-8;' });
        var link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'provisioner_devices.csv';
        link.click();
        setTimeout(function () { URL.revokeObjectURL(link.href); }, 200);
      } else {
        showAlert('danger', 'Export failed.');
      }
    });
  });

  // =====================
  // PUSH CONFIG MODAL
  // =====================
  var selectedPushMacs = [];

  function openApplyModal() {
    var selCount = selectedPushMacs.length;
    var count = parseInt($('#pendingBadge').text()) || 0;
    $('#applyResults').hide();
    $('#applyResultsContent').empty();
    $('#applyProgress').hide();
    $('#applyProgressBar').css('width', '0%').text('').addClass('progress-bar-striped active');
    $('#applyProgressText').text('Initializing...');
    $('#applyOkBtn').html('<i class="fa fa-check"></i> Push').prop('disabled', false).data('retry', false);

    if (selCount > 0) {
      $('#applyCountDesc').hide();
      $('#applySelectedDesc').show();
      $('#applyNoChangesDesc').hide();
      $('#applySelectedCount').text(selCount);
      $('#applyGenerateCfg').prop('checked', false).closest('.checkbox').hide();
      $('#applyProgress').hide();
      $('#applyOkBtn').prop('disabled', false);
      $('#applyRebootRow').hide();
      $('#applyNotifyRow').show();
      $('#applyNotifyPush').prop('checked', true);
      updatePushBtnState();
      $('#applyModal').modal('show');
      return;
    }

    if (count === 0) {
      ajax('getSettings', {}, function (data) {
        var mode = (data && data.deploy_mode) || 'dhcp';
        if (mode !== 'sip_notify') return;
        $('#applyCountDesc').hide();
        $('#applySelectedDesc').hide();
        $('#applyNoChangesDesc').show();
        $('#applyCount').text(0);
        $('#applyGenerateCfg').prop('checked', false).closest('.checkbox').hide();
        $('#applyProgress').hide();
        $('#applyOkBtn').prop('disabled', false);
        $('#applyRebootRow').hide();
        $('#applyNotifyRow').show();
        $('#applyNotifyPush').prop('checked', true);
        updatePushBtnState();
        $('#applyModal').modal('show');
      });
      return;
    }

    $('#applyCountDesc').show();
    $('#applySelectedDesc').hide();
    $('#applyNoChangesDesc').hide();
    $('#applyCount').text(count);
    $('#applyGenerateCfg').prop('checked', true).closest('.checkbox').show();
    $('#applyProgress').hide();
    $('#applyOkBtn').prop('disabled', false);
    ajax('getSettings', {}, function (data) {
      var mode = (data && data.deploy_mode) || 'dhcp';
      if (mode === 'sip_notify') {
        $('#applyRebootRow').hide();
        $('#applyNotifyRow').show();
        $('#applyNotifyPush').prop('checked', true);
      } else {
        $('#applyRebootRow').show();
        $('#applyRebootPhones').prop('checked', pendingNeedsReboot).prop('disabled', false);
        $('#applyNotifyRow').hide();
      }
      updatePushBtnState();
      $('#applyModal').modal('show');
    });
  }

  $('#applyChangesBtn, #applyChangesPhoneBtn').off('click').on('click', function () {
    selectedPushMacs = [];
    var isPhoneBtn = $(this).is('#applyChangesPhoneBtn');
    if (isPhoneBtn) {
      var s = $('#phoneStatusTable').bootstrapTable('getSelections');
      $.each(s, function (i, row) { if (row.mac) selectedPushMacs.push(row.mac); });
    } else {
      var s = $('#devicesTable').bootstrapTable('getSelections');
      $.each(s, function (i, row) { if (row.mac_address) selectedPushMacs.push(row.mac_address); });
    }
    openApplyModal();
  });

  $('#applyModal').on('hidden.bs.modal', function () {
    selectedPushMacs = [];
    applying = false;
    $('#applyGenerateCfg').closest('.checkbox').show();
    $('#applyCountDesc').show();
    $('#applySelectedDesc').hide();
    $('#applyNoChangesDesc').hide();
    $('#applyOkBtn').html('<i class="fa fa-check"></i> Push');
    $('#applyResults').hide();
    $('#applyResultsContent').empty();
    $('#applyProgress').hide();
  });

  $('#applyModal').on('hide.bs.modal', function (event) {
    if (applying) event.preventDefault();
  });

  function updatePushBtnState() {
    var gen  = $('#applyGenerateCfg').is(':checked');
    var reboot = $('#applyRebootPhones').is(':checked');
    var notify = $('#applyNotifyPush').is(':checked');
    var anyAction = gen || reboot || notify;
    if ($('#applyNotifyRow').is(':visible')) {
      anyAction = gen || notify;
    }
    $('#applyOkBtn').prop('disabled', !anyAction);
  }

  $('#applyGenerateCfg, #applyRebootPhones, #applyNotifyPush').off('change').on('change', function () {
    updatePushBtnState();
  });

  function updateProgress(pct, text) {
    if (pct === null) {
      $('#applyProgressBar').css('width', '100%').text('Working...').addClass('progress-bar-striped active');
    } else {
      $('#applyProgressBar').css('width', pct + '%').text(pct + '%');
      if (pct >= 100) $('#applyProgressBar').removeClass('active');
    }
    $('#applyProgressText').text(text);
  }

  function showInlineResults(res) {
    var sent = res.notify_sent || res.sent || [];
    var failed = res.notify_failed || res.failed || [];
    var skipped = res.notify_skipped || res.skipped || [];
    var generated = res.generated || [];
    var html = '';
    if (sent.length > 0) {
      html += '<div class="alert alert-success" style="margin-bottom:8px;padding:8px 12px"><strong>NOTIFY sent</strong> — ' + sent.length + ' phone(s)</div>';
    }
    if (failed.length > 0) {
      var errMap = {};
      failed.forEach(function(f){ var e = f.error || 'unknown'; errMap[e] = (errMap[e] || 0) + 1; });
      var parts = Object.keys(errMap).map(function(e){ return errMap[e] > 1 ? e + ' (' + errMap[e] + ')' : e; });
      html += '<div class="alert alert-danger" style="margin-bottom:8px;padding:8px 12px"><strong>NOTIFY failed</strong> — ' + failed.length + ' phone(s): ' + parts.join(', ') + '</div>';
    }
    if (skipped.length > 0) {
      html += '<div class="alert alert-warning" style="margin-bottom:8px;padding:8px 12px"><strong>NOTIFY skipped</strong> — ' + skipped.length + ' phone(s): no valid private IP candidate</div>';
    }
    if (generated.length > 0) {
      html += '<p class="text-muted" style="margin-bottom:4px">Configs generated for ' + generated.length + ' device(s).</p>';
    }
    if (!html) html = '<p class="text-muted">No phones to notify.</p>';
    $('#applyResultsContent').html(html);
    $('#applyResults').show();
    if (failed.length > 0 || skipped.length > 0) {
      lastFailedMacs = failed.map(function(f){ return f.mac; }).filter(function(m){ return !!m; }).concat(skipped);
      if (lastFailedMacs.length > 0) {
        $('#applyOkBtn').prop('disabled', false).text('Retry (' + lastFailedMacs.length + ')').data('retry', true);
      } else {
        $('#applyOkBtn').prop('disabled', false).text('Close').data('retry', false);
      }
    } else {
      $('#applyOkBtn').prop('disabled', false).text('Close').data('retry', false);
    }
  }

  var applying = false;
  var lastFailedMacs = [];
  $('#applyOkBtn').off('click').on('click', function () {
    if ($(this).text() === 'Close') {
      $('#applyModal').modal('hide');
      return;
    }
    if ($('#applyOkBtn').data('retry')) {
      if (applying) return;
      applying = true;
      $('#applyOkBtn').prop('disabled', true);
      $('#applyProgress').show();
      updateProgress(null, 'Retrying ' + lastFailedMacs.length + ' failed phone(s)...');
      ajax('pushToPhones', { macs: lastFailedMacs }, function (res) {
        applying = false;
        $('#applyProgress').hide();
        if (res && res.success) {
          if (!$('#applyModal').is(':visible')) return;
          showInlineResults(res);
        } else {
          if (!$('#applyModal').is(':visible')) return;
          showInlineResults({ failed: lastFailedMacs.map(function(m){ return {mac: m, error: res ? res.error : 'Request failed'}; }) });
        }
        $('#devicesTable').bootstrapTable('refresh');
        $('#phoneStatusTable').bootstrapTable('refresh');
        loadPendingCount();
      });
      return;
    }
    if (applying) return;
    applying = true;
    $('#applyOkBtn').prop('disabled', true);
    $('#applyResults').hide();
    $('#applyProgress').show();
    var isSipNotify = $('#applyNotifyPush').length > 0 && $('#applyNotifyRow').is(':visible') && $('#applyNotifyPush').is(':checked');
    if (isSipNotify) {
      if (selectedPushMacs.length > 0) {
        updateProgress(null, 'Scanning and sending configs to selected phones...');
        ajax('pushToPhones', { macs: selectedPushMacs }, function (res) {
          applying = false;
          selectedPushMacs = [];
          $('#applyProgress').hide();
          if (res && res.success) {
            if (!$('#applyModal').is(':visible')) return;
            showInlineResults(res);
          } else {
            if (!$('#applyModal').is(':visible')) return;
            showInlineResults({ failed: [{ error: res ? res.error : 'Request failed' }] });
          }
          $('#devicesTable').bootstrapTable('refresh');
          $('#phoneStatusTable').bootstrapTable('refresh');
          loadPendingCount();
        });
      } else {
        updateProgress(null, 'Generating configs and notifying pending phones...');
        ajax('applyChangesWithNotify', {}, function (res) {
          applying = false;
          selectedPushMacs = [];
          $('#applyProgress').hide();
          if (!res || !res.success) {
            if (!$('#applyModal').is(':visible')) return;
            showInlineResults({ failed: [{ error: res ? res.error : 'Request failed' }] });
            $('#devicesTable').bootstrapTable('refresh');
            $('#phoneStatusTable').bootstrapTable('refresh');
            loadPendingCount();
            return;
          }
          if (!$('#applyModal').is(':visible')) return;
          showInlineResults(res);
          $('#devicesTable').bootstrapTable('refresh');
          $('#phoneStatusTable').bootstrapTable('refresh');
          loadPendingCount();
        });
      }
    } else {
      var generate = $('#applyGenerateCfg').is(':checked');
      var reboot = $('#applyRebootPhones').is(':checked');
      updateProgress(null, generate ? 'Generating configs and applying pending changes...' : 'Applying pending changes...');
      ajax('applyChanges', { generate: generate, reboot: reboot }, function (res) {
        applying = false;
        $('#applyProgress').hide();
        $('#applyOkBtn').prop('disabled', false);
        if (res && res.success) {
          var msg = 'Push completed.';
          if (res.generated && res.generated.length > 0) msg += ' Generated ' + res.generated.length + ' config(s).';
          if (res.reboots && res.reboots.length > 0) msg += ' Reboot sent to ' + res.reboots.length + ' phone(s).';
          if (res.skipped_reboot > 0) msg += ' Skipped reboot for ' + res.skipped_reboot + ' new device(s).';
          showAlert('success', msg);
          $('#applyModal').modal('hide');
          $('#devicesTable').bootstrapTable('refresh');
          $('#phoneStatusTable').bootstrapTable('refresh');
          loadPendingCount();
        } else {
          showAlert('danger', 'Push failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    }
  });

  // =====================
  // PROVISIONING INFO
  // =====================
  function provisioningCheckLoading(label) {
    return '<div class="alert alert-info" style="margin-top:10px;padding:8px 12px;min-height:38px;">' +
      '<i class="fa fa-spinner fa-spin"></i> <strong>' + label + '</strong></div>';
  }

  var provisioningLoadSequence = 0;
  function loadProvisioningInfo() {
    var loadToken = ++provisioningLoadSequence;
    $('#provInfoBody').html(
      '<div class="text-center text-muted" style="padding:30px 10px;">' +
      '<i class="fa fa-spinner fa-spin fa-2x"></i><p style="margin-top:10px;">Loading provisioning status...</p></div>'
    );
    ajax('getProvisioningInfo', {}, function (data) {
      if (loadToken !== provisioningLoadSequence) return;
      var html = '';
      if (!data || data.error) {
        html = '<div class="alert alert-danger"><strong>Unable to load provisioning status.</strong> ' + diagnosticsEsc((data && data.error) || 'Request failed') +
          ' <button type="button" class="btn btn-xs btn-default" id="retryProvisioningInfoBtn"><i class="fa fa-repeat"></i> Retry</button></div>';
        $('#provInfoBody').html(html);
        $('#retryProvisioningInfoBtn').off('click').on('click', loadProvisioningInfo);
        return;
      }
      ajax('getSettings', {}, function (settings) {
        if (loadToken !== provisioningLoadSequence) return;
        if (!settings || settings.error) {
          $('#provInfoBody').html(
            '<div class="alert alert-danger"><strong>Unable to load provisioning settings.</strong> ' + diagnosticsEsc((settings && settings.error) || 'Request failed') +
            ' <button type="button" class="btn btn-xs btn-default" id="retryProvisioningSettingsBtn"><i class="fa fa-repeat"></i> Retry</button></div>'
          );
          $('#retryProvisioningSettingsBtn').off('click').on('click', loadProvisioningInfo);
          return;
        }
        var mode = (settings && settings.deploy_mode) || 'dhcp';
        var showOption66 = (mode === 'dhcp');
        html += '<dl class="dl-horizontal">';
        html += '  <dt>PBX IP</dt><dd>' + data.pbx_ip + '</dd>';
        html += '  <dt>Provisioning URL</dt><dd><code>http://' + data.pbx_ip + ':2001/provisioning/</code>';
        if (showOption66) {
          html += ' <button class="btn btn-xs btn-default" onclick="copyProvUrl(\'http://' + data.pbx_ip + ':2001/provisioning/\')"><i class="fa fa-copy"></i> Copy</button>';
        }
        html += '</dd>';
        html += '  <div id="dhcpOption66Status">' + (showOption66 ? provisioningCheckLoading('Checking DHCP Option 66...') : '<div class="alert alert-info" style="margin-top:10px;padding:8px 12px;"><i class="fa fa-info-circle"></i> <strong>DHCP Option 66:</strong> Not applicable in SIP NOTIFY mode.</div>') + '</div>';
        html += '  <div id="firewallProvisioningStatus">' + provisioningCheckLoading('Checking FreePBX firewall zones...') + '</div>';
        html += '  <dt>Directory</dt><dd><code>' + data.prov_dir + '</code></dd>';
        var writableIcon = data.dir_writable === true ? '<span class="label label-success">Writable</span>' : (data.dir_writable === false ? '<span class="label label-danger">Not writable</span>' : '<span class="label label-warning">Missing</span>');
        html += '  <dt>Status</dt><dd>' + writableIcon + '</dd>';
        html += '  <dt>Device Configs</dt>';
        html += '  <dd><span id="provDeviceCount">' + data.device_count + '</span> file(s) &mdash; <a href="#" onclick="$(\'a[href=\\\'#configfiles\\\']\').tab(\'show\');return false;">View in Config Files</a></dd>';
        html += '</dl>';
        html += '<button class="btn btn-primary" id="generateAllConfigsBtn" style="margin-right:5px;"><i class="fa fa-cogs"></i> Generate All Configs</button>';
        html += '<button class="btn btn-danger" id="fixPermsBtn"><i class="fa fa-wrench"></i> Fix Permissions</button>';
        if (data.model_files && data.model_files.length > 0) {
          html += '<h5 style="margin-top:16px;">Model Files</h5>';
          html += '<table class="table table-condensed"><thead><tr><th>File</th><th>Size</th><th>Modified</th></tr></thead><tbody>';
          $.each(data.model_files, function (i, f) {
            html += '<tr><td><code>' + f.name + '</code></td><td>' + f.size + ' B</td><td>' + f.modified + '</td></tr>';
          });
          html += '</tbody></table>';
        }
        $('#provInfoBody').html(html);
        if (showOption66) {
         ajax('checkDhcpOption66', {}, function (res) {
        if (loadToken !== provisioningLoadSequence) return;
        var statusDiv = $('#dhcpOption66Status');
        if (!res || res.error) {
          statusDiv.html(
            '<div class="alert alert-danger" style="margin-top:10px;padding:8px 12px;">' +
            '<i class="fa fa-times-circle"></i> <strong>DHCP Option 66 check failed:</strong> ' + diagnosticsEsc((res && res.error) || 'Request failed') +
            ' <button type="button" class="btn btn-xs btn-default" id="retryDhcpCheckBtn"><i class="fa fa-repeat"></i> Retry</button></div>'
          );
          $('#retryDhcpCheckBtn').off('click').on('click', loadProvisioningInfo);
        } else if (res.set && res.correct) {
          statusDiv.html(
            '<div class="alert alert-success" style="margin-top:10px;padding:8px 12px;">' +
            '<i class="fa fa-check-circle"></i> ' +
            '<strong>DHCP Option 66 configured correctly:</strong> <code>' + res.value + '</code>' +
            '</div>'
          );
        } else if (res && res.set && !res.correct) {
          statusDiv.html(
            '<div class="alert alert-warning" style="margin-top:10px;padding:8px 12px;">' +
            '<i class="fa fa-exclamation-triangle"></i> ' +
            '<strong>Option 66 misconfigured:</strong> set to <code>' + res.value + '</code>, ' +
            'expected <code>' + res.expected + '</code>. Update in ' +
            '<a href="config.php?display=sysadmin&view=dhcpd" target="_blank">System Admin &rarr; DHCP Server</a>' +
            '</div>'
          );
        } else {
          statusDiv.html(
            '<div class="alert alert-warning" style="margin-top:10px;padding:8px 12px;">' +
            '<i class="fa fa-exclamation-triangle"></i> ' +
            '<strong>Requirement:</strong> DHCP Option 66 (next-server) must point to the provisioning URL above. Configure in ' +
            '<a href="config.php?display=sysadmin&view=dhcpd" target="_blank">System Admin &rarr; DHCP Server</a> ' +
            'for phones to auto-discover and download their config.' +
            '</div>'
          );
        }
      });
      }
      ajax('checkFirewallProvisioning', {}, function (res) {
          if (loadToken !== provisioningLoadSequence) return;
          var fwDiv = $('#firewallProvisioningStatus');
          if (!res || res.error || res.success === false) {
            fwDiv.html(
              '<div class="alert alert-danger" style="margin-top:10px;padding:8px 12px;">' +
              '<i class="fa fa-times-circle"></i> <strong>Firewall check failed:</strong> ' + diagnosticsEsc((res && res.error) || 'Request failed') +
              ' <button type="button" class="btn btn-xs btn-default" id="retryFirewallCheckBtn"><i class="fa fa-repeat"></i> Retry</button></div>'
            );
            $('#retryFirewallCheckBtn').off('click').on('click', loadProvisioningInfo);
          } else if (!res.blocked) {
            fwDiv.html(
              '<div class="alert alert-success" style="margin-top:10px;padding:8px 12px;">' +
              '<i class="fa fa-check-circle"></i> ' +
              '<strong>Firewall:</strong> ' + res.message +
              '</div>'
            );
          } else if (res && res.blocked) {
            fwDiv.html(
              '<div class="alert alert-warning" style="margin-top:10px;padding:8px 12px;">' +
              '<i class="fa fa-exclamation-triangle"></i> ' +
              '<strong>Firewall blocks provisioning:</strong> ' + res.message +
              '</div>'
            );
          } else {
            fwDiv.html(
              '<div class="alert alert-info" style="margin-top:10px;padding:8px 12px;">' +
              '<i class="fa fa-info-circle"></i> ' +
              '<strong>Firewall:</strong> Unable to determine provisioning status.' +
              '</div>'
            );
          }
        });
      function generateAllConfigs(replaceCustom) {
        var btn = $('#generateAllConfigsBtn');
        btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Generating...');
        ajax('generateAllConfigs', { replace_custom: replaceCustom ? 1 : 0 }, function (res) {
          btn.prop('disabled', false).html('<i class="fa fa-cogs"></i> Generate All Configs');
          if (res && res.requires_confirmation) {
            showConfirm(
              'Replace Pulled Configs',
              'Generate All will archive and replace <strong>' + res.custom_count + '</strong> pulled custom config(s) with Provisioner templates. Continue?',
              function () { generateAllConfigs(true); }
            );
            return;
          }
          if (res && res.success) {
            var message = 'Generated ' + res.generated + ' config file(s).';
            if (res.custom_replaced > 0) message += ' Archived and replaced ' + res.custom_replaced + ' custom config(s).';
            showAlert('success', message);
            loadProvisioningInfo();
            $('#configFilesTable').bootstrapTable('refresh');
          } else {
            showAlert('danger', 'Generation failed: ' + (res ? res.error : 'Unknown error'));
          }
        });
      }
      $('#generateAllConfigsBtn').off('click').on('click', function () {
        generateAllConfigs(false);
      });
      $('#fixPermsBtn').off('click').on('click', function () {
        ajax('generateProvisioning', {}, function (res) {
          if (res && res.success) showAlert('success', 'Permissions fixed.');
          else showAlert('danger', 'Failed: ' + (res ? res.output : 'Unknown error'));
        });
      });
    });
  });
  }

  // =====================
  // CONFIG FILES — DELETE ALL
  // =====================
  $('#deleteAllConfigBtn').off('click').on('click', function () {
    showConfirm('Delete All Config Files', 'Delete ALL generated config files? This cannot be undone. (MAC Mapping entries will not be deleted.)', function () {
      ajax('deleteAllConfigFiles', {}, function (res) {
        if (res && res.success) {
          showAlert('success', 'Deleted ' + res.deleted + ' config file(s).');
          $('#configFilesTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
  });

  // =====================
  // LOGS
  // =====================
  $('#clearLogsBtn').off('click').on('click', function () {
    showConfirm('Clear Logs', 'Are you sure you want to clear all logs?', function () {
      ajax('clearLogs', {}, function (res) {
        if (res && res.success) {
          showAlert('success', 'Logs cleared.');
          $('#logsTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Error clearing logs.');
        }
      });
    });
  });

  // =====================
  // SETTINGS
  // =====================
  var detectedSipTransports = {};
  var settingsInterfaces = [];
  var scanSubnetsManual = false;

  function updateAutoDetectedScanSubnet() {
    var option = $('#settingsInterfaceSelect option:selected');
    var subnet = option.data('subnet') || '';
    $('#settingsScanSubnets').val(subnet);
    $('#settingsScanDetection')
      .removeClass('text-warning').addClass('text-muted')
      .text(subnet ? 'Auto-detected from ' + (option.data('name') || 'the selected PBX interface') + ': ' + subnet : 'Select a PBX interface to detect its scan subnet.');
  }

  function loadSettingsInterfaces(pbxIp, savedScanSubnets) {
    ajax('getNetworkSubnets', {}, function (res) {
      var select = $('#settingsInterfaceSelect');
      select.empty().append('<option value="">— Select interface —</option>');
      settingsInterfaces = (res && res.interfaces) || [];
      $.each(settingsInterfaces, function (i, iface) {
        select.append($('<option>', { value: iface.ip, text: iface.label }).attr('data-subnet', iface.subnet).attr('data-name', iface.name));
      });
      if (pbxIp && select.find('option[value="' + pbxIp + '"]').length) select.val(pbxIp);
      var detectedSubnet = select.find('option:selected').data('subnet') || '';
      scanSubnetsManual = !!savedScanSubnets && $.trim(savedScanSubnets) !== detectedSubnet;
      if (scanSubnetsManual) {
        $('#settingsScanSubnets').val(savedScanSubnets);
        $('#settingsScanDetection').removeClass('text-warning').addClass('text-muted').text('Manual scan subnet override. Click Auto-Detect to use the selected interface.');
      } else {
        updateAutoDetectedScanSubnet();
      }
    });
  }

  function updateDetectedSipPort() {
    var transport = $('#settingsTransport').val();
    var detected = detectedSipTransports[transport];
    if (detected) {
      $('#settingsSipPort').val(detected.port);
      $('#settingsSipDetection').removeClass('text-warning').addClass('text-muted').text('Detected from Asterisk runtime: ' + detected.bind_address + ':' + detected.port);
    }
  }

  function loadSipTransportInfo(preferredTransport, fallbackPort) {
    ajax('getSipTransportInfo', {}, function (res) {
      var select = $('#settingsTransport');
      if (!res || !res.success) {
        if (select.find('option[value="' + preferredTransport + '"]').length) select.val(preferredTransport);
        $('#settingsSipPort').val(fallbackPort || '5060');
        $('#settingsSipDetection').removeClass('text-muted').addClass('text-warning').text('Asterisk transport detection failed; using the saved fallback port.');
        return;
      }
      detectedSipTransports = {};
      select.empty();
      ['UDP', 'TCP'].forEach(function (protocol) {
        if (!res.transports || !res.transports[protocol]) return;
        detectedSipTransports[protocol] = res.transports[protocol];
        select.append('<option value="' + protocol + '">' + protocol + '</option>');
      });
      if (select.children().length === 0) {
        select.append('<option value="UDP">UDP</option><option value="TCP">TCP</option>');
        if (select.find('option[value="' + preferredTransport + '"]').length) select.val(preferredTransport);
        $('#settingsSipPort').val(res.fallback_port || fallbackPort || '5060');
        $('#settingsSipDetection').removeClass('text-muted').addClass('text-warning').text('No active UDP/TCP PJSIP transport detected; using the saved fallback port.');
        return;
      }
      if (detectedSipTransports[preferredTransport]) select.val(preferredTransport);
      else select.val(select.children().first().val());
      updateDetectedSipPort();
    });
  }

  function updateDhcpSettingsVisibility(mode) {
    $('#settingsDhcpLeasesRow').toggle(mode === 'dhcp');
  }

  function loadSettings() {
    ajax('getSettings', {}, function (data) {
      if (data) {
        $('#settingsPbxIp').val(data.pbx_ip || '');
        $('#settingsSipPort').val(data.sip_port || '5060');
        loadSipTransportInfo(data.transport || 'UDP', data.sip_port || '5060');
        loadSettingsInterfaces(data.pbx_ip || '', data.scan_subnets || '');
        $('#settingsDhcpLeasesFile').val(data.dhcp_leases_file || '/var/lib/misc/dnsmasq.leases');
        $('#settingsVlanId').val(data.vlan_id || '');
        $('#settingsVlanDataId').val(data.vlan_data_id || '');
        var mode = data.deploy_mode || 'dhcp';
        if (mode === 'sip_notify') {
          $('#modeSipNotify').prop('checked', true);
          $('#modeSipNotifyLabel').addClass('mode-active');
        } else {
          $('#modeDhcp').prop('checked', true);
          $('#modeDhcpLabel').addClass('mode-active');
        }
        updateDhcpSettingsVisibility(mode);
      }
    });
  }

  $('#settingsInterfaceSelect').off('change').on('change', function () {
    var ip = $(this).val();
    if (ip) $('#settingsPbxIp').val(ip);
    if (!scanSubnetsManual) updateAutoDetectedScanSubnet();
  });

  $('#settingsScanSubnets').off('input').on('input', function () {
    scanSubnetsManual = true;
    $('#settingsScanDetection').removeClass('text-warning').addClass('text-muted').text('Manual scan subnet override. Click Auto-Detect to use the selected interface.');
  });

  $('#detectScanSubnetBtn').off('click').on('click', function () {
    scanSubnetsManual = false;
    updateAutoDetectedScanSubnet();
  });

  $('#settingsTransport').off('change').on('change', updateDetectedSipPort);

  $('#savePbxSettingsBtn').off('click').on('click', function (e) {
    e.preventDefault();
    var data = {
      pbx_ip:   $('#settingsPbxIp').val(),
      transport: $('#settingsTransport').val(),
      scan_subnets: scanSubnetsManual ? $('#settingsScanSubnets').val() : ''
    };
    if ($('input[name="deploy_mode"]:checked').val() === 'dhcp') data.dhcp_leases_file = $('#settingsDhcpLeasesFile').val();
    ajax('saveSettings', data, function (res) {
      if (res && res.success) showAlert('success', 'PBX settings saved.');
      else showAlert('danger', 'Failed to save PBX settings: ' + (res ? res.error : 'Unknown error'));
    });
  });

  $('input[name="deploy_mode"]').off('change').on('change', function () {
    var val = $(this).val();
    $('#modeDhcpLabel, #modeSipNotifyLabel').removeClass('mode-active');
    if (val === 'sip_notify') {
      $('#modeSipNotifyLabel').addClass('mode-active');
    } else {
      $('#modeDhcpLabel').addClass('mode-active');
    }
    updateDhcpSettingsVisibility(val);
    applyDiscoveryMode(val);
  });

  $('#saveVlanBtn').off('click').on('click', function (e) {
    e.preventDefault();
    var data = {
      vlan_id: $('#settingsVlanId').val(),
      vlan_data_id: $('#settingsVlanDataId').val()
    };
    ajax('saveSettings', data, function (res) {
      if (res && res.success) showAlert('success', 'VLAN settings saved.');
      else showAlert('danger', 'Failed to save VLAN settings.');
    });
  });


  $('#saveDeployModeBtn').off('click').on('click', function () {
    var mode = $('input[name="deploy_mode"]:checked').val();
    if (!mode) { showAlert('warning', 'Please select a deployment mode.'); return; }
    var btn = $(this);
    btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Saving...');
    ajax('saveSettings', { deploy_mode: mode }, function (res) {
      btn.prop('disabled', false).html('<i class="fa fa-save"></i> Save Mode');
      if (res && res.success) {
        showAlert('success', 'Deployment mode set to ' + mode.replace('_', ' ') + '.');
        applyDiscoveryMode(mode);
        updateDhcpSettingsVisibility(mode);
        if (mode === 'sip_notify') {
          $('#modeSipNotifyLabel').addClass('mode-active');
        } else {
          $('#modeDhcpLabel').addClass('mode-active');
        }
        $('#deployModeSaveStatus').text('Saved!').fadeOut(2000);
      } else {
        showAlert('danger', 'Failed to save mode.');
      }
    });
  });

  // =====================
  // TEMPLATE
  // =====================
  var currentTemplateBrand = 'digium';

  function loadTemplate() {
    var brand = $('#templateBrand').val();
    currentTemplateBrand = brand;
    $('#templateContent').val('Loading...');
    ajax('getTemplateContent', { brand: brand }, function (res) {
      if (res && res.success) {
        $('#templateContent').val(res.content);
        $('#templatePass').val(res.password || '');
      } else {
        $('#templateContent').val('/* Error loading template */');
      }
    });
  }

  $('#templateBrand').off('change').on('change', function () {
    loadTemplate();
  });

  $('#saveTemplateBtn').off('click').on('click', function () {
    ajax('saveTemplateContent', {
      content: $('#templateContent').val(),
      brand: currentTemplateBrand,
      password: $('#templatePass').val()
    }, function (res) {
      if (res && res.success) showAlert('success', 'Template saved.');
      else showAlert('danger', 'Save failed: ' + (res ? res.error : 'Unknown error'));
    });
  });

  $('#resetTemplateBtn').off('click').on('click', function () {
    showConfirm('Reset Template', 'Reset the template to its default content? Any edits will be lost.', function () {
      ajax('resetTemplate', { brand: currentTemplateBrand }, function (res) {
        if (res && res.success) { showAlert('success', 'Template reset to default.'); loadTemplate(); }
        else showAlert('danger', 'Reset failed: ' + (res ? res.error : 'Unknown error'));
      });
    });
  });

  // =====================
  // ALERTS / CONFIRM
  // =====================
  window.copyProvUrl = function(url) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(function () {
        showAlert('success', 'Provisioning URL copied to clipboard.');
      }).catch(function () {
        fallbackCopy(url);
      });
    } else {
      fallbackCopy(url);
    }
  };
  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(ta);
    showAlert('success', 'Provisioning URL copied to clipboard.');
  }

  function showAlert(type, message) {
    var keys = { success: 'success', danger: 'danger', info: 'info', warning: 'warning' };
    var cls = keys[type] || 'info';
    var html = '<div class="alert alert-' + cls + ' alert-dismissible" role="alert" style="position:fixed;top:60px;right:20px;z-index:99999;max-width:500px;">'
            + '<button type="button" class="close" data-dismiss="alert">&times;</button>'
            + message + '</div>';
    var $alert = $(html).appendTo('body');
    setTimeout(function () { $alert.alert('close'); }, 7000);
  }

  function showConfirm(title, message, callback, cancelCallback, okLabel, cancelLabel) {
    var $modal = $(
      '<div class="modal fade" tabindex="-1" role="dialog">' +
        '<div class="modal-dialog" role="document">' +
          '<div class="modal-content">' +
            '<div class="modal-header"><h4 class="modal-title">' + title + '</h4><button type="button" class="close" data-dismiss="modal">&times;</button></div>' +
            '<div class="modal-body">' + message + '</div>' +
            '<div class="modal-footer">' +
              '<button type="button" class="btn btn-default" data-dismiss="modal" id="confirmCancel">' + (cancelLabel || 'Cancel') + '</button>' +
              '<button type="button" class="btn btn-primary" id="confirmOk">' + (okLabel || 'OK') + '</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>'
    ).appendTo('body');
    $modal.find('#confirmOk').on('click', function () {
      $modal.modal('hide');
      if (callback) callback();
    });
    $modal.find('#confirmCancel').on('click', function () {
      if (cancelCallback) cancelCallback();
    });
    $modal.on('hidden.bs.modal', function () { $modal.remove(); });
    $modal.modal('show');
  }

  // =====================
  // TAB TRIGGERS
  // =====================
  $('a[href="#phones"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    $('#phoneStatusTable').bootstrapTable('refresh');
    $('#liveToggleBtn').show();
    if ($('#liveToggleBtn').data('active')) {
      startLiveRefresh();
    }
  });
  $('a[href="#devices"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    $('#devicesTable').bootstrapTable('refresh');
    loadPendingCount();
  });
  $('a[href="#provisioning"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    loadProvisioningInfo();
  });
  $('a[href="#discovered"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    ajax('getSettings', {}, function (data) {
      var mode = (data && data.deploy_mode) || 'dhcp';
      applyDiscoveryMode(mode);
    });
    if ($('#discoveredTable').is(':visible') && $('#discoveredTable').bootstrapTable('getData').length > 0) {
      refreshDiscoveredTable();
    }
    loadInterfaces(true);
  });
  $('a[href="#configfiles"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    $('#configFilesTable').bootstrapTable('refresh');
  });
  $('a[href="#logs"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    $('#logsTable').bootstrapTable('refresh');
  });
  $('a[href="#settings"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    loadSettings();
    loadTemplate();
  });

  // =====================
  // DEVICE DISCOVERY
  // =====================
  onTableSelect('discoveredTable', 'mac', selectedDhcpMacs, true);

  window.discoveredStatusFormatter = function (value, row) {
    if (row.status === 'added') {
      return '<span class="text-muted">Already in Mapping</span>';
    }
    if (row.is_supported) return '<span class="text-success">New Supported</span>';
    if (row.is_phone) return '<span class="text-warning">Recognized, Unsupported</span>';
    return '<span class="text-muted">Not Supported</span>';
  };

  window.discoveredActionsFormatter = function (value, row) {
    if (row.status === 'new') {
      return '<a class="clickable add-discovered-btn" data-mac="' + row.mac + '" data-ip="' + (row.ip || '') + '" data-ext="' + (row.extension || '') + '"><i class="fa fa-plus"></i> Add</a>';
    }
    return '-';
  };

   function applyDiscoveryMode(mode) {
     discoveryMode = mode;
     if (mode === 'sip_notify') {
       $('#scanBtnLabel').text('Scan Network');
       $('#discoveryCardTitle').text('Network Scan');
       $('#scanSubnetRow').show();
       $('#vendorCol').show();
       $('#discoveryScanBox').show();
       $('#discoverPjsipBtn').show();
       $('#autoAddSupportedBtn').show();
      } else {
       $('#scanBtnLabel').text('Scan DHCP Leases');
       $('#discoveryCardTitle').text('DHCP Leases');
       $('#scanSubnetRow').hide();
       $('#vendorCol').show();
       $('#discoveryScanBox').show();
        $('#discoverPjsipBtn').hide();
        $('#autoAddSupportedBtn').hide();
      }
      updateAutoAddSupportedButton();
   }

  function refreshDiscoveredTable() {
  }

  function normalizeDiscoveredRows(rows) {
    return (rows || []).map(function (row) {
      return {
        mac: String(row.mac || '').replace(/[^a-f0-9]/gi, '').toUpperCase(),
        ip: row.ip || '',
        extension: row.extension || '',
        vendor: row.vendor || 'Unknown',
        brand: row.brand || '',
        is_phone: row.is_phone === true || row.is_phone === 1 || row.is_phone === '1',
        is_supported: row.is_supported === true || row.is_supported === 1 || row.is_supported === '1',
        status: row.status || (row.in_provisioner ? 'added' : 'new')
      };
    });
  }

  function updateAutoAddSupportedButton() {
    var available = discoveryMode === 'sip_notify' && scanCompleted && discoveredRows.some(function (row) {
      return row.is_supported;
    });
    $('#autoAddSupportedBtn').prop('disabled', !available);
  }

  function clearDiscoverySelection() {
    selectedDhcpMacs.length = 0;
    $('#discoveredTable').bootstrapTable('uncheckAll');
    updateButtonStates();
  }

  function loadDiscoveredRows(rows) {
    discoveredRows = normalizeDiscoveredRows(rows);
    clearDiscoverySelection();
    $('#discoveredTable').bootstrapTable('load', discoveredRows).show();
    updateAutoAddSupportedButton();
  }

  function updateDiscoveredRowStatus(mac, status) {
    mac = String(mac || '').replace(/[^a-f0-9]/gi, '').toUpperCase();
    var idx = discoveredRows.findIndex(function (r) { return r.mac === mac; });
    if (idx !== -1) {
      discoveredRows[idx].status = status;
      $('#discoveredTable').bootstrapTable('updateByUniqueId', { id: mac, row: { status: status } });
      $('#discoveredTable').bootstrapTable('uncheckBy', { field: 'mac', values: [mac] });
      for (var i = selectedDhcpMacs.length - 1; i >= 0; i--) {
        if (selectedDhcpMacs[i] === mac) selectedDhcpMacs.splice(i, 1);
      }
      updateButtonStates();
      updateAutoAddSupportedButton();
    }
  }

  $('#discoveredTable').on('post-body.bs.table', function () {
    $('.add-discovered-btn').off('click').on('click', function () {
      var mac = $(this).data('mac');
      var ip  = $(this).data('ip') || '';
      var ext = $(this).data('ext') || '';
      ajax('addDiscoveredDevice', { mac: mac, extension: ext, ip: ip }, function (res) {
        if (res && res.success) {
          var msg = mac + ' added to MAC Mapping.';
          if (ext) msg += ' Extension ' + ext + ' assigned.';
          else msg += ' Set its extension in the MAC Mapping tab.';
          showAlert('success', msg);
          updateDiscoveredRowStatus(mac, 'added');
          $('#devicesTable').bootstrapTable('refresh');
          loadPendingCount();
        } else {
          showAlert('danger', 'Failed to add ' + mac + ': ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  function loadInterfaces(selectFirst) {
    ajax('getNetworkSubnets', {}, function (res) {
      var select = $('#scan-interface-select');
      select.empty().append('<option value="">— Select interface —</option>');
      var interfaces = (res && res.interfaces) || [];
      $.each(interfaces, function (i, iface) {
        select.append('<option value="' + iface.subnet + '" data-ip="' + iface.ip + '">' + iface.label + '</option>');
      });
      if (selectFirst && interfaces.length > 0) {
        select.val((res && res.selected_subnet) || interfaces[0].subnet).trigger('change');
      }
      if (interfaces.length === 0 && res && res.subnets && res.subnets.length > 0) {
        select.append('<option value="' + res.subnets[0] + '">' + res.subnets[0] + '</option>');
        if (selectFirst) select.val(res.subnets[0]).trigger('change');
      }
    });
  }

  $('#scan-interface-select').off('change').on('change', function () {
    var subnet = $(this).val();
    $('#scan-subnet-input').val(subnet);
  });

  $('#scanDiscoveryBtn').off('click').on('click', function () {
    var btn = $(this);
    var isDhcpMode = discoveryMode === 'dhcp';

    scanCompleted = false;
    $('#discoverPjsipBtn').prop('disabled', true);
    updateAutoAddSupportedButton();
    $('#discoveredTable').bootstrapTable('resetSearch', '');
    discoveredRows = [];
    clearDiscoverySelection();
    $('#discoveredTable').bootstrapTable('load', []).hide();

    btn.prop('disabled', true).find('#scanBtnLabel').html('<i class="fa fa-spinner fa-spin"></i> Scanning...');

    if (isDhcpMode) {
      ajax('getDhcpLeases', {}, function (res) {
        btn.prop('disabled', false).find('#scanBtnLabel').text('Scan DHCP Leases');
        if (!res || !res.success) {
          $('#scanStatus').html('<div class="alert alert-warning">' + (res ? res.error : 'Scan failed.') + '</div>').show();
          $('#discoveredTable').hide();
          return;
        }
        if (res.leases.length === 0) {
          $('#scanStatus').html('<div class="alert alert-info">No DHCP leases found.</div>').show();
          $('#discoveredTable').hide();
          return;
        }
        scanCompleted = true;
        $('#discoverPjsipBtn').prop('disabled', false);
        $('#scanStatus').html('<p class="text-muted"><strong>' + res.leases.length + '</strong> device(s) found in <code>' + res.file_path + '</code></p>').show();
        loadDiscoveredRows(res.leases);
      });
    } else {
      var subnet = $('#scan-subnet-input').val().trim();
      if (!subnet) {
        btn.prop('disabled', false).find('#scanBtnLabel').text('Scan Network');
        $('#scanStatus').html('<div class="alert alert-warning">Select an interface or enter a subnet manually.</div>').show();
        $('#discoveredTable').hide();
        return;
      }
      $('#spinner-scan').removeClass('hidden');
      ajax('scanNetwork', { subnet: subnet }, function (res) {
        btn.prop('disabled', false).find('#scanBtnLabel').text('Scan Network');
        $('#spinner-scan').addClass('hidden');
        if (!res || !res.success) {
          $('#scanStatus').html('<div class="alert alert-warning">' + (res ? res.error : 'Scan failed.') + '</div>').show();
          $('#discoveredTable').hide();
          return;
        }
        if (!res.devices || res.devices.length === 0) {
          $('#scanStatus').html('<div class="alert alert-info">No phones found in ' + (res.subnets ? res.subnets.join(', ') : res.subnet) + '.</div>').show();
          $('#discoveredTable').hide();
          return;
        }
        var rows = res.devices.map(function (d) {
          return {
            mac: d.mac || '',
            ip: d.ip || '',
           vendor: d.vendor || 'Unknown',
            brand: d.brand || '',
            is_phone: !!d.is_phone,
            is_supported: !!d.is_supported,
            status: d.in_provisioner ? 'added' : 'new'
          };
        });
        scanCompleted = true;
        $('#discoverPjsipBtn').prop('disabled', false);
        $('#scanStatus').html('<p class="text-muted"><strong>' + rows.length + '</strong> device(s) found in <code>' + (res.subnets ? res.subnets.join(', ') : res.subnet) + '</code></p>').show();
        loadDiscoveredRows(rows);
      });
    }
  });

  $('#autoAddSupportedBtn').off('click').on('click', function () {
    var btn = $(this);
    if (btn.data('digium-busy') || discoveryMode !== 'sip_notify' || !scanCompleted) return;
    var supported = discoveredRows.filter(function (row) { return row.is_supported; });
    if (supported.length === 0) {
      showAlert('info', 'No supported phones were found by this scan.');
      return;
    }

    btn.data('digium-busy', true).prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Matching...');
    ajax('autoDiscoverFromPjsip', {}, function (matchResult) {
      var pjsipWarning = null;
      if (matchResult && matchResult.success) {
        $.each(matchResult.matches || [], function (i, match) {
          var mac = String(match.mac || '').replace(/[^a-f0-9]/gi, '').toUpperCase();
          var row = discoveredRows.find(function (candidate) { return candidate.mac === mac; });
          if (row) {
            row.extension = match.extension || '';
            $('#discoveredTable').bootstrapTable('updateByUniqueId', { id: mac, row: { extension: row.extension } });
          }
        });
      } else {
        pjsipWarning = matchResult ? matchResult.error : 'PJSIP matching was unavailable.';
      }

      btn.data('digium-busy', false).html('<i class="fa fa-magic"></i> Auto Add Supported');
      updateAutoAddSupportedButton();
      var newSupported = supported.filter(function (row) { return row.status === 'new'; });
      var existingSupported = supported.length - newSupported.length;
      var withExtension = newSupported.filter(function (row) { return !!row.extension; }).length;
      var unsupportedCount = discoveredRows.length - supported.length;
      var message = '<p>Process all supported phones found by this scan?</p>'
        + '<dl class="dl-horizontal">'
        + '<dt>New with extension</dt><dd>' + withExtension + '</dd>'
        + '<dt>New unassigned</dt><dd>' + (newSupported.length - withExtension) + '</dd>'
        + '<dt>Existing IP refresh</dt><dd>' + existingSupported + '</dd>'
        + '<dt>Unsupported skipped</dt><dd>' + unsupportedCount + '</dd>'
        + '</dl>'
        + '<p>Configs will not be generated or pushed. Review MAC Mapping before using Push Config.</p>';
      if (pjsipWarning) {
        message += '<div class="alert alert-warning">PJSIP matching warning: '
          + $('<div>').text(pjsipWarning).html() + '. Phones without a match will be added unassigned.</div>';
      }
      showConfirm('Auto Add Supported Phones', message, function () {
        runAutoAddSupported(btn);
      }, null, 'Add Supported');
    });
  });

  function runAutoAddSupported(btn) {
    var devices = discoveredRows.map(function (row) { return { mac: row.mac, ip: row.ip || '' }; });
    btn.data('digium-busy', true).prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Adding...');
    ajax('autoAddSupportedDiscoveredDevices', { devices: devices }, function (res) {
      btn.data('digium-busy', false).html('<i class="fa fa-magic"></i> Auto Add Supported');
      updateAutoAddSupportedButton();
      if (!res || !res.success) {
        showAlert('danger', 'Auto Add failed: ' + (res ? res.error : 'Unknown error'));
        return;
      }
      $.each(res.added || [], function (i, device) {
        var mac = String(device.mac || '').replace(/[^a-f0-9]/gi, '').toUpperCase();
        var row = discoveredRows.find(function (candidate) { return candidate.mac === mac; });
        if (row) {
          row.status = 'added';
          row.extension = device.extension || '';
          $('#discoveredTable').bootstrapTable('updateByUniqueId', { id: mac, row: { status: 'added', extension: row.extension } });
        }
      });
      $('#devicesTable').bootstrapTable('refresh');
      loadPendingCount();
      clearDiscoverySelection();
      var result = '<p>Supported phone processing is complete.</p><dl class="dl-horizontal">'
        + '<dt>Added</dt><dd>' + res.added_count + '</dd>'
        + '<dt>With extension</dt><dd>' + res.added_with_extension + '</dd>'
        + '<dt>Unassigned</dt><dd>' + res.added_without_extension + '</dd>'
        + '<dt>IPs refreshed</dt><dd>' + res.refreshed_count + '</dd>'
        + '<dt>Already current</dt><dd>' + res.unchanged_count + '</dd>'
        + '<dt>Unsupported skipped</dt><dd>' + res.unsupported_count + '</dd>'
        + '<dt>Extension conflicts</dt><dd>' + (res.extension_conflicts || []).length + '</dd>'
        + '<dt>Errors</dt><dd>' + (res.errors || []).length + '</dd></dl>';
      if (res.pjsip_warning) result += '<div class="alert alert-warning">PJSIP matching was unavailable; unmatched phones were added without extensions.</div>';
      showConfirm('Auto Add Complete', result, function () {
        $('a[href="#devices"]').tab('show');
      }, null, 'Review MAC Mapping', 'Stay Here');
    });
  }

  var pullProgressSequence = 0;
  function startPullProgress(devices) {
    var progressToken = ++pullProgressSequence;
    var MAX_CONCURRENT = 5;
    var pullQueue = devices.filter(function (d) { return d.extension; });
    if (pullQueue.length === 0) return;
    var results = {};
    pullQueue.forEach(function (d) { results[d.mac] = null; });
    var total = pullQueue.length;
    var done = 0;
    var ok = 0;
    var failed = 0;
    var index = 0;
    var pending = 0;

    function isCurrentPull() {
      return progressToken === pullProgressSequence;
    }

    function renderTable() {
      if (!isCurrentPull()) return;
      var html = '';
      pullQueue.forEach(function (d) {
        var r = results[d.mac];
        var statusIcon = r && r.success ? '<span class="text-success">\u2705 Pulled</span>'
          : r && r.success === false ? '<span class="text-danger">\u274c ' + diagnosticsEsc(r.error || 'Unknown error') + '</span>'
          : '<span class="text-muted"><i class="fa fa-spinner fa-spin"></i> fetching...</span>';
        html += '<tr><td>' + d.mac + '</td><td>' + (d.ip || '—') + '</td><td>' + statusIcon + '</td></tr>';
      });
      $('#pullProgressBody').html(html);
    }

    function updateProgress() {
      if (!isCurrentPull()) return;
      var pct = total > 0 ? Math.round(done / total * 100) : 0;
      $('#pullProgressBar').css('width', pct + '%').text(done + ' / ' + total);
      $('#pullProgressSummary').text(ok + ' succeeded, ' + failed + ' failed');
      renderTable();
    }

    function finishPull() {
      if (!isCurrentPull()) return;
      if (failed > 0) {
        $('#pullRetryFailedBtn').show();
      }
      $('#pullProgressBar').removeClass('active');
      $('#pullCloseBtn').prop('disabled', false);
      if (ok > 0) {
        var table = $('#configFilesTable');
        table.bootstrapTable('resetSearch', '');
        table.one('load-success.bs.table', function () { table.bootstrapTable('selectPage', 1); });
        table.bootstrapTable('refresh');
        $('#pullProgressSummary').text(ok + ' succeeded, ' + failed + ' failed. Config Files refreshed.');
      }
    }

    function kick() {
      while (pending < MAX_CONCURRENT && index < total) {
        (function (mac) {
          index++;
          pending++;
          if (!mac) { pending--; done++; updateProgress(); return; }
          renderTable();
          $.ajax({
            url: 'ajax.php?module=provisioner&command=pullPhoneConfig',
            type: 'POST',
            data: { mac: mac },
            dataType: 'json',
            timeout: 120000
          }).done(function (res) {
            if (res && res.success) {
              results[mac] = { success: true, file: res.file || '' };
              ok++;
            } else {
              results[mac] = { success: false, error: (res && res.error) || 'Unknown error' };
              failed++;
            }
          }).fail(function () {
            results[mac] = { success: false, error: 'HTTP error' };
            failed++;
          }).always(function () {
            done++;
            pending--;
            updateProgress();
            if (done >= total && pending === 0) {
              finishPull();
            } else {
              kick();
            }
          });
        })(pullQueue[index].mac);
      }
    }

    $('#pullProgressTitle').text('Pulling Config from Phones');
    $('#pullProgressSummary').text('');
    $('#pullRetryFailedBtn').hide().data('devices', pullQueue);
    $('#pullCloseBtn').prop('disabled', true);
    updateProgress();
    $('#pullProgressModal').modal('show');
    kick();

    $('#pullRetryFailedBtn').off('click').on('click', function () {
      var failedDevices = pullQueue.filter(function (d) { return !results[d.mac] || !results[d.mac].success; });
      if (failedDevices.length === 0) { $(this).hide(); return; }
      failedDevices.forEach(function (d) { results[d.mac] = null; });
      ok = 0;
      failed = 0;
      done = 0;
      index = 0;
      pending = 0;
      pullQueue = failedDevices;
      total = pullQueue.length;
      $('#pullProgressBar').addClass('active');
      $('#pullRetryFailedBtn').hide();
      updateProgress();
      kick();
    });
  }

  $('#addSelectedDiscoveryBtn').off('click').on('click', function () {
    var macs = selectedDhcpMacs.slice();
    if (macs.length === 0) return;
    var newDevices = [];
    $.each(macs, function (i, mac) {
      var row = discoveredRows.find(function (r) { return r.mac === mac; });
      if (row && row.status === 'new') {
        newDevices.push({ mac: mac, ip: row.ip || '', extension: row.extension || '' });
      }
    });
    if (newDevices.length === 0) {
      showAlert('info', 'All selected devices are already in MAC Mapping.');
      return;
    }
    var skipped = macs.length - newDevices.length;
    var withExt = newDevices.filter(function (d) { return d.extension; }).length;
    var msg = 'Add ' + newDevices.length + ' device(s) to MAC Mapping?';
    if (withExt > 0) msg += ' ' + withExt + ' have PJSIP extensions assigned.';
    else msg += ' Extensions will be empty — edit them in the MAC Mapping tab.';
    if (skipped > 0) msg += ' (' + skipped + ' already in mapping, skipped.)';

    function doAdd(pullConfig) {
        ajax('addDiscoveredDevices', { devices: newDevices }, function (res) {
          if (res && res.success) {
            var accepted = res.devices || [];
            $.each(accepted, function (i, d) { updateDiscoveredRowStatus(d.mac, 'added'); });
            $('#devicesTable').bootstrapTable('refresh');
            loadPendingCount();
            var extCount = accepted.filter(function(d){ return d.extension; }).length;
            var addMsg = 'Added ' + res.added + ' of ' + newDevices.length + ' device(s) to MAC Mapping.';
            if (extCount > 0) addMsg += ' ' + extCount + ' with extensions.';
            if (res.errors && res.errors.length > 0) addMsg += ' Errors: ' + res.errors.join('; ');
            showAlert(res.errors && res.errors.length > 0 ? 'warning' : 'success', addMsg);
            if (pullConfig && extCount > 0) {
              startPullProgress(accepted);
            }
        } else {
          showAlert('danger', 'Failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    }

    if (withExt > 0) {
      showConfirm('Add Devices', msg + '<br><br>Pull current config from the <strong>' + withExt + '</strong> phone(s) with extensions? This downloads their settings for viewing/editing — it does not modify the phone.',
        function () { doAdd(true); },
        function () { doAdd(false); },
        'Add & Pull Config', 'Add Only'
      );
    } else {
      showConfirm('Add Devices', msg, function () { doAdd(false); });
    }
  });

  // Init Bootstrap tooltips
  $('[data-toggle="tooltip"]').tooltip();

  // Load first tab on start
  loadPendingCount();
});

#!/usr/bin/env python3
import hashlib
import json
import os
import socket
import sys
import subprocess
import tempfile
import time


def md5_custom(text):
    return hashlib.md5(text.encode('latin-1')).hexdigest()


def phone_service_available(ip, timeout=3):
    try:
        with socket.create_connection((ip, 80), timeout=timeout):
            return True
    except OSError:
        return False


def read_nonce_from_jar(jar):
    if not jar or not os.path.exists(jar):
        return None
    with open(jar) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split('\t')
            if len(parts) >= 7 and parts[5] == 'auth':
                return parts[6]
    return None


def curl_out(url, jar=None, data=None, timeout=15):
    cmd = ['curl', '-s', '--connect-timeout', str(timeout), '--max-time', str(timeout), '--no-keepalive', '-H', 'Connection: close']
    if jar:
        cmd += ['-b', jar, '-c', jar]
    if data:
        cmd += ['-d', data]
    cmd.append(url)
    try:
        r = subprocess.run(cmd, capture_output=True, text=False, timeout=timeout + 5)
        return {
            'exit': r.returncode,
            'stdout': r.stdout.decode('latin-1'),
            'stderr': r.stderr.decode('utf-8', errors='replace'),
        }
    except subprocess.TimeoutExpired:
        return {'exit': -1, 'stdout': '', 'stderr': 'timed out'}


def get_nonce(ip, jar, timeout):
    curl_out(f"http://{ip}/config.txt", jar=jar, timeout=timeout)
    nonce = read_nonce_from_jar(jar)
    if nonce:
        return nonce

    r = curl_out(f"http://{ip}/key==nonce", timeout=timeout)
    if r['stdout']:
        raw = r['stdout'].strip()[:16]
        if len(raw) >= 10:
            return raw

    return None


def fetch_config(ip, username, password, timeout=15):
    jar = os.path.join(tempfile.gettempdir(), f'digium_jar_{ip.replace(".", "_")}.txt')
    if os.path.exists(jar):
        os.remove(jar)

    try:
        if not phone_service_available(ip):
            return {"success": False, "error": f"Phone unavailable at {ip}"}

        for attempt in range(4):
            nonce = get_nonce(ip, jar, timeout)
            if not nonce or len(nonce) < 10:
                time.sleep(2)
                continue

            md5_hash = md5_custom(f"{username}:{password}:{nonce}")
            encoded = f"{username}:{md5_hash}"

            curl_out(f"http://{ip}/", jar=jar, data=f"encoded={encoded}&ReturnPage=/", timeout=timeout)
            r = curl_out(f"http://{ip}/config.txt", jar=jar, timeout=timeout)

            config = r['stdout']
            if not config or len(config) < 50:
                time.sleep(2)
                continue

            if "403 Forbidden" in config or "<center>nginx</center>" in config:
                return {"success": False, "error": "Got nginx response — IP belongs to a web server, not the phone"}

            if any(marker in config.lower() for marker in ("<html", "<head", "<body", "<title>", "server too busy")):
                return {"success": False, "error": "Received HTML/error response instead of a Digium config"}

            if "<title>Logon</title>" in config or ("Logon" in config[:500] and "password" in config[:400].lower()):
                return {"success": False, "error": "Auth failed — check credentials"}

            if "<<VOIP CONFIG FILE>>" not in config:
                return {"success": False, "error": "Invalid Digium config format"}

            return {"success": True, "config": config}

        return {"success": False, "error": f"Phone did not respond at {ip} — device may be busy"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}
    finally:
        try:
            if os.path.exists(jar):
                os.remove(jar)
        except Exception:
            pass


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print(json.dumps({"success": False, "error": "Usage: fetch_digium_config.py <ip> <username> <password>"}))
        sys.exit(1)
    ip = sys.argv[1]
    username = sys.argv[2]
    password = sys.argv[3]
    result = fetch_config(ip, username, password)
    print(json.dumps(result))
    sys.exit(0 if result["success"] else 1)

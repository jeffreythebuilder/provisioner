#!/usr/bin/python3
import socket, struct, time, sys, json, re

duration = int(sys.argv[1]) if len(sys.argv) > 1 else 10
pbx_ip = sys.argv[2] if len(sys.argv) > 2 else "0.0.0.0"

devices = {}
ports = [5060, 60000]
sockets = []

for port in ports:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", port))
        mreq = struct.pack("4s4s", socket.inet_aton("224.0.1.75"), socket.inet_aton(pbx_ip))
        s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        s.settimeout(1)
        sockets.append((s, port))
    except Exception as e:
        sys.stderr.write(f"Port {port}: {e}\n")

end = time.time() + duration
while time.time() < end:
    for s, port in sockets:
        try:
            data, addr = s.recvfrom(65535)
            if b"SUBSCRIBE" not in data:
                continue
            text = data.decode("utf-8", errors="replace")

            mac = None
            m = re.search(r'Contact:\s*<sip:([a-f0-9]{12})@', text, re.I)
            if m: mac = m.group(1)
            if not mac:
                m = re.search(r'Contact:\s*<sip:sngmac_([a-f0-9]{12})@', text, re.I)
                if m: mac = m.group(1)
            if not mac:
                m = re.search(r'From:\s*<sip:MAC([a-f0-9]{12})@', text, re.I)
                if m: mac = m.group(1)
            if not mac:
                m = re.search(r'User-Agent:\s*.*\s+([a-f0-9]{12})\s*$', text, re.I)
                if m: mac = m.group(1)

            vendor = None
            m = re.search(r'vendor\s*=\s*"([^"]+)"', text, re.I)
            if m: vendor = m.group(1)

            model = None
            m = re.search(r'model\s*=\s*"([^"]+)"', text, re.I)
            if m: model = m.group(1)

            if mac and mac not in devices:
                if vendor and vendor.lower() == "asterisk":
                    vendor = "Digium"
                devices[mac] = {
                    "ip": addr[0],
                    "mac": mac.upper(),
                    "vendor": vendor or "Unknown",
                    "model": model or "-",
                    "source": "PnP:" + str(port),
                }
        except socket.timeout:
            continue
        except Exception:
            continue

for s, port in sockets:
    s.close()

print(json.dumps({"success": True, "devices": list(devices.values()), "count": len(devices)}))

#!/usr/bin/python3
import socket, sys, time

if len(sys.argv) < 5:
    print("Usage: send_sip_notify.py <phone_ip> <pbx_ip> <mac> <uri> [phone_port]", file=sys.stderr)
    sys.exit(1)

phone_ip = sys.argv[1]
pbx_ip = sys.argv[2]
mac = sys.argv[3].lower()
uri = sys.argv[4]
phone_port = int(sys.argv[5]) if len(sys.argv) > 5 else 5060

branch = mac[:8] if len(mac) >= 8 else mac
call_id = "pnp-%s-%d" % (mac, int(time.time()))

notify = "\r\n".join((
    "NOTIFY sip:%s:%d SIP/2.0" % (phone_ip, phone_port),
    "Via: SIP/2.0/UDP %s:{src_port};branch=z9hG4bK-%s" % (pbx_ip, branch),
    "Max-Forwards: 20",
    "Contact: <sip:provisioner@%s>" % pbx_ip,
    "To: <sip:%s@%s>" % (mac.upper(), pbx_ip),
    "From: <sip:provisioner@%s>" % pbx_ip,
    "Call-ID: %s" % call_id,
    "CSeq: 1 NOTIFY",
    "Content-Type: application/url",
    "Event: ua-profile",
    "Content-Length: %d" % len(uri),
    "",
    uri,
))

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 0))
src_port = s.getsockname()[1]
packet = notify.format(src_port=src_port).encode()

for i in range(10):
    s.sendto(packet, (phone_ip, phone_port))
    s.settimeout(0.5)
    try:
        data, addr = s.recvfrom(4096)
        if b"200 OK" in data and b"CSeq: 1 NOTIFY" in data:
            s.close()
            print("OK")
            sys.exit(0)
    except socket.timeout:
        pass

s.close()
sys.exit(1)

<?php
$moduleName = 'provisioner';
?>
<style>
#deployModeCard .mode-active {
  background: #e8f5e9;
  border-color: #4caf50 !important;
}
#deployModeCard .mode-active strong::after {
  content: " (Active)";
  font-size: 11px;
  color: #2e7d32;
  font-weight: bold;
  margin-left: 6px;
}
</style>
<div class="container-fluid" id="provisioner-app">

  <!-- Tabs -->
  <ul class="nav nav-tabs" id="provisionerTabs" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" id="phones-tab" data-toggle="tab" href="#phones" role="tab">
        <i class="fa fa-phone"></i> Phone Status
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="devices-tab" data-toggle="tab" href="#devices" role="tab">
        <i class="fa fa-list"></i> MAC Mapping
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="import-tab" data-toggle="tab" href="#import" role="tab">
        <i class="fa fa-upload"></i><i class="fa fa-download"></i> Bulk Handler
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="provisioning-tab" data-toggle="tab" href="#provisioning" role="tab">
        <i class="fa fa-cogs"></i> Provisioning
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="discovered-tab" data-toggle="tab" href="#discovered" role="tab">
        <i class="fa fa-search"></i> Device Discovery
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="configfiles-tab" data-toggle="tab" href="#configfiles" role="tab">
        <i class="fa fa-file-text-o"></i> Config Files
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="logs-tab" data-toggle="tab" href="#logs" role="tab">
        <i class="fa fa-history"></i> Logs
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="settings-tab" data-toggle="tab" href="#settings" role="tab">
        <i class="fa fa-wrench"></i> Settings
      </a>
    </li>
  </ul>

  <div class="tab-content" id="provisionerTabsContent">

    <!-- ===================== PHONE STATUS TAB ===================== -->
    <div class="tab-pane fade show active" id="phones" role="tabpanel">
      <div class="row" style="margin-top:20px;">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title">Phone Status
                <button class="btn  btn-secondary float-right" id="liveToggleBtn" style="margin-right:5px;display:none;" title="Auto-refresh the table every 5 seconds">
                  <i class="fa fa-refresh"></i> Auto-Refresh
                </button>
                <button class="btn  btn-warning float-right" id="rebootAllBtn" style="margin-left:5px;">
                  <i class="fa fa-power-off"></i> Reboot All
                </button>
                <button class="btn  btn-secondary float-right" id="refreshPhoneBtn" style="margin-right:5px;">
                  <i class="fa fa-refresh"></i> Refresh
                </button>
                <button class="btn  btn-warning float-right" id="applyChangesPhoneBtn" style="display:none;margin-right:5px;">
                  <i class="fa fa-check"></i> Push Config <span id="pendingBadgePhone" class="badge badge-light" style="margin-left:4px;">0</span>
                </button>
              </h4>
            </div>
            <div class="card-body">
              <div id="phoneStatusToolbar">
                <button class="btn  btn-danger" id="rebootSelectedBtn" disabled><i class="fa fa-power-off"></i> Reboot</button>
                <button class="btn  btn-warning" id="retryFailedBtn" style="display:none;"><i class="fa fa-repeat"></i> Retry Failed</button>
              </div>
              <table id="phoneStatusTable"
                     data-url="ajax.php?module=provisioner&amp;command=getPhoneStatusGrid"
                     data-toolbar="#phoneStatusToolbar"
                     data-toggle="table"
                     data-pagination="true"
                     data-search="true"
                     data-maintain-selected="true"
                     data-cookie="true"
                     data-cookie-id-table="provisioner-phones"
                     class="table table-striped">
                <thead>
                  <tr>
                    <th data-checkbox="true"></th>
                    <th data-sortable="true" data-field="extension">Extension</th>
                    <th data-sortable="true" data-field="mac">MAC</th>
                    <th data-sortable="true" data-field="brand">Brand</th>
                    <th data-sortable="true" data-field="description">Description</th>
                    <th data-sortable="true" data-field="ip">IP</th>
                    <th data-sortable="true" data-field="status">Status</th>
                    <th data-sortable="true" data-field="push_status">Push</th>
                    <th data-sortable="true" data-field="last_ack">Last ACK</th>
                    <th data-field="actions">Actions</th>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===================== MAC MAPPING TAB ===================== -->
    <div class="tab-pane fade" id="devices" role="tabpanel">
      <div class="row" style="margin-top:20px;">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title">MAC Mapping
                <button class="btn  btn-warning float-right" id="applyChangesBtn" style="margin-left:5px;">
                  <i class="fa fa-check"></i> Push Config <span id="pendingBadge" class="badge badge-light" style="display:none;margin-left:4px;">0</span>
                </button>
                <button class="btn  btn-secondary float-right" id="discardAllBtn" style="display:none;margin-right:5px;">
                  <i class="fa fa-undo"></i> Discard All
                </button>
              </h4>
            </div>
            <div class="card-body">
              <div id="deviceToolbar">
                <button class="btn  btn-primary" id="addDeviceBtn"><i class="fa fa-plus"></i> Add Device</button>
                <button class="btn  btn-success" id="autoAssignBtn"><i class="fa fa-magic"></i> Auto-Assign</button>
                <button class="btn  btn-danger" id="deleteSelectedBtn" disabled><i class="fa fa-trash"></i> Delete</button>
              </div>
              <table id="devicesTable"
                     data-url="ajax.php?module=provisioner&amp;command=getDeviceGrid"
                     data-toolbar="#deviceToolbar"
                     data-toggle="table"
                     data-pagination="true"
                     data-search="true"
                     data-maintain-selected="true"
                     data-cookie="true"
                     data-cookie-id-table="provisioner-devices"
                     class="table table-striped">
                <thead>
                  <tr>
                    <th data-checkbox="true"></th>
                    <th data-sortable="true" data-field="extension">Extension</th>
                    <th data-sortable="true" data-field="mac_address">MAC Address</th>
                    <th data-sortable="true" data-field="brand">Brand</th>
                    <th data-sortable="true" data-field="description">Description</th>
                    <th data-sortable="true" data-field="static_ip">Static IP</th>
                    <th data-field="actions">Actions</th>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===================== BULK HANDLER TAB ===================== -->
    <div class="tab-pane fade" id="import" role="tabpanel">
      <div class="row" style="margin-top:20px;">
        <div class="col-sm-12">
          <h1>Bulk Handler</h1>
          <ul class="nav nav-pills">
            <li role="presentation" class="active"><a href="#bulkImportSection" class="list-group-item import__export__btn bulk-pill">Import</a></li>
            <li role="presentation"><a href="#bulkExportSection" class="list-group-item import__export__btn bulk-pill">Export</a></li>
          </ul>
          <div class="fpbx-container">
            <div class="tab-content display">

              <!-- Export Section -->
              <div id="bulkExportSection" class="tab-pane">
                <form class="fpbx-submit bulkhandler" name="bulkhandlerexport" role="form">
                  <div class="container-fluid">
                    <div class="element-container">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="">
                            <div class="row form-group">
                              <div class="col-md-3">
                                <label class="control-label">CSV Export</label>
                                <i class="fa fa-question-circle fpbx-help-icon" data-for="export-help"></i>
                              </div>
                              <div class="col-md-9">
                                <p>Export all MAC Mapping entries to a CSV file.</p>
                                <button type="button" class="btn" id="exportCsvBtn">Export</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                          <span id="export-help-help" class="help-block fpbx-help-block">Download all devices as a comma-separated values file</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>

              <!-- Import Section -->
              <div id="bulkImportSection" class="tab-pane active">
                <form class="fpbx-submit bulkhandler" name="bulkhandler" role="form">
                  <div class="container-fluid">
                    <div class="element-container">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="">
                            <div class="row form-group">
                              <div class="col-md-3">
                                <label class="control-label" for="importCsvFile">CSV File</label>
                                <i class="fa fa-question-circle fpbx-help-icon" data-for="import-file"></i>
                              </div>
                              <div class="col-md-9">
                                <span class="btn btn-default btn-file">Browse <input type="file" class="form-control importer" id="importCsvFile" accept=".csv,.txt"></span>
                                <span class="filename"></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                          <span id="import-file-help" class="help-block fpbx-help-block">Select a CSV file to import</span>
                        </div>
                      </div>
                    </div>
                    <div class="element-container">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="">
                            <div class="row form-group">
                              <div class="col-md-3">
                                <label class="control-label" for="importCsv">CSV Data</label>
                                <i class="fa fa-question-circle fpbx-help-icon" data-for="import-data"></i>
                              </div>
                              <div class="col-md-9">
                                <textarea class="form-control" id="importCsv" rows="8" placeholder="201,00:04:f3:ab:cd:ef,,Office Phone,,,&#10;202,00:04:f3:12:34:56,alcatel,Conference Room,192.168.0.11,255.255.255.0,192.168.0.1"></textarea>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                          <span id="import-data-help" class="help-block fpbx-help-block">Format: <code>extension,mac,brand,description,static_ip,subnet_mask,gateway</code> (brand and static IP columns optional)</span>
                        </div>
                      </div>
                    </div>
                    <div class="element-container">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="">
                            <div class="row form-group">
                              <div class="col-md-3"></div>
                              <div class="col-md-9">
                                <input type="button" id="importBtn" value="Import">
                                <div id="importResults" style="display:none;margin-top:8px;"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===================== PROVISIONING TAB ===================== -->
    <div class="tab-pane fade" id="provisioning" role="tabpanel">
      <div class="row" style="margin-top:20px;">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title">Server Info</h4>
            </div>
            <div class="card-body" id="provInfoBody">
              <p>Loading...</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===================== DEVICE DISCOVERY TAB ===================== -->
    <div class="tab-pane fade" id="discovered" role="tabpanel">
      <div class="row" style="margin-top:20px;">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title">
                <span id="discoveryCardTitle">Scan for Phones</span>
                <span id="scanSubnetRow" style="display:none;margin-left:10px;font-size:14px;font-weight:normal;">
                  Subnet: <input type="text" id="scan-subnet-input" class="form-control" style="width:160px;font-family:monospace;display:inline-block;" placeholder="e.g. 192.168.0.0/24">
                  <button class="btn btn-default btn-sm" id="autoDetectSubnetBtn" type="button"><i class="fa fa-magic"></i> Auto Detect</button>
                  <span id="spinner-scan" class="hidden" style="margin-left:6px"><i class="fa fa-spinner fa-spin"></i></span>
                </span>
                <button class="btn  btn-primary float-right" id="scanDiscoveryBtn">
                  <i class="fa fa-search"></i> <span id="scanBtnLabel">Scan DHCP Leases</span>
                </button>
              </h4>
            </div>
            <div class="card-body">
              <div id="scanStatus" style="display:none;margin-bottom:8px;"></div>
              <div id="discoveredToolbar">
                <button class="btn  btn-primary" id="addSelectedDiscoveryBtn" disabled>
                  <i class="fa fa-plus"></i> Add
                </button>
              </div>
              <table id="discoveredTable"
                     data-toolbar="#discoveredToolbar"
                     data-toggle="table"
                     data-pagination="true"
                     data-search="true"
                     data-maintain-selected="true"
                     data-cookie="true"
                     data-cookie-id-table="provisioner-discovered"
                     class="table table-striped"
                     style="display:none;">
                <thead>
                  <tr>
                    <th data-checkbox="true"></th>
                    <th data-sortable="true" data-field="mac">MAC</th>
                    <th data-sortable="true" data-field="ip">IP</th>
                    <th data-sortable="true" data-field="vendor" id="vendorCol" style="display:none;">Vendor</th>
                    <th data-sortable="true" data-field="status" data-formatter="discoveredStatusFormatter">Status</th>
                    <th data-field="actions" data-formatter="discoveredActionsFormatter">Actions</th>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===================== CONFIG FILES TAB ===================== -->
    <div class="tab-pane fade" id="configfiles" role="tabpanel">
      <div class="row" style="margin-top:20px;">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title">Generated Config Files
                <button class="btn  btn-danger float-right" id="deleteAllConfigBtn">
                  <i class="fa fa-trash"></i> Delete All
                </button>
              </h4>
            </div>
            <div class="card-body">
              <div id="configFileToolbar">
                <button class="btn btn-info" id="pullSelectedConfigBtn" disabled><i class="fa fa-download"></i> Pull Config</button>
                <button class="btn btn-warning" id="revertSelectedConfigBtn" disabled><i class="fa fa-undo"></i> Revert Config</button>
                <button class="btn btn-danger" id="deleteSelectedConfigBtn" disabled><i class="fa fa-trash"></i> Delete</button>
              </div>
              <table id="configFilesTable"
                     data-url="ajax.php?module=provisioner&amp;command=getConfigFileGrid"
                     data-toolbar="#configFileToolbar"
                     data-toggle="table"
                     data-pagination="true"
                     data-search="true"
                     data-maintain-selected="true"
                     data-cookie="true"
                     data-cookie-id-table="provisioner-config"
                     class="table table-striped">
                <thead>
                  <tr>
                    <th data-checkbox="true"></th>
                    <th data-sortable="true" data-field="extension">Extension</th>
                    <th data-sortable="true" data-field="mac">MAC</th>
                    <th data-sortable="true" data-field="description">Description</th>
                    <th data-sortable="true" data-field="modified">Modified</th>
                    <th data-field="actions">Actions</th>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===================== LOGS TAB ===================== -->
    <div class="tab-pane fade" id="logs" role="tabpanel">
      <div class="row" style="margin-top:20px;">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title">Logs
                <button class="btn  btn-danger float-right" id="clearLogsBtn">
                  <i class="fa fa-trash"></i> Clear Logs
                </button>
              </h4>
            </div>
            <div class="card-body">
              <table id="logsTable"
                     data-url="ajax.php?module=provisioner&amp;command=getLogGrid"
                     data-toggle="table"
                     data-pagination="true"
                     data-search="true"
                     data-cookie="true"
                     data-cookie-id-table="provisioner-logs"
                     class="table table-striped">
                <thead>
                  <tr>
                    <th data-sortable="true" data-field="timestamp">Timestamp</th>
                    <th data-sortable="true" data-field="action">Action</th>
                    <th data-sortable="true" data-field="details">Details</th>
                    <th data-sortable="true" data-field="status">Status</th>
                  </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ===================== SETTINGS TAB ===================== -->
    <div class="tab-pane fade" id="settings" role="tabpanel">
      <div class="row" style="margin-top:20px;">
        <div class="col-md-12">
          <div class="card" id="deployModeCard">
            <div class="card-header">
              <h4 class="card-title">Deployment Mode</h4>
            </div>
            <div class="card-body">
              <div class="radio">
                <label id="modeDhcpLabel" style="display:block;padding:10px 14px;border:1px solid #ddd;border-radius:4px;margin-bottom:8px;cursor:pointer;">
                  <input type="radio" name="deploy_mode" value="dhcp" id="modeDhcp" style="margin-right:6px;">
                  <strong>DHCP Option 66</strong> &mdash; Phone gets config URL from DHCP server. Scan uses DHCP leases. Push triggers a reboot (SIP NOTIFY via Asterisk) to force the phone to re-DHCP and fetch config.
                </label>
                <label id="modeSipNotifyLabel" style="display:block;padding:10px 14px;border:1px solid #ddd;border-radius:4px;margin-bottom:8px;cursor:pointer;">
                  <input type="radio" name="deploy_mode" value="sip_notify" id="modeSipNotify" style="margin-right:6px;">
                  <strong>SIP NOTIFY Push</strong> &mdash; Phone gets config URL via a direct SIP NOTIFY packet to port 5060 (no DHCP, no Asterisk). Scan uses network ping-sweep (same-subnet). Push auto-resolves IPs from ARP, nmap scan, or stored IP (cross-subnet).
                </label>
              </div>
              <button type="button" class="btn btn-primary" id="saveDeployModeBtn"><i class="fa fa-save"></i> Save Mode</button>
              <span id="deployModeSaveStatus" style="margin-left:8px;"></span>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title">PBX Settings</h4>
            </div>
            <div class="card-body">
              <form id="pbxSettingsForm">
                <div class="form-group">
                  <label for="settingsPbxIp">PBX IP Address</label>
                  <input type="text" class="form-control" id="settingsPbxIp" name="pbx_ip">
                </div>
                <div class="form-group">
                  <label for="settingsSipPort">SIP Port</label>
                  <input type="text" class="form-control" id="settingsSipPort" name="sip_port">
                </div>
                <div class="form-group">
                  <label for="settingsTransport">Transport</label>
                  <select class="form-control" id="settingsTransport" name="transport">
                    <option value="UDP">UDP</option>
                    <option value="TCP">TCP</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="settingsProvDir">Provisioning Directory</label>
                  <input type="text" class="form-control" id="settingsProvDir" name="prov_dir">
                </div>
                <div class="form-group">
                  <label for="settingsScanSubnets">Scan Subnets (CIDR)</label>
                  <input type="text" class="form-control" id="settingsScanSubnets" name="scan_subnets" placeholder="192.168.0.0/24, 10.10.0.0/16">
                  <small class="form-text text-muted">Comma-separated CIDR ranges for nmap scanning. Leave empty to auto-detect from PBX interfaces.</small>
                </div>
                <button type="button" class="btn  btn-primary" id="savePbxSettingsBtn"><i class="fa fa-save"></i> Save Settings</button>
              </form>
            </div>
          </div>
          <div class="card" style="margin-top:15px;">
            <div class="card-header">
              <h4 class="card-title">Phone Admin Credentials</h4>
            </div>
            <div class="card-body">
              <form id="phoneAdminForm">
                <div class="form-group">
                  <label for="settingsPhoneAdminPass">Password — Digium</label>
                  <input type="password" class="form-control" id="settingsPhoneAdminPass" name="phone_admin_pass" placeholder="789">
                </div>
                <div class="form-group">
                  <label for="settingsPhoneAdminPassAlcatel">Password — Alcatel</label>
                  <input type="password" class="form-control" id="settingsPhoneAdminPassAlcatel" name="phone_admin_pass_alcatel" placeholder="123456">
                </div>
                <button type="button" class="btn  btn-primary" id="savePhoneAdminBtn"><i class="fa fa-save"></i> Save Settings</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title">Template</h4>
            </div>
            <div class="card-body">
              <div class="form-group">
                <label for="templateBrand">Brand</label>
                <select class="form-control" id="templateBrand">
                  <?php foreach ($brands as $b): ?>
                  <option value="<?= $b ?>"><?= ucfirst($b) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <textarea class="form-control" id="templateContent" rows="15" style="font-family:monospace;font-size:12px;"></textarea>
              <div style="margin-top:8px;">
                <button class="btn  btn-primary" id="saveTemplateBtn"><i class="fa fa-save"></i> Save Template</button>
                <button class="btn  btn-secondary" id="resetTemplateBtn"><i class="fa fa-undo"></i> Reset to Default</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

  <!-- ===================== MODALS ===================== -->

  <!-- Add/Edit Device Modal -->
  <div class="modal fade" id="deviceModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="deviceModalTitle">Add Device</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <div class="alert alert-danger" id="deviceModalError" style="display:none;"></div>
          <input type="hidden" id="deviceId">
          <div class="form-group">
            <label for="deviceMac">MAC Address</label>
            <input type="text" class="form-control" id="deviceMac" placeholder="00:04:f3:ab:cd:ef">
          </div>
          <div class="form-group">
            <label for="deviceExtension">Extension</label>
            <select class="form-control" id="deviceExtension">
              <option value="">-- Select Extension --</option>
            </select>
          </div>
          <div class="form-group">
            <label for="deviceBrand">Brand</label>
            <select class="form-control" id="deviceBrand">
              <?php foreach ($brands as $b): ?>
              <option value="<?= $b ?>"><?= ucfirst($b) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="deviceDescription">Description</label>
            <input type="text" class="form-control" id="deviceDescription" placeholder="Office Phone">
          </div>
          <div class="form-group">
            <label for="deviceIpMode">IP Assignment</label>
            <select class="form-control" id="deviceIpMode">
              <option value="dhcp" selected>DHCP</option>
              <option value="static">Static</option>
            </select>
          </div>
          <div id="staticFields" style="display:none;">
            <div class="form-group">
              <label for="deviceStaticIp">Static IP</label>
              <input type="text" class="form-control" id="deviceStaticIp" placeholder="192.168.0.50">
            </div>
            <div class="form-group">
              <label for="deviceStaticMask">Subnet Mask</label>
              <div class="input-group">
                <input type="text" class="form-control" id="deviceStaticMask" placeholder="24 or 255.255.255.0">
                <div class="input-group-append">
                  <select class="form-control" id="maskPresets" style="width:auto;">
                    <option value="">Presets</option>
                    <option value="8">/8 = 255.0.0.0</option>
                    <option value="16">/16 = 255.255.0.0</option>
                    <option value="23">/23 = 255.255.254.0</option>
                    <option value="24">/24 = 255.255.255.0</option>
                    <option value="28">/28 = 255.255.255.240</option>
                    <option value="30">/30 = 255.255.252</option>
                    <option value="32">/32 = 255.255.255.255</option>
                  </select>
                </div>
              </div>
              <small class="text-muted">Type CIDR (e.g. <code>24</code>) or dotted, or select from presets</small>
            </div>
            <div class="form-group">
              <label for="deviceStaticGw">Gateway</label>
              <input type="text" class="form-control" id="deviceStaticGw" placeholder="192.168.0.1">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-primary" id="saveDeviceBtn"><i class="fa fa-save"></i> Save</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Push Config Modal -->
  <div class="modal fade" id="applyModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Push Config</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p id="applyCountDesc">Push config for <strong id="applyCount">0</strong> device(s) with pending changes.</p>
          <p id="applySelectedDesc" style="display:none;">Push config for <strong id="applySelectedCount">0</strong> selected phone(s).</p>
          <p id="applyNoChangesDesc" style="display:none;">Push config to all active phones (no pending changes).</p>
          <div class="checkbox">
            <label><input type="checkbox" id="applyGenerateCfg" checked> Generate config files</label>
          </div>
          <div class="checkbox" id="applyRebootRow">
            <label><input type="checkbox" id="applyRebootPhones" checked> Reboot phones</label>
          </div>
          <div id="applyNotifyRow" style="display:none;">
            <div class="checkbox">
              <label><input type="checkbox" id="applyNotifyPush" checked> Send SIP NOTIFY push</label>
            </div>
          </div>
          <div id="applyProgress" style="display:none;">
            <div class="progress" style="margin-bottom:8px;">
              <div class="progress-bar progress-bar-striped active" id="applyProgressBar" style="width:0%"></div>
            </div>
            <p class="text-muted" id="applyProgressText">Initializing...</p>
          </div>
          <div id="applyResults" style="display:none;">
            <hr>
            <div id="applyResultsContent"></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-warning" id="applyOkBtn"><i class="fa fa-check"></i> Push</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Edit Config File Modal -->
  <div class="modal fade" id="configEditModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="configEditTitle">Edit Config File</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="configEditMac">
          <textarea class="form-control" id="configEditContent" rows="20" style="font-family:monospace;font-size:12px;"></textarea>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-success" id="saveActiveConfigBtn" style="display:none"><i class="fa fa-save"></i> Override Active Config</button>
          <button type="button" class="btn btn-primary" id="saveConfigBtn"><i class="fa fa-save"></i> Save</button>
        </div>
      </div>
    </div>
  </div>

</div>
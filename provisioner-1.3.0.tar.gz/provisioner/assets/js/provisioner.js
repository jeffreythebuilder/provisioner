$(document).ready(function () {

  const ajax = function (command, data, callback) {
    data = data || {};
    data.module = 'provisioner';
    return $.post('ajax.php?module=provisioner&command=' + command, data, function (res) {
      callback(res);
    }, 'json').fail(function (xhr) {
      if (xhr.statusText === 'abort' || xhr.status === 0) return;
      console.error('AJAX error:', xhr.responseText);
      callback({ error: 'Request failed' });
    });
  };

  // =====================
  // PENDING CHANGES COUNT
  // =====================
  var pendingNeedsReboot = false;

  function loadPendingCount(callback) {
    ajax('getPendingCount', {}, function (res) {
      var count = res && res.count ? res.count : 0;
      var badge = $('#pendingBadge');
      var btn = $('#applyChangesBtn');
      var badgePhone = $('#pendingBadgePhone');
      var btnPhone = $('#applyChangesPhoneBtn');
      var discard = $('#discardAllBtn');
      pendingNeedsReboot = res && res.needs_reboot ? true : false;
      var isSipNotify = res && res.deploy_mode === 'sip_notify';
      if (count > 0) {
        badge.text(count).show();
        btn.prop('disabled', false);
        badgePhone.text(count).show();
        btnPhone.show();
        discard.show();
      } else if (isSipNotify) {
        badge.text('Push').removeClass('badge-primary badge-danger badge-warning badge-info').addClass('badge-info').show();
        btn.prop('disabled', false);
        badgePhone.text('Push').removeClass('badge-primary badge-danger badge-warning badge-info').addClass('badge-info').show();
        btnPhone.show();
        discard.hide();
      } else {
        badge.hide();
        btn.prop('disabled', true);
        badgePhone.hide();
        btnPhone.hide();
        discard.hide();
      }
      if (callback) callback(count);
    });
  }

  // =====================
  // TABLE SELECTION TRACKING
  // =====================
  var selectedExtensions = [];
  var selectedDeviceIds = [];
  var selectedConfigMacs = [];
  var selectedDhcpMacs = [];
  var liveInterval = null;
  var autoRefreshCountdown = 5;

  function onTableSelect(tableId, field, store) {
    $('#' + tableId).on('check.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table',
      function () {
        store.length = 0;
        var selections = $('#' + tableId).bootstrapTable('getSelections');
        $.each(selections, function (i, row) {
          store.push(row[field]);
        });
        updateButtonStates();
      }
    );
    $('#' + tableId).on('page-change.bs.table', function () {
      store.length = 0;
      updateButtonStates();
    });
  }

  function updateButtonStates() {
    $('#rebootSelectedBtn').prop('disabled', selectedExtensions.length === 0);
    $('#deleteSelectedBtn').prop('disabled', selectedDeviceIds.length === 0);
    $('#deleteSelectedConfigBtn').prop('disabled', selectedConfigMacs.length === 0);
    $('#pullSelectedConfigBtn').prop('disabled', selectedConfigMacs.length === 0);
    $('#revertSelectedConfigBtn').prop('disabled', selectedConfigMacs.length === 0);
    $('#addSelectedDiscoveryBtn').prop('disabled', selectedDhcpMacs.length === 0);
  }

  // =====================
  // TABLE EVENT INIT
  // =====================
  onTableSelect('phoneStatusTable', 'extension', selectedExtensions);

  $('#phoneStatusTable').on('post-body.bs.table', function () {
    $('.reboot-btn').off('click').on('click', function () {
      var ext = $(this).data('ext');
      showConfirm('Reboot Phone', 'Reboot extension ' + ext + '?', function () {
        ajax('rebootPhone', { extension: ext }, function (res) {
          if (res && res.success) {
            showAlert('success', 'Reboot sent to extension ' + ext);
            $('#phoneStatusTable').bootstrapTable('refresh');
          } else {
            showAlert('danger', 'Reboot failed for extension ' + ext);
          }
        });
      });
    });
    $('.retry-push-btn').off('click').on('click', function () {
      var btn = $(this);
      btn.html('<i class="fa fa-spinner fa-spin"></i>');
      var mac = btn.data('mac');
      ajax('retryPushForPhones', { macs: [mac] }, function (res) {
        if (res && res.success) {
          var sent = (res.sent || []).length;
          var failed = (res.failed || []).length;
          var msg = 'Retry done. ' + sent + ' sent, ' + failed + ' failed.';
          showAlert(sent > 0 ? 'success' : 'warning', msg);
        } else {
          showAlert('danger', 'Retry failed: ' + (res ? res.error : 'Unknown error'));
        }
        $('#phoneStatusTable').bootstrapTable('refresh');
      });
    });
    showRetryFailedBtn();
  });

  $('#rebootSelectedBtn').off('click').on('click', function () {
    if (selectedExtensions.length === 0) return;
    var allRows = $('#phoneStatusTable').bootstrapTable('getData');
    var onlineExts = [];
    $.each(allRows, function (i, r) {
      if ((r.status === 'Registered' || r.status === 'Online' || r.status === 'Reboot Required' || r.status === 'Apply Pending') && selectedExtensions.indexOf(r.extension) !== -1) {
        onlineExts.push(r.extension);
      }
    });
    if (onlineExts.length === 0) {
      showAlert('warning', 'No selected phones are online and eligible for reboot.');
      return;
    }
    var skipped = selectedExtensions.length - onlineExts.length;
    var msg = 'Reboot ' + onlineExts.length + ' phone(s)?';
    if (skipped > 0) msg += ' (' + skipped + ' offline phone(s) will be skipped.)';
    showConfirm('Reboot Extensions', msg, function () {
      ajax('rebootPhones', { extensions: onlineExts }, function (res) {
        if (res && res.success) {
          showAlert('success', 'Reboot sent to ' + onlineExts.length + ' phone(s).');
          $('#phoneStatusTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Reboot failed.');
        }
      });
    });
  });

  function showRetryFailedBtn() {
    var allRows = $('#phoneStatusTable').bootstrapTable('getData');
    var hasFailed = false;
    $.each(allRows, function (i, r) {
      if (r.push_status && r.push_status.indexOf('Failed') !== -1) {
        hasFailed = true;
        return false;
      }
    });
    $('#retryFailedBtn').toggle(hasFailed);
  }

  $('#retryFailedBtn').off('click').on('click', function () {
    var allRows = $('#phoneStatusTable').bootstrapTable('getData');
    var failedMacs = [];
    $.each(allRows, function (i, r) {
      if (r.push_status && r.push_status.indexOf('Failed') !== -1) {
        failedMacs.push(r.mac);
      }
    });
    if (failedMacs.length === 0) return;
    showConfirm('Retry Push', 'Retry push for ' + failedMacs.length + ' failed phone(s)?', function () {
      $('#retryFailedBtn').prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Retrying...');
      ajax('retryPushForPhones', { macs: failedMacs }, function (res) {
        $('#retryFailedBtn').prop('disabled', false).html('<i class="fa fa-repeat"></i> Retry Failed');
        if (res && res.success) {
          var sent = (res.sent || []).length;
          var failed = (res.failed || []).length;
          showAlert('success', 'Retry done. ' + sent + ' sent, ' + failed + ' failed.');
        } else {
          showAlert('danger', 'Retry failed: ' + (res ? res.error : 'Unknown error'));
        }
        $('#phoneStatusTable').bootstrapTable('refresh');
      });
    });
  });

  // MAC Mapping — bulk delete
  onTableSelect('devicesTable', 'id', selectedDeviceIds);

  $('#devicesTable').on('post-body.bs.table', function () {
    $('.edit-device-btn').off('click').on('click', function () {
      $('#deviceModalTitle').text('Edit Device');
      $('#deviceId').val($(this).data('id'));
      var curExt = $(this).attr('data-ext');
      $('#deviceMac').val($(this).data('mac'));
      $('#deviceBrand').val($(this).data('brand'));
      $('#deviceDescription').val($(this).data('desc'));
      var staticIp = $(this).data('static-ip') || '';
      if (staticIp) {
        $('#deviceIpMode').val('static');
        $('#staticFields').show();
      } else {
        $('#deviceIpMode').val('dhcp');
        $('#staticFields').hide();
      }
      $('#deviceStaticIp').val(staticIp);
      $('#deviceStaticMask').val($(this).data('static-mask') || '').trigger('input');
      $('#deviceStaticGw').val($(this).data('static-gw') || '');
      $('#deviceModalError').hide();
      loadExtensions(curExt, function () { $('#deviceModal').modal('show'); });
    });
    $('.revert-device-btn').off('click').on('click', function () {
      if ($(this).data('digium-busy')) return;
      var id = $(this).data('id');
      showConfirm('Revert Device', 'Restore this device to its previous values?', function () {
        ajax('revertDevice', { id: id }, function (res) {
          if (res && res.success) {
            showAlert('success', 'Device reverted.');
            $('#devicesTable').bootstrapTable('refresh');
            loadPendingCount();
          } else {
            showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
    });
    $('.delete-device-btn').off('click').on('click', function () {
      if ($(this).data('digium-busy')) return;
      $(this).data('digium-busy', true);
      var id = $(this).data('id');
      var ext = $(this).data('ext');
      showConfirm('Delete Device', 'Delete extension ' + ext + '? This cannot be undone.', function () {
        ajax('deleteDevice', { id: id }, function (res) {
          if (res && res.success) {
            showAlert('success', 'Device deleted.');
            $('#devicesTable').bootstrapTable('refresh');
            $('#phoneStatusTable').bootstrapTable('refresh');
            loadPendingCount();
          } else {
            showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
    });
  });

  // Config Files — bulk delete
  onTableSelect('configFilesTable', 'mac', selectedConfigMacs);

  $('#configFilesTable').on('post-body.bs.table', function () {
    $('.edit-config-btn').off('click').on('click', function () {
      var mac = $(this).data('mac');
      var ext = $(this).data('ext');
      $('#configEditModal').data('configExt', ext);
      $('#configEditMac').val(mac);
      $('#configEditTitle').text('Edit Config File — ' + mac);
      $('#configEditContent').val('Loading...');
      $('#configEditModal').modal('show');
      ajax('getConfigFileContent', { mac: mac }, function (res) {
        if (res && res.success) {
          $('#configEditContent').val(res.content);
          $('#configEditModal').data('configExt', res.extension);
        } else {
          $('#configEditContent').val('Error loading config.');
        }
      });
    });
    $('.delete-config-btn').off('click').on('click', function () {
      if ($(this).data('digium-busy')) return;
      $(this).data('digium-busy', true);
      var mac = $(this).data('mac');
      showConfirm('Delete Config File', 'Delete config for ' + mac + '? (MAC Mapping entries will not be deleted.)', function () {
        ajax('deleteConfigFile', { mac: mac }, function (res) {
          if (res && res.success) {
            showAlert('success', 'Deleted ' + mac + '.cfg');
            $('#configFilesTable').bootstrapTable('refresh');
          } else {
            showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
    });
    $('.fetch-config-btn').off('click').on('click', function () {
      var mac = $(this).data('mac');
      $('#configEditMac').val(mac);
      $('#configEditTitle').text('Config from Phone — ' + mac + ' (Loading...)');
      $('#configEditContent').val('Fetching config from phone...').prop('readonly', true);
      $('#saveConfigBtn').hide();
      $('#saveActiveConfigBtn').hide();
      $('#configEditModal').modal('show');
      ajax('fetchPhoneConfig', { mac: mac }, function (res) {
        if (res && res.success) {
          $('#configEditTitle').text('Config from Phone — ' + mac);
          $('#configEditContent').val(res.config).prop('readonly', true);
          $('#saveActiveConfigBtn').show().data('mac', mac);
        } else {
          var error = res ? res.error : 'Unknown error';
          $('#configEditTitle').text('Config from Phone — ' + mac + ' (Failed)');
          $('#configEditContent').val('Failed to fetch config:\n' + error + '\n\nCheck Phone Admin credentials in Settings tab.').prop('readonly', true);
        }
      });
    });
    $('.revert-config-btn').off('click').on('click', function () {
      if ($(this).data('digium-busy')) return;
      $(this).data('digium-busy', true);
      var mac = $(this).data('mac');
      showConfirm('Revert to Template', 'Restore the backed-up config (if available) and revert to template-generated config for next push?', function () {
        ajax('revertConfigTemplate', { mac: mac }, function (res) {
          if (res && res.success) {
            showAlert('success', res.message);
            $('#configFilesTable').bootstrapTable('refresh');
          } else {
            showAlert('danger', 'Revert failed: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
    });
  });

  $('#deleteSelectedConfigBtn').off('click').on('click', function () {
    if (selectedConfigMacs.length === 0) return;
    showConfirm('Delete Configs', 'Delete ' + selectedConfigMacs.length + ' config file(s)? (MAC Mapping entries will not be deleted.)', function () {
      ajax('deleteSelectedConfigFiles', { macs: selectedConfigMacs }, function (res) {
        if (res && res.success) {
          showAlert('success', 'Deleted ' + res.deleted + ' file(s).');
          $('#configFilesTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  $('#pullSelectedConfigBtn').off('click').on('click', function () {
    if (selectedConfigMacs.length === 0) return;
    showConfirm('Pull Configs', 'Download config from ' + selectedConfigMacs.length + ' phone(s) and override their template configs? Current configs will be backed up. Only one backup kept per phone.', function () {
      ajax('pullSelectedConfigFiles', { macs: selectedConfigMacs }, function (res) {
        if (res && res.success) {
          var msg = 'Config pulled from ' + res.pulled + ' phone(s).';
          if (res.errors.length) msg += ' ' + res.errors.length + ' failed.';
          showAlert('success', msg);
          $('#configFilesTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Pull failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  $('#revertSelectedConfigBtn').off('click').on('click', function () {
    if (selectedConfigMacs.length === 0) return;
    showConfirm('Revert Configs', 'Restore backed-up config for ' + selectedConfigMacs.length + ' device(s) and revert to template-generated config?', function () {
      ajax('revertSelectedConfigFiles', { macs: selectedConfigMacs }, function (res) {
        if (res && res.success) {
          var msg = 'Reverted ' + res.reverted + ' device(s).';
          if (res.errors.length) msg += ' ' + res.errors.length + ' failed.';
          showAlert('success', msg);
          $('#configFilesTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Revert failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  $('#saveActiveConfigBtn').off('click').on('click', function () {
    var mac = $(this).data('mac');
    var content = $('#configEditContent').val();
    showConfirm('Override Active Config', 'Override the current ' + mac + '.cfg with the config from phone? Current file will be backed up.', function () {
      ajax('saveAsActiveConfig', { mac: mac, content: content }, function (res) {
        if (res && res.success) {
          showAlert('success', res.message);
          $('#configFilesTable').bootstrapTable('refresh');
          $('#configEditModal').modal('hide');
        } else {
          showAlert('danger', 'Save failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  $('#configEditModal').on('hidden.bs.modal', function () {
    $('#saveActiveConfigBtn').hide();
    $('#saveConfigBtn').show();
    $('#configEditContent').prop('readonly', false);
  });

  $('#saveConfigBtn').off('click').on('click', function () {
    var mac = $('#configEditMac').val();
    var content = $('#configEditContent').val();
    ajax('saveConfigFile', {
      mac: mac,
      content: content
    }, function (res) {
      if (res && res.success) {
        showAlert('success', 'Config file saved.');
        $('#configFilesTable').bootstrapTable('refresh');
        var cfgExt = $('#configEditModal').data('configExt');
        if (cfgExt) {
            showConfirm('Push & Reboot', 'Reboot extension ' + cfgExt + ' now to load the new config?', function () {
            ajax('rebootPhone', { extension: cfgExt }, function (r) {
              if (r && r.success) {
                showAlert('success', 'Reboot sent to extension ' + cfgExt);
              } else {
                showAlert('danger', 'Reboot failed for extension ' + cfgExt);
              }
            });
          });
        }
      } else {
        showAlert('danger', 'Save failed: ' + (res ? res.error : 'Unknown error'));
      }
    });
  });

  // =====================
  // REFRESH
  // =====================
  $('#refreshPhoneBtn').off('click').on('click', function () {
    $('#phoneStatusTable').bootstrapTable('refresh');
    loadPendingCount();
  });

  function startLiveRefresh() {
    if (liveInterval) clearInterval(liveInterval);
    autoRefreshCountdown = 5;
    $('#liveToggleBtn').removeClass('btn-secondary').addClass('btn-success').html('<i class="fa fa-refresh fa-spin"></i> Auto-Refresh ' + autoRefreshCountdown + 's').data('active', true).attr('title', 'Auto-refreshing every 5 seconds. Click to stop.');
    refreshPhoneTable();
    liveInterval = setInterval(function () {
      if ($('.modal.show').length > 0 || $('.bootbox.modal').length > 0) return;
      autoRefreshCountdown--;
      if (autoRefreshCountdown < 1) {
        autoRefreshCountdown = 5;
        refreshPhoneTable();
      }
      $('#liveToggleBtn').html('<i class="fa fa-refresh fa-spin"></i> Auto-Refresh ' + autoRefreshCountdown + 's');
    }, 1000);
  }

  function stopLiveRefresh() {
    if (liveInterval) {
      clearInterval(liveInterval);
      liveInterval = null;
    }
    $('#liveToggleBtn').removeClass('btn-success').addClass('btn-secondary').html('<i class="fa fa-refresh"></i> Auto-Refresh').data('active', false).attr('title', 'Auto-refresh the table every 5 seconds');
  }

  function refreshPhoneTable() {
    $('#phoneStatusTable').bootstrapTable('refresh');
    loadPendingCount();
  }

  $('#liveToggleBtn').off('click').on('click', function () {
    if ($(this).data('active')) {
      stopLiveRefresh();
    } else {
      startLiveRefresh();
    }
  });

  // =====================
  // REBOOT ALL
  // =====================
  $('#rebootAllBtn').off('click').on('click', function () {
    var rows = $('#phoneStatusTable').bootstrapTable('getData');
    var exts = [];
    $.each(rows, function (i, r) {
      if (r.status === 'Registered' || r.status === 'Online' || r.status === 'Reboot Required' || r.status === 'Apply Pending') {
        exts.push(r.extension);
      }
    });
    if (exts.length === 0) {
      showAlert('info', 'No phones to reboot.');
      return;
    }
    showConfirm('Reboot All Phones', 'Are you sure you want to reboot ALL phones listed below?', function () {
      ajax('rebootPhones', { extensions: exts }, function (res) {
        if (res && res.success) {
          showAlert('success', 'Reboot sent to ' + exts.length + ' phone(s).');
          $('#phoneStatusTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Reboot failed.');
        }
      });
    });
  });

  // =====================
  // ADD / EDIT DEVICE
  // =====================
  function loadExtensions(selectedExt, callback) {
    var sel = $('#deviceExtension');
    sel.empty().append('<option value="">Loading extensions...</option>');
    ajax('getExtensions', {}, function (exts) {
      sel.empty().append('<option value="">-- Select Extension --</option>');
      if (exts && exts.length) {
        $.each(exts, function (i, e) {
          var opt = $('<option>').val(e.extension).text(e.extension + ' (' + e.name + ')');
          if (selectedExt && e.extension === selectedExt) opt.prop('selected', true);
          sel.append(opt);
        });
      }
      if (callback) callback();
    });
  }

  $('#addDeviceBtn').off('click').on('click', function () {
    $('#deviceModalTitle').text('Add Device');
    $('#deviceId').val('');
    $('#deviceMac').val('');
    $('#deviceBrand').val($('#deviceBrand option:first').val());
    $('#deviceDescription').val('');
    $('#deviceIpMode').val('dhcp');
    $('#staticFields').hide();
    $('#deviceStaticIp').val('');
    $('#deviceStaticMask').val('');
    $('#deviceStaticGw').val('');
    $('#deviceModalError').hide();
    loadExtensions('', function () { $('#deviceModal').modal('show'); });
  });

  function cidrToMask(val) {
    if (!val) return null;
    if (/^\d{1,2}$/.test(val)) {
      var n = parseInt(val);
      if (n >= 0 && n <= 32) {
        var mask = ~(Math.pow(2, 32 - n) - 1) >>> 0;
        return [(mask >>> 24), (mask >> 16 & 255), (mask >> 8 & 255), (mask & 255)].join('.');
      }
    }
    return val;
  }

  function maskToCidr(val) {
    if (!val) return '';
    if (/^\d{1,2}$/.test(val)) return val;
    var parts = val.split('.').map(Number);
    if (parts.length !== 4 || parts.some(function(p) { return isNaN(p) || p < 0 || p > 255; })) return '';
    var bin = parts.map(function(p) { return (p >>> 0).toString(2).padStart(8, '0'); }).join('');
    if (!/^1+0*$/.test(bin)) return '';
    return bin.indexOf('0') === -1 ? '32' : String(bin.indexOf('0'));
  }

  $('#deviceIpMode').on('change', function () {
    $('#staticFields').toggle($(this).val() === 'static');
  });

  $('#maskPresets').on('change', function () {
    if ($(this).val()) {
      $('#deviceStaticMask').val($(this).val());
    }
  });

  $('#deviceStaticMask').on('input', function () {
    var cidr = maskToCidr($(this).val());
    $('#maskPresets').val(cidr || '');
  });

  var saving = false;
  $('#saveDeviceBtn').off('click').on('click', function () {
    if (saving) return;
    var id   = $('#deviceId').val();
    var mac  = $('#deviceMac').val().trim();
    var ext  = $('#deviceExtension').val().trim();
    var brand = $('#deviceBrand').val();
    var desc = $('#deviceDescription').val().trim();
    if (!mac || !ext) {
      $('#deviceModalError').text('MAC address and extension are required.').show();
      return;
    }
    saving = true;
    var command = id ? 'updateDevice' : 'addDevice';
    var isStatic = $('#deviceIpMode').val() === 'static';
    var staticIp  = isStatic ? $('#deviceStaticIp').val().trim() || null : null;
    var staticMask = isStatic ? cidrToMask($('#deviceStaticMask').val().trim()) : null;
    var staticGw  = isStatic ? $('#deviceStaticGw').val().trim() || null : null;
    var data    = { mac: mac, extension: ext, description: desc, brand: brand, static_ip: staticIp, static_mask: staticMask, static_gw: staticGw };
    if (id) data.id = id;
    ajax(command, data, function (res) {
      saving = false;
      if (res && res.success) {
        $('#deviceModal').modal('hide');
        showAlert('success', 'Device saved. Use Push Config to generate configs and reboot.');
        $('#devicesTable').bootstrapTable('refresh');
        loadPendingCount();
      } else {
        $('#deviceModalError').text('Error: ' + (res ? res.error : 'Unknown error')).show();
      }
    });
  });

  // =====================
  // DISCARD ALL
  // =====================
  var discarding = false;
  $('#discardAllBtn').off('click').on('click', function () {
    if (discarding) return;
    showConfirm('Discard All Changes', 'Revert ALL pending devices to their previous values? This cannot be undone.', function () {
      discarding = true;
      ajax('discardAllChanges', {}, function (res) {
        discarding = false;
        if (res && res.success) {
          showAlert('success', 'Discarded changes for ' + res.affected + ' device(s).');
          $('#devicesTable').bootstrapTable('refresh');
          loadPendingCount();
        } else {
          showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  // =====================
  // DELETE SELECTED
  // =====================
  $('#deleteSelectedBtn').off('click').on('click', function () {
    if (selectedDeviceIds.length === 0) return;
    showConfirm('Delete Devices', 'Delete ' + selectedDeviceIds.length + ' device(s)? This cannot be undone.', function () {
      ajax('deleteDevices', { ids: selectedDeviceIds }, function (res) {
        if (res && res.success) {
          showAlert('success', 'Deleted ' + res.deleted + ' device(s).');
          $('#devicesTable').bootstrapTable('refresh');
          $('#phoneStatusTable').bootstrapTable('refresh');
          loadPendingCount();
        } else {
          showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  // =====================
  // AUTO-ASSIGN EXTENSIONS
  // =====================
  $('#autoAssignBtn').off('click').on('click', function () {
    var btn = $(this);
    btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Loading...');
    ajax('autoAssignExtensions', {}, function (res) {
      btn.prop('disabled', false).html('<i class="fa fa-magic"></i> Auto-Assign');
      if (!res || res.error) {
        showAlert('danger', res && res.error ? res.error : 'Auto-assign request failed.');
        return;
      }
      if (!res.success || !res.assignments || res.assignments.length === 0) {
        showAlert('info', 'No devices without extensions to assign.');
        return;
      }
      var html = '<p>Assign the following extensions?</p><table class="table table-condensed"><thead><tr><th>MAC</th><th>Extension</th></tr></thead><tbody>';
      $.each(res.assignments, function (i, a) {
        html += '<tr><td>' + a.mac + '</td><td><strong>' + a.extension + '</strong></td></tr>';
      });
      html += '</tbody></table>';
      showConfirm('Auto-Assign Extensions (' + res.assignments.length + ')', html, function () {
        ajax('autoAssignExtensions', { save: true }, function (res2) {
          if (res2 && res2.success) {
            var deployMode = (res2.deploy_mode) || 'dhcp';
            var msg = 'Assigned ' + res2.assignments.length + ' extension(s). Generating configs';
            if (deployMode === 'sip_notify') msg += ' and sending SIP NOTIFY...';
            else msg += ' and rebooting...';
            showAlert('success', msg);
            var pushAjax = deployMode === 'sip_notify' ? 'applyChangesWithNotify' : 'applyChanges';
            var pushData = deployMode === 'sip_notify' ? {} : { generate: true, reboot: true };
            ajax(pushAjax, pushData, function (res3) {
              if (res3 && res3.success) {
                var msg2 = 'Push completed.';
                if (res3.generated && res3.generated.length > 0) msg2 += ' Generated ' + res3.generated.length + ' config(s).';
                if (deployMode === 'sip_notify') {
                  if (res3.notify_sent && res3.notify_sent.length > 0) msg2 += ' NOTIFY sent to ' + res3.notify_sent.length + ' phone(s).';
                  if (res3.notify_failed && res3.notify_failed.length > 0) {
                    var errMap = {};
                    res3.notify_failed.forEach(function(f){ var e = f.error || 'unknown'; errMap[e] = (errMap[e] || 0) + 1; });
                    var errParts = Object.keys(errMap).map(function(e){ return errMap[e] > 1 ? e + ' (' + errMap[e] + ')' : e; });
                    msg2 += ' ' + res3.notify_failed.length + ' phone(s) failed — ' + errParts.join(', ');
                  }
                } else {
                  if (res3.reboots && res3.reboots.length > 0) msg2 += ' Reboot sent to ' + res3.reboots.length + ' phone(s).';
                }
                showAlert('success', msg2);
              } else {
                showAlert('warning', 'Assignment saved but config push had issues: ' + (res3 ? res3.error : 'Unknown error'));
              }
              $('#devicesTable').bootstrapTable('refresh');
              $('#phoneStatusTable').bootstrapTable('refresh');
              loadPendingCount();
            });
          } else {
            showAlert('danger', 'Assignment failed: ' + (res2 ? res2.error : 'Unknown error'));
          }
        });
      });
    });
  });

  // =====================
  // BULK HANDLER TAB PILLS
  // =====================
  $(document).on('click', '.bulk-pill', function (e) {
    e.preventDefault();
    var target = $(this).attr('href');
    $('.bulk-pill').closest('li').removeClass('active');
    $(this).closest('li').addClass('active');
    $('#import .tab-content.display .tab-pane').removeClass('active');
    $(target).addClass('active');
  });

  // =====================
  // BULK IMPORT
  // =====================
  // File upload handler — read CSV into textarea
  $('#importCsvFile').off('change').on('change', function () {
    var file = this.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function (e) {
      $('#importCsv').val(e.target.result);
    };
    reader.readAsText(file);
  });

  $('#importBtn').off('click').on('click', function () {
    var csv = $('#importCsv').val().trim();
    if (!csv) { showAlert('danger', 'Please provide CSV content.'); return; }
    ajax('bulkImport', { csv_content: csv }, function (res) {
      if (!res || res.error) {
        showAlert('danger', res && res.error ? 'Import failed: ' + res.error : 'Import failed.');
        return;
      }
    if (res.success > 0) {
        if (res.errors && res.errors.length > 0) {
          var html = '<div class="alert alert-warning"><strong>' + res.success + ' device(s) imported successfully with errors:</strong><ul style="margin-top:8px;">';
          $.each(res.errors, function (i, err) { html += '<li>' + err + '</li>'; });
          html += '</ul></div>';
          $('#importResults').html(html).show();
        } else {
          showAlert('success', res.success + ' device(s) imported successfully.');
        }
        $('#devicesTable').bootstrapTable('refresh');
        loadPendingCount(function () { openApplyModal(); });
      } else {
        var errHtml = 'Import failed: no devices imported.';
        if (res.errors && res.errors.length > 0) {
          errHtml += '<ul style="margin-top:8px;">';
          $.each(res.errors, function (i, err) { errHtml += '<li>' + err + '</li>'; });
          errHtml += '</ul>';
        }
        $('#importResults').html('<div class="alert alert-danger">' + errHtml + '</div>').show();
        $('#devicesTable').bootstrapTable('refresh');
    }
    });
  });

  // =====================
  // EXPORT CSV
  // =====================
  $('#exportCsvBtn').off('click').on('click', function () {
    ajax('exportCsv', {}, function (res) {
      if (res && res.success && res.csv) {
        var blob = new Blob([res.csv], { type: 'text/csv;charset=utf-8;' });
        var link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'provisioner_devices.csv';
        link.click();
        setTimeout(function () { URL.revokeObjectURL(link.href); }, 200);
      } else {
        showAlert('danger', 'Export failed.');
      }
    });
  });

  // =====================
  // PUSH CONFIG MODAL
  // =====================
  var selectedPushMacs = [];

  function openApplyModal() {
    var selCount = selectedPushMacs.length;
    var count = parseInt($('#pendingBadge').text()) || 0;
    $('#applyResults').hide();
    $('#applyResultsContent').empty();
    $('#applyProgress').hide();
    $('#applyOkBtn').html('<i class="fa fa-check"></i> Push').prop('disabled', false).data('retry', false);

    if (selCount > 0) {
      $('#applyCountDesc').hide();
      $('#applySelectedDesc').show();
      $('#applyNoChangesDesc').hide();
      $('#applySelectedCount').text(selCount);
      $('#applyGenerateCfg').prop('checked', false).closest('.checkbox').hide();
      $('#applyProgress').hide();
      $('#applyOkBtn').prop('disabled', false);
      $('#applyRebootRow').hide();
      $('#applyNotifyRow').show();
      $('#applyNotifyPush').prop('checked', true);
      updatePushBtnState();
      $('#applyModal').modal('show');
      return;
    }

    if (count === 0) {
      ajax('getSettings', {}, function (data) {
        var mode = (data && data.deploy_mode) || 'dhcp';
        if (mode !== 'sip_notify') return;
        $('#applyCountDesc').hide();
        $('#applySelectedDesc').hide();
        $('#applyNoChangesDesc').show();
        $('#applyCount').text(0);
        $('#applyGenerateCfg').prop('checked', false).closest('.checkbox').hide();
        $('#applyProgress').hide();
        $('#applyOkBtn').prop('disabled', false);
        $('#applyRebootRow').hide();
        $('#applyNotifyRow').show();
        $('#applyNotifyPush').prop('checked', true);
        updatePushBtnState();
        $('#applyModal').modal('show');
      });
      return;
    }

    $('#applyCountDesc').show();
    $('#applySelectedDesc').hide();
    $('#applyNoChangesDesc').hide();
    $('#applyCount').text(count);
    $('#applyGenerateCfg').prop('checked', true).closest('.checkbox').show();
    $('#applyProgress').hide();
    $('#applyOkBtn').prop('disabled', false);
    ajax('getSettings', {}, function (data) {
      var mode = (data && data.deploy_mode) || 'dhcp';
      if (mode === 'sip_notify') {
        $('#applyRebootRow').hide();
        $('#applyNotifyRow').show();
        $('#applyNotifyPush').prop('checked', true);
      } else {
        $('#applyRebootRow').show();
        $('#applyRebootPhones').prop('checked', pendingNeedsReboot).prop('disabled', false);
        $('#applyNotifyRow').hide();
      }
      updatePushBtnState();
      $('#applyModal').modal('show');
    });
  }

  $('#applyChangesBtn, #applyChangesPhoneBtn').off('click').on('click', function () {
    selectedPushMacs = [];
    var isPhoneBtn = $(this).is('#applyChangesPhoneBtn');
    if (isPhoneBtn) {
      var s = $('#phoneStatusTable').bootstrapTable('getSelections');
      $.each(s, function (i, row) { if (row.mac) selectedPushMacs.push(row.mac); });
    } else {
      var s = $('#devicesTable').bootstrapTable('getSelections');
      $.each(s, function (i, row) { if (row.mac_address) selectedPushMacs.push(row.mac_address); });
    }
    openApplyModal();
  });

  $('#applyModal').on('hidden.bs.modal', function () {
    selectedPushMacs = [];
    applying = false;
    $('#applyGenerateCfg').closest('.checkbox').show();
    $('#applyCountDesc').show();
    $('#applySelectedDesc').hide();
    $('#applyNoChangesDesc').hide();
    $('#applyOkBtn').html('<i class="fa fa-check"></i> Push');
    $('#applyResults').hide();
    $('#applyResultsContent').empty();
    $('#applyProgress').hide();
  });

  function updatePushBtnState() {
    var gen  = $('#applyGenerateCfg').is(':checked');
    var reboot = $('#applyRebootPhones').is(':checked');
    var notify = $('#applyNotifyPush').is(':checked');
    var anyAction = gen || reboot || notify;
    if ($('#applyNotifyRow').is(':visible')) {
      anyAction = gen || notify;
    }
    $('#applyOkBtn').prop('disabled', !anyAction);
  }

  $('#applyGenerateCfg, #applyRebootPhones, #applyNotifyPush').off('change').on('change', function () {
    updatePushBtnState();
  });

  function updateProgress(pct, text) {
    $('#applyProgressBar').css('width', pct + '%').text(pct + '%');
    $('#applyProgressText').text(text);
  }

  function showInlineResults(res) {
    var sent = res.notify_sent || res.sent || [];
    var failed = res.notify_failed || res.failed || [];
    var generated = res.generated || [];
    var html = '';
    if (sent.length > 0) {
      html += '<div class="alert alert-success" style="margin-bottom:8px;padding:8px 12px"><strong>NOTIFY sent</strong> — ' + sent.length + ' phone(s)</div>';
    }
    if (failed.length > 0) {
      var errMap = {};
      failed.forEach(function(f){ var e = f.error || 'unknown'; errMap[e] = (errMap[e] || 0) + 1; });
      var parts = Object.keys(errMap).map(function(e){ return errMap[e] > 1 ? e + ' (' + errMap[e] + ')' : e; });
      html += '<div class="alert alert-danger" style="margin-bottom:8px;padding:8px 12px"><strong>NOTIFY failed</strong> — ' + failed.length + ' phone(s): ' + parts.join(', ') + '</div>';
    }
    if (generated.length > 0) {
      html += '<p class="text-muted" style="margin-bottom:4px">Configs generated for ' + generated.length + ' device(s).</p>';
    }
    if (!html) html = '<p class="text-muted">No phones to notify.</p>';
    $('#applyResultsContent').html(html);
    $('#applyResults').show();
    if (failed.length > 0) {
      lastFailedMacs = failed.map(function(f){ return f.mac; }).filter(function(m){ return !!m; });
      $('#applyOkBtn').prop('disabled', false).text('Retry Failed (' + failed.length + ')').data('retry', true);
    } else {
      $('#applyOkBtn').prop('disabled', false).text('Close').data('retry', false);
    }
  }

  var applying = false;
  var lastFailedMacs = [];
  $('#applyOkBtn').off('click').on('click', function () {
    if ($(this).text() === 'Close') {
      $('#applyModal').modal('hide');
      return;
    }
    if ($('#applyOkBtn').data('retry')) {
      $('#applyProgress').show();
      updateProgress(40, 'Retrying ' + lastFailedMacs.length + ' failed phone(s)...');
      ajax('pushToPhones', { macs: lastFailedMacs }, function (res) {
        applying = false;
        $('#applyProgress').hide();
        if (res && res.success) {
          if (!$('#applyModal').is(':visible')) return;
          showInlineResults(res);
        } else {
          if (!$('#applyModal').is(':visible')) return;
          showInlineResults({ failed: lastFailedMacs.map(function(m){ return {mac: m, error: res ? res.error : 'Request failed'}; }) });
        }
        $('#devicesTable').bootstrapTable('refresh');
        $('#phoneStatusTable').bootstrapTable('refresh');
        loadPendingCount();
      });
      return;
    }
    if (applying) return;
    applying = true;
    $('#applyOkBtn').prop('disabled', true);
    $('#applyResults').hide();
    $('#applyProgress').show();
    var isSipNotify = $('#applyNotifyPush').length > 0 && $('#applyNotifyRow').is(':visible') && $('#applyNotifyPush').is(':checked');
    if (isSipNotify) {
      if (selectedPushMacs.length > 0) {
        updateProgress(40, 'Scanning network for phones...');
        ajax('pushToPhones', { macs: selectedPushMacs }, function (res) {
          applying = false;
          selectedPushMacs = [];
          $('#applyProgress').hide();
          if (res && res.success) {
            if (!$('#applyModal').is(':visible')) return;
            showInlineResults(res);
          } else {
            if (!$('#applyModal').is(':visible')) return;
            showInlineResults({ failed: [{ error: res ? res.error : 'Request failed' }] });
          }
          $('#devicesTable').bootstrapTable('refresh');
          $('#phoneStatusTable').bootstrapTable('refresh');
          loadPendingCount();
        });
      } else {
        updateProgress(10, 'Generating config files...');
        ajax('applyChanges', { generate: true, reboot: false }, function (res) {
          if (!res || !res.success) {
            applying = false;
            $('#applyProgress').hide();
            if (!$('#applyModal').is(':visible')) return;
            showInlineResults({ failed: [{ error: 'Generation failed: ' + (res ? res.error : 'Unknown error') }] });
            $('#devicesTable').bootstrapTable('refresh');
            $('#phoneStatusTable').bootstrapTable('refresh');
            loadPendingCount();
            return;
          }
          updateProgress(40, 'Scanning network for phones...');
          ajax('pushConfigToPhones', {}, function (res2) {
            applying = false;
            selectedPushMacs = [];
            $('#applyProgress').hide();
            if (res2 && res2.success) {
              res2.generated = res.generated || [];
              if (!$('#applyModal').is(':visible')) return;
              showInlineResults(res2);
            } else {
              if (!$('#applyModal').is(':visible')) return;
              showInlineResults({ generated: res.generated || [], failed: [{ error: res2 ? res2.error : 'Request failed' }] });
            }
            $('#devicesTable').bootstrapTable('refresh');
            $('#phoneStatusTable').bootstrapTable('refresh');
            loadPendingCount();
          });
        });
      }
    } else {
      var generate = $('#applyGenerateCfg').is(':checked');
      var reboot = $('#applyRebootPhones').is(':checked');
      ajax('applyChanges', { generate: generate, reboot: reboot }, function (res) {
        applying = false;
        $('#applyProgress').hide();
        $('#applyOkBtn').prop('disabled', false);
        if (res && res.success) {
          var msg = 'Push completed.';
          if (res.generated && res.generated.length > 0) msg += ' Generated ' + res.generated.length + ' config(s).';
          if (res.reboots && res.reboots.length > 0) msg += ' Reboot sent to ' + res.reboots.length + ' phone(s).';
          if (res.skipped_reboot > 0) msg += ' Skipped reboot for ' + res.skipped_reboot + ' new device(s).';
          showAlert('success', msg);
          $('#applyModal').modal('hide');
          $('#devicesTable').bootstrapTable('refresh');
          $('#phoneStatusTable').bootstrapTable('refresh');
          loadPendingCount();
        } else {
          showAlert('danger', 'Push failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    }
  });

  // =====================
  // PROVISIONING INFO
  // =====================
  function loadProvisioningInfo() {
    ajax('getProvisioningInfo', {}, function (data) {
      var html = '';
      if (!data) { html = '<p>Error loading provisioning info.</p>'; $('#provInfoBody').html(html); return; }
      ajax('getSettings', {}, function (settings) {
        var mode = (settings && settings.deploy_mode) || 'dhcp';
        var showOption66 = (mode === 'dhcp');
        html += '<dl class="dl-horizontal">';
        html += '  <dt>PBX IP</dt><dd>' + data.pbx_ip + '</dd>';
        html += '  <dt>Provisioning URL</dt><dd><code>http://' + data.pbx_ip + ':2001/provisioning/</code>';
        if (showOption66) {
          html += ' <button class="btn btn-xs btn-default" onclick="copyProvUrl(\'http://' + data.pbx_ip + ':2001/provisioning/\')"><i class="fa fa-copy"></i> Copy</button>';
        }
        html += '</dd>';
        html += '  <div id="dhcpOption66Status"></div>';
        html += '  <div id="firewallProvisioningStatus"></div>';
        html += '  <dt>Directory</dt><dd><code>' + data.prov_dir + '</code></dd>';
        var writableIcon = data.dir_writable === true ? '<span class="label label-success">Writable</span>' : (data.dir_writable === false ? '<span class="label label-danger">Not writable</span>' : '<span class="label label-warning">Missing</span>');
        html += '  <dt>Status</dt><dd>' + writableIcon + '</dd>';
        html += '  <dt>Device Configs</dt>';
        html += '  <dd><span id="provDeviceCount">' + data.device_count + '</span> file(s) &mdash; <a href="#" onclick="$(\'a[href=\\\'#configfiles\\\']\').tab(\'show\');return false;">View in Config Files</a></dd>';
        html += '</dl>';
        html += '<button class="btn btn-primary" id="generateAllConfigsBtn" style="margin-right:5px;"><i class="fa fa-cogs"></i> Generate All Configs</button>';
        html += '<button class="btn btn-danger" id="fixPermsBtn"><i class="fa fa-wrench"></i> Fix Permissions</button>';
        if (data.model_files && data.model_files.length > 0) {
          html += '<h5 style="margin-top:16px;">Model Files</h5>';
          html += '<table class="table table-condensed"><thead><tr><th>File</th><th>Size</th><th>Modified</th></tr></thead><tbody>';
          $.each(data.model_files, function (i, f) {
            html += '<tr><td><code>' + f.name + '</code></td><td>' + f.size + ' B</td><td>' + f.modified + '</td></tr>';
          });
          html += '</tbody></table>';
        }
        $('#provInfoBody').html(html);
        if (showOption66) {
          ajax('checkDhcpOption66', {}, function (res) {
        var statusDiv = $('#dhcpOption66Status');
        if (res && res.set && res.correct) {
          statusDiv.html(
            '<div class="alert alert-success" style="margin-top:10px;padding:8px 12px;">' +
            '<i class="fa fa-check-circle"></i> ' +
            '<strong>DHCP Option 66 configured correctly:</strong> <code>' + res.value + '</code>' +
            '</div>'
          );
        } else if (res && res.set && !res.correct) {
          statusDiv.html(
            '<div class="alert alert-warning" style="margin-top:10px;padding:8px 12px;">' +
            '<i class="fa fa-exclamation-triangle"></i> ' +
            '<strong>Option 66 misconfigured:</strong> set to <code>' + res.value + '</code>, ' +
            'expected <code>' + res.expected + '</code>. Update in ' +
            '<a href="config.php?display=sysadmin&view=dhcpd" target="_blank">System Admin &rarr; DHCP Server</a>' +
            '</div>'
          );
        } else {
          statusDiv.html(
            '<div class="alert alert-warning" style="margin-top:10px;padding:8px 12px;">' +
            '<i class="fa fa-exclamation-triangle"></i> ' +
            '<strong>Requirement:</strong> DHCP Option 66 (next-server) must point to the provisioning URL above. Configure in ' +
            '<a href="config.php?display=sysadmin&view=dhcpd" target="_blank">System Admin &rarr; DHCP Server</a> ' +
            'for phones to auto-discover and download their config.' +
            '</div>'
          );
        }
      });
      }
      ajax('checkFirewallProvisioning', {}, function (res) {
          var fwDiv = $('#firewallProvisioningStatus');
          if (res && !res.blocked) {
            fwDiv.html(
              '<div class="alert alert-success" style="margin-top:10px;padding:8px 12px;">' +
              '<i class="fa fa-check-circle"></i> ' +
              '<strong>Firewall:</strong> ' + res.message +
              '</div>'
            );
          } else if (res && res.blocked) {
            fwDiv.html(
              '<div class="alert alert-warning" style="margin-top:10px;padding:8px 12px;">' +
              '<i class="fa fa-exclamation-triangle"></i> ' +
              '<strong>Firewall blocks provisioning:</strong> ' + res.message +
              '</div>'
            );
          } else {
            fwDiv.html(
              '<div class="alert alert-info" style="margin-top:10px;padding:8px 12px;">' +
              '<i class="fa fa-info-circle"></i> ' +
              '<strong>Firewall:</strong> Unable to determine provisioning status.' +
              '</div>'
            );
          }
        });
      $('#generateAllConfigsBtn').off('click').on('click', function () {
        var btn = $(this);
        btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Generating...');
        ajax('generateAllConfigs', {}, function (res) {
          btn.prop('disabled', false).html('<i class="fa fa-cogs"></i> Generate All Configs');
          if (res && res.success) {
            showAlert('success', 'Generated ' + res.generated + ' config file(s).');
            loadProvisioningInfo();
            $('#configFilesTable').bootstrapTable('refresh');
          } else {
            showAlert('danger', 'Generation failed: ' + (res ? res.error : 'Unknown error'));
          }
        });
      });
      $('#fixPermsBtn').off('click').on('click', function () {
        ajax('generateProvisioning', {}, function (res) {
          if (res && res.success) showAlert('success', 'Permissions fixed.');
          else showAlert('danger', 'Failed: ' + (res ? res.output : 'Unknown error'));
        });
      });
    });
  });
  }

  // =====================
  // CONFIG FILES — DELETE ALL
  // =====================
  $('#deleteAllConfigBtn').off('click').on('click', function () {
    showConfirm('Delete All Config Files', 'Delete ALL generated config files? This cannot be undone. (MAC Mapping entries will not be deleted.)', function () {
      ajax('deleteAllConfigFiles', {}, function (res) {
        if (res && res.success) {
          showAlert('success', 'Deleted ' + res.deleted + ' config file(s).');
          $('#configFilesTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Error: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  // =====================
  // LOGS
  // =====================
  $('#clearLogsBtn').off('click').on('click', function () {
    showConfirm('Clear Logs', 'Are you sure you want to clear all logs?', function () {
      ajax('clearLogs', {}, function (res) {
        if (res && res.success) {
          showAlert('success', 'Logs cleared.');
          $('#logsTable').bootstrapTable('refresh');
        } else {
          showAlert('danger', 'Error clearing logs.');
        }
      });
    });
  });

  // =====================
  // SETTINGS
  // =====================
  function loadSettings() {
    ajax('getSettings', {}, function (data) {
      if (data) {
        if (data.pbx_ip)   $('#settingsPbxIp').val(data.pbx_ip);
        if (data.sip_port) $('#settingsSipPort').val(data.sip_port);
        if (data.transport) $('#settingsTransport').val(data.transport);
        if (data.prov_dir) $('#settingsProvDir').val(data.prov_dir);
        if (data.scan_subnets) $('#settingsScanSubnets').val(data.scan_subnets);
        if (data.phone_admin_pass) $('#settingsPhoneAdminPass').val(data.phone_admin_pass);
        if (data.phone_admin_pass_alcatel) $('#settingsPhoneAdminPassAlcatel').val(data.phone_admin_pass_alcatel);
        var mode = data.deploy_mode || 'dhcp';
        $('#modeDhcpLabel, #modeSipNotifyLabel').removeClass('mode-active');
        if (mode === 'sip_notify') {
          $('#modeSipNotify').prop('checked', true);
          $('#modeSipNotifyLabel').addClass('mode-active');
        } else {
          $('#modeDhcp').prop('checked', true);
          $('#modeDhcpLabel').addClass('mode-active');
        }
      }
    });
  }

  $('#savePbxSettingsBtn').off('click').on('click', function (e) {
    e.preventDefault();
    var data = {
      pbx_ip:   $('#settingsPbxIp').val(),
      sip_port: $('#settingsSipPort').val(),
      transport: $('#settingsTransport').val(),
      prov_dir: $('#settingsProvDir').val(),
      scan_subnets: $('#settingsScanSubnets').val()
    };
    ajax('saveSettings', data, function (res) {
      if (res && res.success) showAlert('success', 'PBX settings saved.');
      else showAlert('danger', 'Failed to save PBX settings.');
    });
  });

  $('#savePhoneAdminBtn').off('click').on('click', function (e) {
    e.preventDefault();
    var data = {
      phone_admin_pass: $('#settingsPhoneAdminPass').val(),
      phone_admin_pass_alcatel: $('#settingsPhoneAdminPassAlcatel').val()
    };
    ajax('saveSettings', data, function (res) {
      if (res && res.success) showAlert('success', 'Phone admin credentials saved.');
      else showAlert('danger', 'Failed to save credentials.');
    });
  });

  $('#saveDeployModeBtn').off('click').on('click', function () {
    var mode = $('input[name="deploy_mode"]:checked').val();
    if (!mode) { showAlert('warning', 'Please select a deployment mode.'); return; }
    var btn = $(this);
    btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Saving...');
    ajax('saveSettings', { deploy_mode: mode }, function (res) {
      btn.prop('disabled', false).html('<i class="fa fa-save"></i> Save Mode');
      if (res && res.success) {
        showAlert('success', 'Deployment mode set to ' + mode.replace('_', ' ') + '.');
        applyDiscoveryMode(mode);
        $('#modeDhcpLabel, #modeSipNotifyLabel').removeClass('mode-active');
        if (mode === 'sip_notify') {
          $('#modeSipNotifyLabel').addClass('mode-active');
        } else {
          $('#modeDhcpLabel').addClass('mode-active');
        }
        $('#deployModeSaveStatus').text('Saved!').fadeOut(2000);
      } else {
        showAlert('danger', 'Failed to save mode.');
      }
    });
  });

  // =====================
  // TEMPLATE
  // =====================
  var currentTemplateBrand = 'digium';

  function loadTemplate() {
    var brand = $('#templateBrand').val();
    currentTemplateBrand = brand;
    $('#templateContent').val('Loading...');
    ajax('getTemplateContent', { brand: brand }, function (res) {
      if (res && res.success) {
        $('#templateContent').val(res.content);
      } else {
        $('#templateContent').val('/* Error loading template */');
      }
    });
  }

  $('#templateBrand').off('change').on('change', function () {
    loadTemplate();
  });

  $('#saveTemplateBtn').off('click').on('click', function () {
    ajax('saveTemplateContent', {
      content: $('#templateContent').val(),
      brand: currentTemplateBrand
    }, function (res) {
      if (res && res.success) showAlert('success', 'Template saved.');
      else showAlert('danger', 'Save failed: ' + (res ? res.error : 'Unknown error'));
    });
  });

  $('#resetTemplateBtn').off('click').on('click', function () {
    showConfirm('Reset Template', 'Reset the template to its default content? Any edits will be lost.', function () {
      ajax('resetTemplate', { brand: currentTemplateBrand }, function (res) {
        if (res && res.success) { showAlert('success', 'Template reset to default.'); loadTemplate(); }
        else showAlert('danger', 'Reset failed: ' + (res ? res.error : 'Unknown error'));
      });
    });
  });

  // =====================
  // ALERTS / CONFIRM
  // =====================
  window.copyProvUrl = function(url) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(function () {
        showAlert('success', 'Provisioning URL copied to clipboard.');
      }).catch(function () {
        fallbackCopy(url);
      });
    } else {
      fallbackCopy(url);
    }
  };
  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(ta);
    showAlert('success', 'Provisioning URL copied to clipboard.');
  }

  function showAlert(type, message) {
    var keys = { success: 'success', danger: 'danger', info: 'info', warning: 'warning' };
    var cls = keys[type] || 'info';
    var html = '<div class="alert alert-' + cls + ' alert-dismissible" role="alert" style="position:fixed;top:60px;right:20px;z-index:99999;max-width:500px;">'
            + '<button type="button" class="close" data-dismiss="alert">&times;</button>'
            + message + '</div>';
    var $alert = $(html).appendTo('body');
    setTimeout(function () { $alert.alert('close'); }, 7000);
  }

  function showConfirm(title, message, callback) {
    var $modal = $(
      '<div class="modal fade" tabindex="-1" role="dialog">' +
        '<div class="modal-dialog" role="document">' +
          '<div class="modal-content">' +
            '<div class="modal-header"><h4 class="modal-title">' + title + '</h4><button type="button" class="close" data-dismiss="modal">&times;</button></div>' +
            '<div class="modal-body">' + message + '</div>' +
            '<div class="modal-footer">' +
              '<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>' +
              '<button type="button" class="btn btn-primary" id="confirmOk">OK</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>'
    ).appendTo('body');
    $modal.find('#confirmOk').on('click', function () {
      $modal.modal('hide');
      callback();
    });
    $modal.on('hidden.bs.modal', function () { $modal.remove(); });
    $modal.modal('show');
  }

  // =====================
  // TAB TRIGGERS
  // =====================
  $('a[href="#phones"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    $('#phoneStatusTable').bootstrapTable('refresh');
    $('#liveToggleBtn').show();
    if ($('#liveToggleBtn').data('active')) {
      startLiveRefresh();
    }
  });
  $('a[href="#devices"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    $('#devicesTable').bootstrapTable('refresh');
    loadPendingCount();
  });
  $('a[href="#provisioning"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    loadProvisioningInfo();
  });
  $('a[href="#discovered"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    ajax('getSettings', {}, function (data) {
      var mode = (data && data.deploy_mode) || 'dhcp';
      applyDiscoveryMode(mode);
    });
    if ($('#discoveredTable').is(':visible') && $('#discoveredTable').bootstrapTable('getData').length > 0) {
      refreshDiscoveredTable();
    }
    var input = document.getElementById('scan-subnet-input');
    if (input && !input.value) {
      ajax('scanNetwork', { subnet: '' }, function (res) {
        if (res && res.subnet) input.value = res.subnet;
      });
    }
  });
  $('a[href="#configfiles"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    $('#configFilesTable').bootstrapTable('refresh');
  });
  $('a[href="#logs"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    $('#logsTable').bootstrapTable('refresh');
  });
  $('a[href="#settings"]').off('shown.bs.tab').on('shown.bs.tab', function () {
    stopLiveRefresh();
    $('#liveToggleBtn').hide();
    loadSettings();
    loadTemplate();
  });

  // =====================
  // DEVICE DISCOVERY
  // =====================
  onTableSelect('discoveredTable', 'mac', selectedDhcpMacs);

  window.discoveredStatusFormatter = function (value, row) {
    if (row.status === 'added') {
      return '<span class="text-muted">Already in Mapping</span>';
    }
    return '<span class="text-success">New</span>';
  };

  window.discoveredActionsFormatter = function (value, row) {
    if (row.status === 'new') {
      return '<a class="clickable add-discovered-btn" data-mac="' + row.mac + '" data-ip="' + (row.ip || '') + '"><i class="fa fa-plus"></i> Add</a>';
    }
    return '-';
  };

  function applyDiscoveryMode(mode) {
    if (mode === 'sip_notify') {
      $('#scanBtnLabel').text('Scan Network');
      $('#discoveryCardTitle').text('Network Scan');
      $('#scanSubnetRow').show();
      $('#vendorCol').show();
    } else {
      $('#scanBtnLabel').text('Scan DHCP Leases');
      $('#discoveryCardTitle').text('DHCP Scan');
      $('#scanSubnetRow').hide();
      $('#vendorCol').hide();
    }
  }

  function refreshDiscoveredTable() {
    var label = $('#scanBtnLabel').text();
    if (label.indexOf('DHCP') !== -1) {
      ajax('getDhcpLeases', {}, function (res) {
        if (res && res.success && res.leases.length > 0) {
          $('#discoveredTable').bootstrapTable('load', res.leases).show();
        }
      });
    }
  }

  function updateDiscoveredRowStatus(mac, status) {
    var data = $('#discoveredTable').bootstrapTable('getData');
    var idx = data.findIndex(function (r) { return r.mac === mac; });
    if (idx !== -1) {
      data[idx].status = status;
      $('#discoveredTable').bootstrapTable('load', data);
    }
  }

  $('#discoveredTable').on('post-body.bs.table', function () {
    $('.add-discovered-btn').off('click').on('click', function () {
      var mac = $(this).data('mac');
      var ip  = $(this).data('ip') || '';
      ajax('addDiscoveredDevice', { mac: mac, extension: '', ip: ip }, function (res) {
        if (res && res.success) {
          showAlert('success', mac + ' added to MAC Mapping. Set its extension in the MAC Mapping tab.');
          updateDiscoveredRowStatus(mac, 'added');
          $('#devicesTable').bootstrapTable('refresh');
          loadPendingCount();
        } else {
          showAlert('danger', 'Failed to add ' + mac + ': ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  $('#autoDetectSubnetBtn').off('click').on('click', function () {
    var btn = $(this);
    btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Detecting...');
    ajax('getNetworkSubnets', {}, function (res) {
      btn.prop('disabled', false).html('<i class="fa fa-magic"></i> Auto Detect');
      if (res && res.success && res.subnets.length > 0) {
        $('#scan-subnet-input').val(res.subnets[0]);
        if (res.subnets.length > 1) {
          $('#scanStatus').html('<p class="text-muted">Also detected: <code>' + res.subnets.slice(1).join(', ') + '</code></p>').show();
        }
      } else {
        $('#scanStatus').html('<div class="alert alert-warning">Could not detect any subnets.</div>').show();
      }
    });
  });

  $('#scanDiscoveryBtn').off('click').on('click', function () {
    var btn = $(this);
    var btnLabel = $('#scanBtnLabel').text();
    var isDhcpMode = btnLabel.indexOf('DHCP') !== -1;

    btn.prop('disabled', true).find('#scanBtnLabel').html('<i class="fa fa-spinner fa-spin"></i> Scanning...');

    if (isDhcpMode) {
      ajax('getDhcpLeases', {}, function (res) {
        btn.prop('disabled', false).find('#scanBtnLabel').text('Scan DHCP Leases');
        if (!res || !res.success) {
          $('#scanStatus').html('<div class="alert alert-warning">' + (res ? res.error : 'Scan failed.') + '</div>').show();
          $('#discoveredTable').hide();
          return;
        }
        if (res.leases.length === 0) {
          $('#scanStatus').html('<div class="alert alert-info">No DHCP leases found.</div>').show();
          $('#discoveredTable').hide();
          return;
        }
        $('#scanStatus').html('<p class="text-muted"><strong>' + res.leases.length + '</strong> device(s) found in <code>' + res.file_path + '</code></p>').show();
        $('#discoveredTable').bootstrapTable('load', res.leases).show();
      });
    } else {
      var subnet = $('#scan-subnet-input').val().trim();
      if (!subnet) {
        btn.prop('disabled', false).find('#scanBtnLabel').text('Scan Network');
        $('#scanStatus').html('<div class="alert alert-warning">Enter a subnet or click <strong>Auto Detect</strong>.</div>').show();
        $('#discoveredTable').hide();
        return;
      }
      $('#spinner-scan').removeClass('hidden');
      ajax('scanNetwork', { subnet: subnet }, function (res) {
        btn.prop('disabled', false).find('#scanBtnLabel').text('Scan Network');
        $('#spinner-scan').addClass('hidden');
        if (!res || !res.success) {
          $('#scanStatus').html('<div class="alert alert-warning">' + (res ? res.error : 'Scan failed.') + '</div>').show();
          $('#discoveredTable').hide();
          return;
        }
        if (!res.devices || res.devices.length === 0) {
          $('#scanStatus').html('<div class="alert alert-info">No phones found in ' + (res.subnets ? res.subnets.join(', ') : res.subnet) + '.</div>').show();
          $('#discoveredTable').hide();
          return;
        }
        var rows = res.devices.map(function (d) {
          return {
            mac: d.mac || '',
            ip: d.ip || '',
            vendor: d.vendor || 'Unknown',
            status: d.in_provisioner ? 'added' : 'new'
          };
        });
        $('#scanStatus').html('<p class="text-muted"><strong>' + rows.length + '</strong> device(s) found in <code>' + (res.subnets ? res.subnets.join(', ') : res.subnet) + '</code></p>').show();
        $('#discoveredTable').bootstrapTable('load', rows).show();
      });
    }
  });

  $('#addSelectedDiscoveryBtn').off('click').on('click', function () {
    var macs = selectedDhcpMacs.slice();
    if (macs.length === 0) return;
    var allRows = $('#discoveredTable').bootstrapTable('getData');
    var newDevices = [];
    $.each(macs, function (i, mac) {
      var row = allRows.find(function (r) { return r.mac === mac; });
      if (row && row.status === 'new') {
        newDevices.push({ mac: mac, ip: row.ip || '' });
      }
    });
    if (newDevices.length === 0) {
      showAlert('info', 'All selected devices are already in MAC Mapping.');
      return;
    }
    var skipped = macs.length - newDevices.length;
    var msg = 'Add ' + newDevices.length + ' device(s) to MAC Mapping? Extensions will be empty — edit them in the MAC Mapping tab.';
    if (skipped > 0) msg += ' (' + skipped + ' already in mapping, skipped.)';
    showConfirm('Add Devices', msg, function () {
      ajax('addDiscoveredDevices', { devices: newDevices }, function (res) {
        if (res && res.success) {
          showAlert('success', 'Added ' + res.added + ' of ' + newDevices.length + ' device(s) to MAC Mapping.');
          $.each(newDevices, function (i, d) { updateDiscoveredRowStatus(d.mac, 'added'); });
          $('#devicesTable').bootstrapTable('refresh');
          loadPendingCount();
        } else {
          showAlert('danger', 'Failed: ' + (res ? res.error : 'Unknown error'));
        }
      });
    });
  });

  // Load first tab on start
  loadPendingCount();
});
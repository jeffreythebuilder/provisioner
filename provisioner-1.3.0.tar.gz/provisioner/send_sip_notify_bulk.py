#!/usr/bin/python3
import json, socket, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed

def send_notify_to_phone(phone):
    phone_ip = phone['phone_ip']
    pbx_ip = phone['pbx_ip']
    mac = phone['mac'].lower()
    uri = phone['uri']
    phone_port = phone.get('port', 5060)

    branch = mac[:8] if len(mac) >= 8 else mac
    call_id = "pnp-%s-%d" % (mac, int(time.time() * 1000))

    notify = "\r\n".join((
        "NOTIFY sip:%s:%d SIP/2.0" % (phone_ip, phone_port),
        "Via: SIP/2.0/UDP %s:{src_port};branch=z9hG4bK-%s" % (pbx_ip, branch),
        "Max-Forwards: 20",
        "Contact: <sip:provisioner@%s>" % pbx_ip,
        "To: <sip:%s@%s>" % (mac.upper(), pbx_ip),
        "From: <sip:provisioner@%s>" % pbx_ip,
        "Call-ID: %s" % call_id,
        "CSeq: 1 NOTIFY",
        "Content-Type: application/url",
        "Event: ua-profile",
        "Content-Length: %d" % len(uri),
        "",
        uri,
    ))

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('0.0.0.0', 0))
    src_port = s.getsockname()[1]
    packet = notify.format(src_port=src_port).encode()

    success = False
    for i in range(10):
        s.sendto(packet, (phone_ip, phone_port))
        s.settimeout(0.5)
        try:
            data, addr = s.recvfrom(4096)
            if b"200 OK" in data and b"CSeq: 1 NOTIFY" in data:
                success = True
                break
        except socket.timeout:
            pass

    s.close()
    return {'mac': mac, 'success': success, 'ip': phone_ip}

def main():
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'Usage: send_sip_notify_bulk.py <json_file>', 'results': {}}))
        sys.exit(1)

    with open(sys.argv[1]) as f:
        phones = json.load(f)

    results = {}
    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = {executor.submit(send_notify_to_phone, p): p for p in phones}
        for future in as_completed(futures):
            r = future.result()
            results[r['mac']] = {'success': r['success'], 'ip': r['ip']}

    print(json.dumps({'results': results}))

if __name__ == '__main__':
    main()

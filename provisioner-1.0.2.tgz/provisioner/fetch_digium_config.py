#!/usr/bin/env python3
import hashlib
import json
import sys
import requests


def md5_custom(text):
    return hashlib.md5(text.encode('latin-1')).hexdigest()


def fetch_config(ip, username, password, timeout=10):
    base_url = f"http://{ip}"
    session = requests.Session()
    try:
        session.get(f"{base_url}/config.txt", timeout=timeout, allow_redirects=True)
        r = session.get(f"{base_url}/key==nonce", timeout=timeout)
        nonce = r.text[:16]
        session.cookies.set("auth", nonce, domain=ip)
        md5_hash = md5_custom(f"{username}:{password}:{nonce}")
        encoded = f"{username}:{md5_hash}"
        session.post(f"{base_url}/", data={"encoded": encoded, "ReturnPage": "/"},
                     timeout=timeout, allow_redirects=True)
        r = session.get(f"{base_url}/config.txt", timeout=timeout)
        if "<title>Logon</title>" in r.text:
            return {"success": False, "error": "Auth failed — check credentials"}
        return {"success": True, "config": r.text}
    except requests.exceptions.ConnectionError:
        return {"success": False, "error": f"Could not connect to phone at {ip} — check network / IP"}
    except requests.exceptions.Timeout:
        return {"success": False, "error": f"Connection to phone at {ip} timed out"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print(json.dumps({"success": False, "error": "Usage: fetch_digium_config.py <ip> <username> <password>"}))
        sys.exit(1)
    ip = sys.argv[1]
    username = sys.argv[2]
    password = sys.argv[3]
    result = fetch_config(ip, username, password)
    print(json.dumps(result))
    sys.exit(0 if result["success"] else 1)

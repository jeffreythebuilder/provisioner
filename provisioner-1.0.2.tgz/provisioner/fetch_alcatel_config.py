#!/usr/bin/env python3
import json
import sys
import requests

requests.packages.urllib3.disable_warnings()


def fetch_config(ip, username, password, timeout=10):
    base_url = f"https://{ip}"
    session = requests.Session()
    session.verify = False

    try:
        r = session.post(f"{base_url}/wbm/api/account", json={
            "method": "login",
            "param": {"username": username, "password": password, "token": None},
            "sid": 0
        }, timeout=timeout)
        auth = r.json()
        if not auth.get("success"):
            return {"success": False, "error": "Auth failed — check credentials"}
        sid = auth["sid"]

        r = session.post(f"{base_url}/wbm/api/setting-all.xml", json={
            "method": "download",
            "sid": sid
        }, timeout=timeout)

        if not r.text.strip().startswith("<?xml"):
            return {"success": False, "error": "Unexpected response — not XML"}
        return {"success": True, "config": r.text}

    except requests.exceptions.ConnectionError:
        return {"success": False, "error": f"Could not connect to phone at {ip}"}
    except requests.exceptions.Timeout:
        return {"success": False, "error": f"Connection to phone at {ip} timed out"}
    except (KeyError, json.JSONDecodeError) as e:
        return {"success": False, "error": f"Unexpected auth response: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print(json.dumps({"success": False, "error": "Usage: fetch_alcatel_config.py <ip> <username> <password>"}))
        sys.exit(1)
    ip = sys.argv[1]
    username = sys.argv[2]
    password = sys.argv[3]
    result = fetch_config(ip, username, password)
    print(json.dumps(result))
    sys.exit(0 if result["success"] else 1)

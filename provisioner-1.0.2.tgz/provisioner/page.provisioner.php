<?php
echo '<link rel="stylesheet" href="/admin/modules/provisioner/assets/css/provisioner.css">';
echo '<script src="/admin/modules/provisioner/assets/js/provisioner.js"></script>';
echo FreePBX::Provisioner()->showPage();
<?php

namespace FreePBX\modules;

class Provisioner implements \BMO {
    private $db;

    private static $ouiMap = [
        '0004f3' => 'digium',
        '000fd3' => 'digium',
        '00809f' => 'alcatel',
        '08005a' => 'alcatel',
        '001c0e' => 'alcatel',
        '00236a' => 'alcatel',
        '3c28a6' => 'alcatel',
        '00037f' => 'yealink',
        '001565' => 'yealink',
        '000c41' => 'polycom',
        '00904f' => 'polycom',
        '000e53' => 'snom',
        '000413' => 'cisco',
        '001681' => 'grandstream',
    ];

    public function getBrandByMac($mac) {
        $prefix = substr(strtolower(preg_replace('/[^a-f0-9]/', '', $mac)), 0, 6);
        return self::$ouiMap[$prefix] ?? null;
    }

    public function getBrands() {
        $dirs = glob(__DIR__ . '/templates/*', GLOB_ONLYDIR);
        $brands = [];
        foreach ($dirs as $dir) {
            $name = basename($dir);
            if (file_exists("$dir/default.cfg")) $brands[] = $name;
        }
        sort($brands);
        return $brands;
    }

    public function getExtensions() {
        if (!class_exists('FreePBX') || !\FreePBX::Core()) return [];
        $users = \FreePBX::Core()->listUsers();
        $exts = [];
        foreach ($users as $u) {
            $exts[] = ['extension' => $u[0], 'name' => $u[1]];
        }
        return $exts;
    }

    public function autoAssignExtensions() {
        $stmt = $this->db->query("SELECT id, mac_address, extension FROM provisioner_devices ORDER BY mac_address ASC");
        $devices = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $assigned = array_column($devices, 'extension');
        $assigned = array_filter($assigned, fn($v) => $v !== '');

        if (!class_exists('FreePBX') || !\FreePBX::Core()) {
            return ['success' => false, 'error' => 'Cannot access FreePBX extensions'];
        }
        $users = \FreePBX::Core()->listUsers();
        $allExts = array_map(fn($u) => $u[0], $users);
        sort($allExts, SORT_NUMERIC);
        $freeExts = array_values(array_diff($allExts, $assigned));

        $assignments = [];
        foreach ($devices as $d) {
            if (empty($d['extension'])) {
                $ext = array_shift($freeExts);
                if ($ext === null) break;
                $assignments[] = ['id' => $d['id'], 'mac' => $d['mac_address'], 'extension' => $ext];
            }
        }

        if (!empty($_REQUEST['save'])) {
            $now = date('Y-m-d H:i:s');
            foreach ($assignments as $a) {
                $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, needs_changes=1, updated_at=? WHERE id=?");
                $stmt->execute([$a['extension'], $now, $a['id']]);
            }
            $this->addLog('device', "Auto-assigned " . count($assignments) . " extension(s)", 'success');
        }

        return ['success' => true, 'assignments' => $assignments];
    }

    public function exportCsv() {
        $rows = $this->db->query("SELECT extension, mac_address, brand, description FROM provisioner_devices ORDER BY extension ASC");
        $csv = "Extension,MAC,Brand,Description\n";
        while ($row = $rows->fetch(\PDO::FETCH_ASSOC)) {
            $csv .= '"' . $row['extension'] . '","' . $row['mac_address'] . '","' . ($row['brand'] ?: 'digium') . '","' . str_replace('"', '""', $row['description'] ?? '') . '"' . "\n";
        }
        return ['success' => true, 'csv' => $csv];
    }

    public function __construct($freepbx = null) {
        if ($freepbx) {
            $this->db = $freepbx->Database();
        }
    }

    public function install() {}
    public function uninstall() {}
    public function backup() {}
    public function restore($backup) {}
    public function doConfigPageInit($page) {}

    public function getSetting($key) {
        $stmt = $this->db->prepare("SELECT value FROM provisioner_settings WHERE key_name=?");
        $stmt->execute([$key]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $row['value'] : null;
    }

    public function setSetting($key, $value) {
        $stmt = $this->db->prepare("INSERT INTO provisioner_settings (key_name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value=?");
        $stmt->execute([$key, $value, $value]);
    }

    public function getSettings() {
        $stmt = $this->db->query("SELECT key_name, value FROM provisioner_settings");
        $settings = [];
        while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $settings[$row['key_name']] = $row['value'];
        }
        return $settings;
    }

    public function saveSettings($data) {
        $keys = ['pbx_ip', 'sip_port', 'transport', 'prov_dir', 'phone_admin_pass', 'phone_admin_pass_alcatel'];
        foreach ($keys as $key) {
            if (isset($data[$key])) {
                $this->setSetting($key, $data[$key]);
            }
        }
        $this->addLog('settings', 'Settings updated', 'success');
        return ['success' => true];
    }

    // =====================
    // DHCP LEASE SCANNER
    // =====================
    public function getDhcpLeases() {
        $files = [
            '/var/lib/misc/dnsmasq.leases',
            '/var/lib/dhcpd/dhcpd.leases'
        ];
        $leases = [];
        $readFile = null;
        foreach ($files as $f) {
            if (is_readable($f)) {
                $readFile = $f;
                break;
            }
        }
        if (!$readFile) {
            return [
                'success' => false,
                'error' => 'No DHCP lease file found at ' . implode(' or ', $files) . '. Make sure a DHCP server is running and the file is readable by the web server.',
                'leases' => [],
                'file_path' => ''
            ];
        }
        $content = file_get_contents($readFile);
        if ($content === false || trim($content) === '') {
            return ['success' => true, 'leases' => [], 'file_path' => $readFile];
        }
        $lines = explode("\n", $content);
        $isDnsmasq = false;
        foreach ($lines as $line) {
            if (preg_match('/^[\d]+\s+([\da-f:]{17})\s+/i', $line)) {
                $isDnsmasq = true;
                break;
            }
        }
        if ($isDnsmasq) {
            foreach ($lines as $line) {
                $line = trim($line);
                if (empty($line)) continue;
                if (preg_match('/^[\d]+\s+([\da-f:]{17})\s+([\d.]+)\s+(\S+)/i', $line, $m)) {
                    $mac = strtolower(preg_replace('/[^a-f0-9]/', '', $m[1]));
                    $ip  = $m[2];
                    $hostname = $m[3] === '*' ? '-' : $m[3];
                    $leases[$mac] = ['mac' => $mac, 'ip' => $ip, 'hostname' => $hostname];
                }
            }
        } else {
            $raw = $content;
            $blocks = preg_split('/\}\s*/', $raw);
            foreach ($blocks as $block) {
                $block = trim($block);
                if (empty($block)) continue;
                $ip = '';
                $mac = '';
                $hostname = '-';
                if (preg_match('/^lease\s+([\d.]+)\s*\{/i', $block, $m)) {
                    $ip = $m[1];
                }
                if (preg_match('/hardware\s+ethernet\s+([\da-f:]{17})/i', $block, $m)) {
                    $mac = strtolower(preg_replace('/[^a-f0-9]/', '', $m[1]));
                }
                if (preg_match('/client-hostname\s+"([^"]+)"/i', $block, $m)) {
                    $hostname = $m[1];
                }
                if ($mac) {
                    $leases[$mac] = ['mac' => $mac, 'ip' => $ip, 'hostname' => $hostname];
                }
            }
        }
        $existing = [];
        $stmt = $this->db->query("SELECT mac_address FROM provisioner_devices");
        while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $existing[$row['mac_address']] = true;
        }
        $result = [];
        foreach ($leases as $mac => $info) {
            $info['status'] = isset($existing[$mac]) ? 'added' : 'new';
            $result[] = $info;
        }
        usort($result, function ($a, $b) {
            return strcmp($a['mac'], $b['mac']);
        });
        return ['success' => true, 'leases' => $result, 'file_path' => $readFile];
    }

    // =====================
    // PHONE STATUS
    // =====================
    private function isPhoneReachable($ip) {
        $arp = @file_get_contents('/proc/net/arp');
        if (!$arp) return false;
        foreach (explode("\n", $arp) as $line) {
            $parts = preg_split('/\s+/', trim($line));
            if (isset($parts[0]) && $parts[0] === $ip && isset($parts[3]) && $parts[3] === '0x2') {
                return true;
            }
        }
        return false;
    }
    public function getPhoneStatus() {
        $output = shell_exec('asterisk -rx "pjsip show contacts" 2>/dev/null');
        $devices = $this->getDevices();
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $results = [];

        foreach ($devices as $device) {
            $needsChanges = !empty($device['needs_changes']);

            $ext  = $device['extension'];
            $desc = $device['description'];
            $mac  = $device['mac_address'];

            if ($needsChanges) {
                $ext  = $device['previous_extension'] !== null ? $device['previous_extension'] : $ext;
                $desc = $device['previous_description'] !== null ? $device['previous_description'] : $desc;
            }

            $configExists = file_exists($provDir . '/' . $mac . '.cfg') || file_exists($provDir . '/config.' . $mac . '.xml');

            $status = 'Unavailable';
            $ip     = '';

            if ($output) {
                foreach (explode("\n", $output) as $line) {
                    if (preg_match('/Contact:\s+' . preg_quote($ext, '/') . '\/sip:' . preg_quote($ext, '/') . '@([\d.]+).*?(Avail|Unavail)/i', $line, $matches)) {
                        $ip = $matches[1];
                        $status = $matches[2];
                        break;
                    }
                }
            }
            if (!$ip) {
                $leases = $this->getDhcpLeases();
                if ($leases['success']) {
                    foreach ($leases['leases'] as $lease) {
                        if ($lease['mac'] === $mac) {
                            $ip = $lease['ip'];
                            break;
                        }
                    }
                }
            }

            $results[] = [
                'extension'     => $ext,
                'mac'           => $mac,
                'description'   => $desc,
                'brand'         => $device['brand'] ?? 'digium',
                'ip'            => $ip,
                'status'        => $status,
                'needs_changes' => $needsChanges,
                'config_exists' => $configExists
            ];
        }

        return $results;
    }

    public function getPhoneStatusGrid() {
        $raw = $this->getPhoneStatus();
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $rows = [];
        foreach ($raw as $r) {
            $configExists = file_exists($provDir . '/' . $r['mac'] . '.cfg') || file_exists($provDir . '/config.' . $r['mac'] . '.xml');
            $isRegistered = $r['status'] === 'Avail' || $r['status'] === 'Unavail';
            $isAvail = $r['status'] === 'Avail';
            if ($r['needs_changes'] && $configExists) {
                $actions = '<a class="clickable reboot-btn" data-ext="' . $r['extension'] . '" title="Reboot"><i class="fa fa-power-off"></i></a>';
                $statusLabel = 'Reboot Required';
            } elseif ($r['needs_changes']) {
                $actions = '<span class="text-muted"><i class="fa fa-clock-o"></i> Push first</span>';
                $statusLabel = 'Config Pending';
            } elseif (!$r['config_exists']) {
                $actions = '<span class="text-muted"><i class="fa fa-file-text-o"></i> Push config</span>';
                $statusLabel = 'No Config';
            } elseif ($isAvail) {
                $actions = '<a class="clickable reboot-btn" data-ext="' . $r['extension'] . '" title="Reboot"><i class="fa fa-power-off"></i></a>';
                $statusLabel = 'Registered';
            } elseif ($isRegistered) {
                $actions = '<span class="text-muted"><i class="fa fa-power-off"></i></span>';
                $statusLabel = (!empty($r['ip']) && $this->isPhoneReachable($r['ip'])) ? 'Unreachable' : 'Offline';
            } elseif (!empty($r['ip'])) {
                $actions = '<a class="clickable reboot-btn" data-ext="' . $r['extension'] . '" title="Reboot"><i class="fa fa-power-off"></i></a>';
                $statusLabel = $this->isPhoneReachable($r['ip']) ? 'Online' : 'Offline';
            } else {
                $actions = '<span class="text-muted"><i class="fa fa-power-off"></i></span>';
                $statusLabel = 'Offline';
            }
            $rows[] = [
                'extension'   => $r['extension'],
                'mac'         => $r['mac'],
                'description' => $r['description'],
                'brand'       => ucfirst($r['brand']),
                'ip'          => $r['ip'],
                'status'      => $statusLabel,
                'actions'     => $actions
            ];
        }
        return $rows;
    }

    // =====================
    // REBOOT PHONE
    // =====================
    private function getBrandByExtension($extension) {
        $stmt = $this->db->prepare("SELECT brand FROM provisioner_devices WHERE extension=? OR previous_extension=?");
        $stmt->execute([$extension, $extension]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? ($row['brand'] ?? 'digium') : 'digium';
    }

    public function rebootPhone($extension) {
        $ext = preg_replace('/[^a-zA-Z0-9_-]/', '', $extension);
        $ip = $this->getPhoneIp($ext);
        if ($ip) {
            $output = shell_exec("asterisk -rx \"pjsip send notify sync-reboot-sangoma uri sip:$ip\" 2>/dev/null");
        } else {
            $output = shell_exec("asterisk -rx \"pjsip send notify sync-reboot-sangoma endpoint $ext\" 2>/dev/null");
        }
        $success = strpos($output, 'Sending NOTIFY') !== false;
        if ($success) {
            $this->db->prepare("UPDATE provisioner_devices SET needs_changes = 0, previous_extension = NULL, previous_description = NULL WHERE previous_extension = ? OR extension = ?")
                ->execute([$extension, $extension]);
        }
        $this->addLog('reboot', "Reboot sent to extension $extension" . ($ip ? " (IP: $ip)" : ""), $success ? 'success' : 'error');
        return ['success' => $success, 'output' => $output];
    }

    private function getPhoneIp($extension) {
        $ext = preg_replace('/[^a-zA-Z0-9_-]/', '', $extension);
        $output = shell_exec('asterisk -rx "pjsip show contacts" 2>/dev/null');
        if ($output) {
            foreach (explode("\n", $output) as $line) {
                if (preg_match('/Contact:\s+' . preg_quote($ext, '/') . '\/sip:' . preg_quote($ext, '/') . '@([\d.]+)/i', $line, $matches)) {
                    return $matches[1];
                }
            }
        }
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE extension=? OR previous_extension=?");
        $stmt->execute([$ext, $ext]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($row && !empty($row['mac_address'])) {
            $mac = $row['mac_address'];
            $leases = $this->getDhcpLeases();
            if ($leases['success']) {
                foreach ($leases['leases'] as $lease) {
                    if ($lease['mac'] === $mac) {
                        return $lease['ip'];
                    }
                }
            }
        }
        return null;
    }

    public function rebootPhones($extensions) {
        $results = [];
        foreach ($extensions as $ext) {
            $results[] = $this->rebootPhone($ext);
        }
        return ['success' => true, 'results' => $results];
    }

    // =====================
    // GENERATE PROVISIONING
    // =====================
    private function cleanDeviceConfig($mac, $provDir) {
        foreach ([$mac . '.cfg', 'config.' . $mac . '.xml'] as $file) {
            $path = $provDir . '/' . $file;
            if (file_exists($path)) unlink($path);
        }
    }

    private function generateDeviceConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $this->cleanDeviceConfig($device['mac_address'], $provDir);
        $brand = $device['brand'] ?? 'digium';
        $method = 'generate' . ucfirst($brand) . 'Config';
        if (method_exists($this, $method)) {
            return $this->$method($device, $template, $pbxIp, $sipPort, $transportVal, $provDir);
        }
        return null;
    }

    private function generateDigiumConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $ext = $device['extension'];
        $mac = $device['mac_address'];

        $stmt = $this->db->prepare("SELECT data FROM sip WHERE id = ? AND keyword = 'secret'");
        $stmt->execute([$ext]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            $stmt = $this->db->prepare("SELECT data FROM pjsip WHERE id = ? AND keyword = 'password'");
            $stmt->execute([$ext]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        }

        if (!$row) return null;

        $secret = $row['data'];
        $tcpUdp = $transportVal === '0' ? '0' : '1';

        $config = str_replace(
            ['{{MAC}}', '{{EXTENSION}}', '{{PBX_IP}}', '{{SIP_PORT}}', '{{SECRET}}', '{{TCP_UDP}}'],
            [$mac, $ext, $pbxIp, $sipPort, $secret, $tcpUdp],
            $template
        );

        file_put_contents($provDir . '/' . $mac . '.cfg', $config);
        return true;
    }

    private function generateAlcatelConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir) {
        $ext = $device['extension'];
        $mac = $device['mac_address'];

        $stmt = $this->db->prepare("SELECT data FROM sip WHERE id = ? AND keyword = 'secret'");
        $stmt->execute([$ext]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            $stmt = $this->db->prepare("SELECT data FROM pjsip WHERE id = ? AND keyword = 'password'");
            $stmt->execute([$ext]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        }

        if (!$row) return null;

        $secret = $row['data'];

        $config = str_replace(
            ['{{MAC}}', '{{EXTENSION}}', '{{PBX_IP}}', '{{SIP_PORT}}', '{{USERNAME}}', '{{PASSWORD}}', '{{TRANSPORT}}'],
            [$mac, $ext, $pbxIp, $sipPort, $ext, $secret, $transportVal === '0' ? '0' : '1'],
            $template
        );

        $file = 'config.' . $mac . '.xml';
        file_put_contents($provDir . '/' . $file, $config);
        return true;
    }

    public function generateProvisioning() {
        $dir = '/var/www/html/provisioning';
        $output = shell_exec("chown -R asterisk:asterisk $dir 2>&1");
        return ['success' => true, 'output' => $output];
    }

    public function generateAllConfigs() {
        $pbxIp   = $this->getSetting('pbx_ip') ?: '192.168.0.10';
        $sipPort = $this->getSetting('sip_port') ?: '5060';
        $transport = $this->getSetting('transport') ?: 'UDP';
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';

        $transportMap = ['UDP' => '0', 'TCP' => '1', 'TLS' => '2', 'TCP/UDP' => '0'];
        $transportVal = isset($transportMap[$transport]) ? $transportMap[$transport] : '0';

        $devices = $this->getDevices();
        if (empty($devices)) {
            return ['success' => true, 'generated' => 0, 'message' => 'No devices in MAC Mapping.'];
        }

        if (!is_dir($provDir)) {
            mkdir($provDir, 0755, true);
            @chown($provDir, 'asterisk');
            @chgrp($provDir, 'asterisk');
        }

        $templates = [];
        $generated = [];
        foreach ($devices as $device) {
            if (!empty($device['custom_config'])) continue;
            $brand = $device['brand'] ?? 'digium';
            if (!isset($templates[$brand])) {
                $templateFile = __DIR__ . '/templates/' . $brand . '/default.cfg';
                $templates[$brand] = file_exists($templateFile) ? file_get_contents($templateFile) : null;
            }
            $template = $templates[$brand];
            if ($template) {
                $result = $this->generateDeviceConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir);
                if ($result) {
                    $generated[] = $device['mac_address'];
                }
            }
        }

        $this->addLog('apply', 'Generated configs for ' . count($generated) . ' devices (all)', 'success');
        return ['success' => true, 'generated' => count($generated)];
    }

    // =====================
    // MAC MAPPING / DEVICES
    // =====================
    public function getDevices() {
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices ORDER BY extension ASC");
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getDeviceGrid() {
        $devices = $this->getDevices();
        $rows = [];
        foreach ($devices as $d) {
            $isPending = !empty($d['needs_changes']);
            $actions = '';
            $brandBadge = $this->brandBadge($d['brand'] ?? 'digium');
            $actions .= '<a class="clickable edit-device-btn" data-id="' . $d['id'] . '" data-mac="' . $d['mac_address'] . '" data-ext="' . $d['extension'] . '" data-desc="' . htmlspecialchars($d['description'] ?? '', ENT_QUOTES) . '" data-brand="' . ($d['brand'] ?? 'digium') . '" title="Edit"><i class="fa fa-edit"></i></a> ';
            if ($isPending) {
                $actions .= '<a class="clickable revert-device-btn" data-id="' . $d['id'] . '" title="Revert"><i class="fa fa-undo"></i></a> ';
            }
            $actions .= '<a class="clickable delete-device-btn" data-id="' . $d['id'] . '" data-ext="' . $d['extension'] . '" title="Delete"><i class="fa fa-trash"></i></a>';
            $rows[] = [
                'id'          => $d['id'],
                'extension'   => $d['extension'],
                'mac_address' => $d['mac_address'],
                'brand'       => $brandBadge,
                'description' => $d['description'] ?? '',
                'is_pending'  => $isPending,
                'actions'     => $actions
            ];
        }
        return $rows;
    }

    private function brandBadge($brand) {
        $colors = ['digium' => 'primary', 'alcatel' => 'info', 'yealink' => 'success', 'polycom' => 'warning'];
        $color = $colors[$brand] ?? 'default';
        return '<span class="badge badge-' . $color . '">' . htmlspecialchars(ucfirst($brand)) . '</span>';
    }

    public function getPendingCount() {
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE needs_changes = 1");
        $stmt->execute();
        $macs = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        $count = count($macs);
        if ($count === 0) {
            return ['count' => 0, 'needs_reboot' => false];
        }
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $allHaveConfig = true;
        foreach ($macs as $mac) {
            if (!file_exists($provDir . '/' . $mac . '.cfg') && !file_exists($provDir . '/config.' . $mac . '.xml')) {
                $allHaveConfig = false;
                break;
            }
        }
        return ['count' => $count, 'needs_reboot' => $allHaveConfig];
    }

    public function applyChanges($generate = true, $reboot = false) {
        $stmt = $this->db->prepare("SELECT * FROM provisioner_devices WHERE needs_changes = 1");
        $stmt->execute();
        $pending = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        if (empty($pending)) {
            return ['success' => true, 'affected' => 0, 'message' => 'No pending changes.'];
        }

        $generated = [];
        $rebootResults = [];

        if ($generate) {
            $pbxIp      = $this->getSetting('pbx_ip') ?: '192.168.0.10';
            $sipPort    = $this->getSetting('sip_port') ?: '5060';
            $transport  = $this->getSetting('transport') ?: 'UDP';
            $provDir    = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';

            $transportMap = ['UDP' => '0', 'TCP' => '1', 'TLS' => '2', 'TCP/UDP' => '0'];
            $transportVal = isset($transportMap[$transport]) ? $transportMap[$transport] : '0';

            $brands = [];
            foreach ($pending as $device) {
                if (!empty($device['custom_config'])) continue;
                $brand = $device['brand'] ?? 'digium';
                if (!isset($brands[$brand])) {
                    $templateFile = __DIR__ . '/templates/' . $brand . '/default.cfg';
                    $brands[$brand] = file_exists($templateFile) ? file_get_contents($templateFile) : null;
                }
            }

            if (!is_dir($provDir)) {
                mkdir($provDir, 0755, true);
                @chown($provDir, 'asterisk');
                @chgrp($provDir, 'asterisk');
            }

            foreach ($pending as $device) {
                if (!empty($device['custom_config'])) continue;
                $brand = $device['brand'] ?? 'digium';
                $template = $brands[$brand] ?? null;
                if ($template) {
                    $result = $this->generateDeviceConfig($device, $template, $pbxIp, $sipPort, $transportVal, $provDir);
                    if ($result) {
                        $generated[] = $device['mac_address'];
                    }
                }
            }

            $this->addLog('apply', 'Generated configs for ' . count($generated) . ' devices', 'success');
        }

        $skippedReboot = 0;
        if ($reboot) {
            foreach ($pending as $device) {
                $rebootExt = $device['previous_extension'] !== null ? $device['previous_extension'] : $device['extension'];
                if ($rebootExt === null) {
                    $skippedReboot++;
                    continue;
                }
                $result = $this->rebootPhone($rebootExt);
                $rebootResults[] = [
                    'extension' => $rebootExt,
                    'success'   => $result['success']
                ];
            }
        }

        if ($generate || $reboot) {
            $this->db->query("UPDATE provisioner_devices SET needs_changes = 0, previous_extension = NULL, previous_description = NULL WHERE needs_changes = 1");
        }

        return [
            'success'        => true,
            'affected'       => count($pending),
            'generated'      => $generated,
            'reboots'        => $rebootResults,
            'skipped_reboot' => $skippedReboot
        ];
    }

    public function addDevice($mac, $extension, $description = '', $brand = null) {
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        if ($brand === null || !in_array($brand, $this->getBrands())) {
            $detected = $this->getBrandByMac($mac);
            $brand = $detected ?: 'digium';
        }
        if (strlen($mac) !== 12) {
            return ['success' => false, 'error' => 'Invalid MAC address — must be 12 hex characters'];
        }

        $prevExt  = null;
        $prevDesc = null;
        $stmt = $this->db->prepare("SELECT id, extension, description, brand, previous_extension, previous_description FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $existing = $stmt->fetch(\PDO::FETCH_ASSOC);
        if ($existing) {
            if ($extension !== $existing['extension'] && $existing['previous_extension'] === null) {
                $prevExt = $existing['extension'];
            }
            if ($description !== $existing['description'] && $existing['previous_description'] === null) {
                $prevDesc = $existing['description'];
            }
        }

        $now = date('Y-m-d H:i:s');
        try {
            if ($existing) {
                $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, brand=?, needs_changes=1, previous_extension=COALESCE(previous_extension, ?), previous_description=COALESCE(previous_description, ?), updated_at=? WHERE mac_address=?");
                $stmt->execute([$extension, $description, $brand, $prevExt, $prevDesc, $now, $mac]);
            } else {
                $stmt = $this->db->prepare("INSERT INTO provisioner_devices (mac_address, extension, description, brand, needs_changes, previous_extension, previous_description, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?)");
                $stmt->execute([$mac, $extension, $description, $brand, $prevExt, $prevDesc, $now, $now]);
            }
            $this->addLog('device', ($existing ? 'Updated' : 'Added') . " device MAC:$mac EXT:$extension BRAND:$brand", 'success');
            return ['success' => true];
        } catch (\Exception $e) {
            try {
                $this->ensureTables();
                $now = date('Y-m-d H:i:s');
                if ($existing) {
                    $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, brand=?, needs_changes=1, previous_extension=COALESCE(previous_extension, ?), previous_description=COALESCE(previous_description, ?), updated_at=? WHERE mac_address=?");
                    $stmt->execute([$extension, $description, $brand, $prevExt, $prevDesc, $now, $mac]);
                } else {
                    $stmt = $this->db->prepare("INSERT INTO provisioner_devices (mac_address, extension, description, brand, needs_changes, previous_extension, previous_description, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?)");
                    $stmt->execute([$mac, $extension, $description, $brand, $prevExt, $prevDesc, $now, $now]);
                }
                $this->addLog('device', ($existing ? 'Updated' : 'Added') . " device MAC:$mac EXT:$extension BRAND:$brand", 'success');
                return ['success' => true];
            } catch (\Exception $e2) {
                $msg = $e2->getMessage();
                $this->addLog('device', "Failed to add device MAC:$mac EXT:$extension - $msg", 'error');
                return ['success' => false, 'error' => $msg];
            }
        }
    }

    public function addDiscoveredDevices($macs) {
        $added = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $clean = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
            if (strlen($clean) !== 12) {
                $errors[] = "$mac: invalid MAC";
                continue;
            }
            $stmt = $this->db->prepare("SELECT id FROM provisioner_devices WHERE mac_address=?");
            $stmt->execute([$clean]);
            if ($stmt->fetch()) {
                continue;
            }
            $result = $this->addDevice($mac, '', '');
            if ($result['success']) {
                $added++;
            } else {
                $errors[] = $mac . ': ' . $result['error'];
            }
        }
        $this->addLog('device', "Added $added discovered device(s) to MAC Mapping", 'success');
        return ['success' => true, 'added' => $added, 'errors' => $errors];
    }

    public function updateDevice($id, $mac, $extension, $description = '', $brand = null) {
        if ($brand !== null && !in_array($brand, $this->getBrands())) {
            $brand = 'digium';
        }
        $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $mac));
        if (strlen($mac) !== 12) {
            return ['success' => false, 'error' => 'Invalid MAC address — must be 12 hex characters'];
        }
        try {
            $stmt = $this->db->prepare("SELECT extension, description, previous_extension, previous_description FROM provisioner_devices WHERE id=?");
            $stmt->execute([$id]);
            $old = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$old) {
                return ['success' => false, 'error' => 'Device not found'];
            }

            $prevExt  = null;
            $prevDesc = null;
            if ($extension !== $old['extension'] && $old['previous_extension'] === null) {
                $prevExt = $old['extension'];
            }
            if ($description !== $old['description'] && $old['previous_description'] === null) {
                $prevDesc = $old['description'];
            }

            $now = date('Y-m-d H:i:s');
            $sql = "UPDATE provisioner_devices SET mac_address=?, extension=?, description=?, needs_changes=1, previous_extension=COALESCE(previous_extension, ?), previous_description=COALESCE(previous_description, ?), updated_at=? WHERE id=?";
            $params = [$mac, $extension, $description, $prevExt, $prevDesc, $now, $id];

            if ($brand !== null) {
                $sql = "UPDATE provisioner_devices SET mac_address=?, extension=?, description=?, brand=?, needs_changes=1, previous_extension=COALESCE(previous_extension, ?), previous_description=COALESCE(previous_description, ?), updated_at=? WHERE id=?";
                $params = [$mac, $extension, $description, $brand, $prevExt, $prevDesc, $now, $id];
            }

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $this->addLog('device', "Updated device ID:$id", 'success');
            return ['success' => true];
        } catch (\Exception $e) {
            $this->addLog('device', "Failed to update device ID:$id - " . $e->getMessage(), 'error');
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function deleteDevice($id) {
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE id=?");
        $stmt->execute([$id]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        $stmt = $this->db->prepare("DELETE FROM provisioner_devices WHERE id=?");
        $stmt->execute([$id]);
        if ($row) {
            $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
            $this->cleanDeviceConfig($row['mac_address'], $provDir);
        }
        $this->addLog('device', "Deleted device ID:$id", 'warning');
        return ['success' => true];
    }

    public function deleteDevices($ids) {
        if (!is_array($ids)) $ids = [$ids];
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $this->db->prepare("SELECT mac_address FROM provisioner_devices WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $macs = $stmt->fetchAll(\PDO::FETCH_COLUMN);
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        foreach ($macs as $mac) {
            $this->cleanDeviceConfig($mac, $provDir);
        }
        $stmt = $this->db->prepare("DELETE FROM provisioner_devices WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $this->addLog('device', "Deleted " . count($ids) . " device(s)", 'warning');
        return ['success' => true, 'deleted' => count($ids)];
    }

    public function bulkImport($csv) {
        $rows = explode("\n", trim($csv));
        $success = 0;
        $errors = [];
        foreach ($rows as $i => $line) {
            $line = trim($line);
            if (empty($line)) continue;
            if ($i === 0 && preg_match('/^(extension|mac|brand|description)/i', $line)) continue;
            $parts = str_getcsv($line);
            if (count($parts) < 2) {
                $errors[] = "Row " . ($i + 1) . ": invalid format";
                continue;
            }
            $ext = trim($parts[0]);
            $mac = trim($parts[1]);
            $brand = isset($parts[2]) && trim($parts[2]) !== '' ? trim($parts[2]) : null;
            $desc = isset($parts[3]) ? trim($parts[3]) : '';
            $result = $this->addDevice($mac, $ext, $desc, $brand);
            if ($result['success']) {
                $success++;
            } else {
                $errors[] = "Row " . ($i + 1) . ": " . $result['error'];
            }
        }
        $this->addLog('device', "Bulk imported $success devices", 'success');
        return ['success' => $success, 'errors' => $errors];
    }

    public function revertDevice($id) {
        $stmt = $this->db->prepare("SELECT extension, description, previous_extension, previous_description FROM provisioner_devices WHERE id=?");
        $stmt->execute([$id]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) {
            return ['success' => false, 'error' => 'Device not found'];
        }
        $newExt  = $device['previous_extension'] !== null ? $device['previous_extension'] : $device['extension'];
        $newDesc = $device['previous_description'] !== null ? $device['previous_description'] : $device['description'];
        $stmt = $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, needs_changes=0, previous_extension=NULL, previous_description=NULL WHERE id=?");
        $stmt->execute([$newExt, $newDesc, $id]);
        $this->addLog('device', "Reverted device ID:$id", 'info');
        return ['success' => true];
    }

    public function discardAllChanges() {
        $stmt = $this->db->query("SELECT id, previous_extension, previous_description FROM provisioner_devices WHERE needs_changes = 1");
        $affected = 0;
        while ($device = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $newExt  = $device['previous_extension'] !== null ? $device['previous_extension'] : '';
            $newDesc = $device['previous_description'] !== null ? $device['previous_description'] : '';
            $this->db->prepare("UPDATE provisioner_devices SET extension=?, description=?, needs_changes=0, previous_extension=NULL, previous_description=NULL WHERE id=?")
                ->execute([$newExt, $newDesc, $device['id']]);
            $affected++;
        }
        $this->addLog('device', "Discarded all changes for $affected device(s)", 'info');
        return ['success' => true, 'affected' => $affected];
    }

    // =====================
    // CONFIG FILES
    // =====================
    public function getConfigFiles() {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $files = [];
        if (!is_dir($provDir)) return $files;
        $dh = opendir($provDir);
        while (($file = readdir($dh)) !== false) {
            $ext = substr($file, -4);
            if ($ext === '.cfg') {
                $mac = substr($file, 0, -4);
            } elseif (preg_match('/^config\.([a-f0-9]{12})\.xml$/i', $file, $m)) {
                $mac = $m[1];
            } else {
                continue;
            }
            if (!preg_match('/^[a-f0-9]{12}$/', $mac)) continue;
            if ($file === 'template.cfg' || $file === 'default.cfg') continue;
            if (preg_match('/^f0A\d+hw1\.100\.cfg$/', $file)) continue;
            $path = $provDir . '/' . $file;
            $files[] = [
                'mac'      => $mac,
                'file'     => $file,
                'size'     => filesize($path),
                'modified' => date('Y-m-d H:i:s', filemtime($path))
            ];
        }
        closedir($dh);
        return $files;
    }

    public function getConfigFileGrid() {
        $files = $this->getConfigFiles();
        $devices = $this->getDevices();
        $deviceMap = [];
        foreach ($devices as $d) {
            $deviceMap[$d['mac_address']] = $d;
        }
        $rows = [];
        foreach ($files as $f) {
            $ext = isset($deviceMap[$f['mac']]) ? $deviceMap[$f['mac']]['extension'] : '-';
            $desc = isset($deviceMap[$f['mac']]) ? $deviceMap[$f['mac']]['description'] : '-';
            $custom = isset($deviceMap[$f['mac']]) && !empty($deviceMap[$f['mac']]['custom_config']);
            $pullBtn = $custom
                ? '<a class="clickable revert-config-btn" data-mac="' . $f['mac'] . '" title="Revert to template-generated config"><i class="fa fa-undo"></i></a>'
                : '<a class="clickable fetch-config-btn" data-mac="' . $f['mac'] . '" title="Fetch current config from phone"><i class="fa fa-download"></i></a>';
            $badge = $custom ? ' <span class="badge badge-warning" style="font-size:10px;">Custom</span>' : '';
            $rows[] = [
                'mac'         => $f['mac'],
                'extension'   => $ext,
                'description' => $desc,
                'modified'    => $f['modified'],
                'actions'     => '<a class="clickable edit-config-btn" data-mac="' . $f['mac'] . '" data-ext="' . $ext . '" title="Edit"><i class="fa fa-edit"></i></a> '
                    . $pullBtn
                    . ' <a class="clickable delete-config-btn" data-mac="' . $f['mac'] . '" title="Delete"><i class="fa fa-trash"></i></a>'
            ];
        }
        return $rows;
    }

    private function getDeviceBrand($mac) {
        $stmt = $this->db->prepare("SELECT brand FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $row['brand'] : 'digium';
    }

    private function getDeviceConfigFilename($mac) {
        $brand = $this->getDeviceBrand($mac);
        return $brand === 'alcatel' ? 'config.' . $mac . '.xml' : $mac . '.cfg';
    }

    private function getConfigFilePath($mac) {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        return $provDir . '/' . $this->getDeviceConfigFilename($mac);
    }

    public function getConfigFileContent($mac) {
        $path = $this->getConfigFilePath($mac);
        if (!file_exists($path)) {
            return ['success' => false, 'error' => 'Config file not found'];
        }
        $ext = $this->getExtensionByMac($mac);
        return ['success' => true, 'content' => file_get_contents($path), 'extension' => $ext];
    }

    public function saveConfigFile($mac, $content) {
        $path = $this->getConfigFilePath($mac);
        $result = file_put_contents($path, $content);
        if ($result === false) {
            $this->addLog('config', "Failed to save config for $mac", 'error');
            return ['success' => false, 'error' => 'Failed to write config file'];
        }
        $this->addLog('config', "Saved config for $mac", 'success');
        return ['success' => true];
    }

    public function deleteConfigFile($mac) {
        $path = $this->getConfigFilePath($mac);
        if (file_exists($path)) {
            unlink($path);
        }
        $this->addLog('config', "Deleted config for $mac", 'warning');
        return ['success' => true];
    }

    public function deleteSelectedConfigFiles($macs) {
        $count = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $r = $this->deleteConfigFile($mac);
            if ($r['success']) $count++;
            else $errors[] = $mac;
        }
        $this->addLog('config', "Deleted $count config files", 'warning');
        return ['success' => true, 'deleted' => $count, 'errors' => $errors];
    }

    public function deleteAllConfigFiles() {
        $files = $this->getConfigFiles();
        $count = 0;
        foreach ($files as $f) {
            $this->deleteConfigFile($f['mac']);
            $count++;
        }
        $this->addLog('config', "Deleted all $count config files", 'warning');
        return ['success' => true, 'deleted' => $count];
    }

    private function runFetchScript($mac, $ext, $ip) {
        $brand = $this->getDeviceBrand($mac);
        if ($brand === 'alcatel') {
            $script = 'fetch_alcatel_config.py';
            $pass = $this->getSetting('phone_admin_pass_alcatel') ?: '123456';
        } else {
            $script = 'fetch_digium_config.py';
            $pass = $this->getSetting('phone_admin_pass') ?: '789';
        }
        $cmd = 'python3 ' . escapeshellarg(__DIR__ . '/' . $script)
             . ' ' . escapeshellarg($ip)
             . ' admin'
             . ' ' . escapeshellarg($pass) . ' 2>&1';
        $output = shell_exec($cmd);
        return json_decode($output, true);
    }

    public function pullPhoneConfig($mac) {
        $stmt = $this->db->prepare("SELECT extension FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) {
            return ['success' => false, 'error' => 'Device not found in MAC Mapping'];
        }
        $ext = $device['extension'];
        $ip = $this->getPhoneIp($ext);
        if (!$ip) {
            return ['success' => false, 'error' => "Could not determine IP for extension $ext — phone may not be registered or on DHCP"];
        }
        $result = $this->runFetchScript($mac, $ext, $ip);
        if (!$result || !$result['success']) {
            $error = $result['error'] ?? 'Script execution failed';
            $this->addLog('config', "Pull config failed for $mac: $error", 'error');
            return ['success' => false, 'error' => $error];
        }
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        if (!is_dir($provDir)) {
            mkdir($provDir, 0755, true);
            @chown($provDir, 'asterisk');
            @chgrp($provDir, 'asterisk');
        }
        $filename = $this->getDeviceConfigFilename($mac);
        $path = $provDir . '/' . $filename;
        $bakPath = $provDir . '/' . $filename . '.bak';
        if (file_exists($path)) {
            copy($path, $bakPath);
        }
        $written = file_put_contents($path, $result['config']);
        if ($written === false) {
            return ['success' => false, 'error' => 'Failed to write config file'];
        }
        $this->db->prepare("UPDATE provisioner_devices SET custom_config=1 WHERE mac_address=?")->execute([$mac]);
        $this->addLog('config', "Pulled config from phone for $mac (ext $ext) via $ip", 'success');
        return ['success' => true, 'message' => "Config pulled from phone ($ip). The previous config was backed up."];
    }

    public function fetchPhoneConfig($mac) {
        $stmt = $this->db->prepare("SELECT extension FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $device = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$device) {
            return ['success' => false, 'error' => 'Device not found in MAC Mapping'];
        }
        $ext = $device['extension'];
        $ip = $this->getPhoneIp($ext);
        if (!$ip) {
            return ['success' => false, 'error' => "Could not determine IP for extension $ext — phone may not be registered or on DHCP"];
        }
        $result = $this->runFetchScript($mac, $ext, $ip);
        if (!$result || !$result['success']) {
            $error = $result['error'] ?? 'Script execution failed';
            $this->addLog('config', "Fetch config failed for $mac: $error", 'error');
            return ['success' => false, 'error' => $error];
        }
        $this->addLog('config', "Fetched config from phone for $mac (ext $ext) via $ip", 'info');
        return ['success' => true, 'config' => $result['config'], 'extension' => $ext];
    }

    public function saveAsActiveConfig($mac, $content) {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        if (!is_dir($provDir)) {
            mkdir($provDir, 0755, true);
            @chown($provDir, 'asterisk');
            @chgrp($provDir, 'asterisk');
        }
        $filename = $this->getDeviceConfigFilename($mac);
        $path = $provDir . '/' . $filename;
        $bakPath = $provDir . '/' . $filename . '.bak';
        if (file_exists($path)) {
            copy($path, $bakPath);
        }
        $written = file_put_contents($path, $content);
        if ($written === false) {
            return ['success' => false, 'error' => 'Failed to write config file'];
        }
        $this->db->prepare("UPDATE provisioner_devices SET custom_config=1 WHERE mac_address=?")->execute([$mac]);
        $this->addLog('config', "Saved fetched config for $mac (with backup)", 'success');
        return ['success' => true, 'message' => "Config saved as active config. Previous file backed up."];
    }

    public function revertConfigTemplate($mac) {
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $filename = $this->getDeviceConfigFilename($mac);
        $cfgPath = $provDir . '/' . $filename;
        $bakPath = $provDir . '/' . $filename . '.bak';
        $restored = false;
        if (file_exists($bakPath)) {
            rename($bakPath, $cfgPath);
            $restored = true;
        } else {
            if (file_exists($cfgPath)) {
                unlink($cfgPath);
            }
        }
        $this->db->prepare("UPDATE provisioner_devices SET custom_config=0 WHERE mac_address=?")->execute([$mac]);
        $msg = $restored
            ? 'Reverted to previous config by restoring from backup.'
            : 'Reverted to template. Config will be regenerated on next push.';
        $this->addLog('config', "Reverted $mac" . ($restored ? ' (restored from backup)' : ''), 'info');
        return ['success' => true, 'message' => $msg];
    }

    public function pullSelectedConfigFiles($macs) {
        $count = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $r = $this->pullPhoneConfig($mac);
            if ($r['success']) $count++;
            else $errors[] = ['mac' => $mac, 'error' => $r['error']];
        }
        $this->addLog('config', "Bulk pull: $count succeeded, " . count($errors) . " failed", $errors ? 'warning' : 'success');
        return ['success' => true, 'pulled' => $count, 'errors' => $errors];
    }

    public function revertSelectedConfigFiles($macs) {
        $count = 0;
        $errors = [];
        foreach ($macs as $mac) {
            $r = $this->revertConfigTemplate($mac);
            if ($r['success']) $count++;
            else $errors[] = ['mac' => $mac, 'error' => $r['error']];
        }
        $this->addLog('config', "Bulk revert: $count succeeded, " . count($errors) . " failed", $errors ? 'warning' : 'success');
        return ['success' => true, 'reverted' => $count, 'errors' => $errors];
    }

    private function getExtensionByMac($mac) {
        $stmt = $this->db->prepare("SELECT extension FROM provisioner_devices WHERE mac_address=?");
        $stmt->execute([$mac]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ? $row['extension'] : '';
    }

    // =====================
    // PROVISIONING INFO
    // =====================
    public function getProvisioningInfo() {
        $pbxIp = $this->getSetting('pbx_ip') ?: '192.168.0.10';
        $provDir = $this->getSetting('prov_dir') ?: '/var/www/html/provisioning';
        $isDir = is_dir($provDir);
        $writable = $isDir && is_writable($provDir) ? true : ($isDir ? false : 'missing');
        $deviceCount = 0;
        $modelFiles = [];
        if ($isDir) {
            $dh = opendir($provDir);
            while (($file = readdir($dh)) !== false) {
                $ext = substr($file, -4);
                $path = $provDir . '/' . $file;
                if ($ext === '.cfg') {
                    if (preg_match('/^f0A\d+hw1\.100\.cfg$/', $file)) {
                        $modelFiles[] = [
                            'name'     => $file,
                            'size'     => filesize($path),
                            'modified' => date('Y-m-d H:i:s', filemtime($path))
                        ];
                    } elseif ($file !== 'template.cfg' && preg_match('/^[a-f0-9]{12}\.cfg$/i', $file)) {
                        $deviceCount++;
                    }
                } elseif (preg_match('/^config\.[a-f0-9]{12}\.xml$/i', $file)) {
                    $deviceCount++;
                }
            }
            closedir($dh);
        }

        $modelCount = count($modelFiles);
        asort($modelFiles);

        return [
            'pbx_ip'       => $pbxIp,
            'prov_dir'     => $provDir,
            'dir_exists'   => $isDir,
            'dir_writable' => $writable,
            'device_count' => $deviceCount,
            'model_count'  => $modelCount,
            'model_files'  => array_values($modelFiles)
        ];
    }

    public function checkDhcpOption66() {
        $expected = 'http://' . ($this->getSetting('pbx_ip') ?: '192.168.0.10') . ':2001/provisioning/';
        $path = '/etc/asterisk/dnsmasq.conf';
        if (!file_exists($path) || !is_readable($path)) {
            return ['set' => false, 'correct' => false, 'value' => null, 'expected' => $expected];
        }
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (preg_match('/^dhcp-option\s*=\s*[^,]+,\s*66\s*,\s*(.*)$/i', trim($line), $m)) {
                $value = trim($m[1]);
                return ['set' => true, 'correct' => $value === $expected, 'value' => $value, 'expected' => $expected];
            }
        }
        return ['set' => false, 'correct' => false, 'value' => null, 'expected' => $expected];
    }

    // =====================
    // LOGS
    // =====================
    public function addLog($action, $details, $status = 'info') {
        try {
            $stmt = $this->db->prepare("INSERT INTO provisioner_logs (timestamp, action, details, status) VALUES (NOW(), ?, ?, ?)");
            $stmt->execute([$action, $details, $status]);
        } catch (\Exception $e) {}
    }

    public function getLogs($limit = 100) {
        $stmt = $this->db->prepare("SELECT * FROM provisioner_logs ORDER BY id DESC LIMIT ?");
        $stmt->bindValue(1, (int)$limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getLogGrid() {
        $rows = $this->getLogs(200);
        $result = [];
        foreach ($rows as $r) {
            $statusClass = $r['status'] === 'success' ? 'text-success' : ($r['status'] === 'error' ? 'text-danger' : 'text-muted');
            $result[] = [
                'timestamp' => $r['timestamp'],
                'action'    => $r['action'],
                'details'   => $r['details'],
                'status'    => '<span class="' . $statusClass . '">' . ucfirst($r['status']) . '</span>'
            ];
        }
        return $result;
    }

    public function clearLogs() {
        $this->db->query("DELETE FROM provisioner_logs");
        $this->addLog('logs', 'Logs cleared', 'warning');
        return ['success' => true];
    }

    // =====================
    // TEMPLATE
    // =====================
    public function getTemplateContent($brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $path = __DIR__ . '/templates/' . $brand . '/default.cfg';
        if (!file_exists($path)) {
            // Fallback to digium
            $path = __DIR__ . '/templates/digium/default.cfg';
        }
        if (!file_exists($path)) {
            return ['success' => false, 'error' => 'Template file not found.'];
        }
        $raw = file_get_contents($path);
        if ($raw === false) {
            return ['success' => false, 'error' => 'Failed to read template.'];
        }
        return ['success' => true, 'content' => $raw];
    }

    public function saveTemplateContent($content, $brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $path = __DIR__ . '/templates/' . $brand . '/default.cfg';
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $result = file_put_contents($path, $content);
        if ($result === false) {
            return ['success' => false, 'error' => 'Failed to write template.'];
        }
        $this->addLog('settings', "$brand template saved", 'success');
        return ['success' => true];
    }

    public function getDefaultTemplateContent($brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $path = __DIR__ . '/templates/' . $brand . '/default.cfg.dist';
        if (!file_exists($path)) {
            $path = __DIR__ . '/templates/digium/default.cfg.dist';
        }
        if (!file_exists($path)) {
            return ['success' => false, 'error' => 'Default template not found.'];
        }
        $raw = file_get_contents($path);
        return ['success' => true, 'content' => $raw];
    }

    public function resetTemplate($brand = 'digium') {
        if (!in_array($brand, $this->getBrands())) $brand = 'digium';
        $dist = __DIR__ . '/templates/' . $brand . '/default.cfg.dist';
        if (!file_exists($dist)) {
            $dist = __DIR__ . '/templates/digium/default.cfg.dist';
        }
        $target = __DIR__ . '/templates/' . $brand . '/default.cfg';
        if (file_exists($dist)) {
            copy($dist, $target);
            $this->addLog('settings', "$brand template reset to default", 'success');
            return ['success' => true];
        }
        return ['success' => false, 'error' => 'Default template not found.'];
    }

    // =====================
    // AJAX
    // =====================
    public function ajaxRequest($req, &$setting) {
        $allowed = [
            'getPhoneStatus', 'getPhoneStatusGrid', 'rebootPhone', 'rebootPhones', 'generateProvisioning',
            'getDevices', 'getDeviceGrid', 'addDevice', 'updateDevice', 'deleteDevice', 'deleteDevices',
            'bulkImport', 'getLogs', 'getLogGrid', 'clearLogs',
            'getSettings', 'saveSettings',
            'getPendingCount', 'applyChanges',
            'revertDevice', 'discardAllChanges',
            'getProvisioningInfo', 'generateAllConfigs', 'getConfigFiles', 'getConfigFileGrid', 'getConfigFileContent', 'saveConfigFile', 'deleteConfigFile', 'deleteSelectedConfigFiles', 'deleteAllConfigFiles',
            'getTemplateContent', 'saveTemplateContent',
            'getDefaultTemplateContent', 'resetTemplate',
            'getDhcpLeases', 'addDiscoveredDevice', 'addDiscoveredDevices',
            'getBrands',
            'getExtensions', 'autoAssignExtensions', 'exportCsv', 'checkDhcpOption66',
            'pullPhoneConfig', 'revertConfigTemplate',
            'pullSelectedConfigFiles', 'revertSelectedConfigFiles',
            'fetchPhoneConfig', 'saveAsActiveConfig'
        ];
        return in_array($req, $allowed);
    }

    public function ajaxHandler() {
        $command = $_REQUEST['command'];
        switch ($command) {
            case 'getPhoneStatus':
                return $this->getPhoneStatus();

            case 'getPhoneStatusGrid':
                return $this->getPhoneStatusGrid();

            case 'rebootPhone':
                return $this->rebootPhone($_REQUEST['extension']);

            case 'rebootPhones':
                return $this->rebootPhones($_REQUEST['extensions']);

            case 'getProvisioningInfo':
                return $this->getProvisioningInfo();

            case 'checkDhcpOption66':
                return $this->checkDhcpOption66();

            case 'generateProvisioning':
                return $this->generateProvisioning();

            case 'generateAllConfigs':
                return $this->generateAllConfigs();

            case 'getDevices':
                return $this->getDevices();

            case 'getDeviceGrid':
                return $this->getDeviceGrid();

            case 'deleteDevices':
                return $this->deleteDevices($_REQUEST['ids']);

            case 'addDevice':
                return $this->addDevice(
                    $_REQUEST['mac'],
                    $_REQUEST['extension'],
                    $_REQUEST['description'] ?? '',
                    $_REQUEST['brand'] ?? null
                );

            case 'updateDevice':
                return $this->updateDevice(
                    $_REQUEST['id'],
                    $_REQUEST['mac'],
                    $_REQUEST['extension'],
                    $_REQUEST['description'] ?? '',
                    $_REQUEST['brand'] ?? null
                );

            case 'deleteDevice':
                return $this->deleteDevice($_REQUEST['id']);

            case 'bulkImport':
                return $this->bulkImport($_REQUEST['csv_content']);

            case 'getLogs':
                return $this->getLogs(isset($_REQUEST['limit']) ? $_REQUEST['limit'] : 100);

            case 'getLogGrid':
                return $this->getLogGrid();

            case 'clearLogs':
                return $this->clearLogs();

            case 'getSettings':
                return $this->getSettings();

            case 'saveSettings':
                return $this->saveSettings($_REQUEST);

            case 'getPendingCount':
                return $this->getPendingCount();

            case 'applyChanges':
                $generate = isset($_REQUEST['generate']) && ($_REQUEST['generate'] === true || $_REQUEST['generate'] === 'true' || $_REQUEST['generate'] === '1');
                $reboot   = isset($_REQUEST['reboot']) && ($_REQUEST['reboot'] === true || $_REQUEST['reboot'] === 'true' || $_REQUEST['reboot'] === '1');
                return $this->applyChanges($generate, $reboot);

            case 'revertDevice':
                return $this->revertDevice($_REQUEST['id']);

            case 'discardAllChanges':
                return $this->discardAllChanges();

            case 'getConfigFiles':
                return $this->getConfigFiles();

            case 'getConfigFileGrid':
                return $this->getConfigFileGrid();

            case 'getConfigFileContent':
                return $this->getConfigFileContent($_REQUEST['mac']);

            case 'saveConfigFile':
                return $this->saveConfigFile($_REQUEST['mac'], $_REQUEST['content']);

            case 'deleteConfigFile':
                return $this->deleteConfigFile($_REQUEST['mac']);

            case 'deleteSelectedConfigFiles':
                return $this->deleteSelectedConfigFiles($_REQUEST['macs']);

            case 'deleteAllConfigFiles':
                return $this->deleteAllConfigFiles();

            case 'getTemplateContent':
                return $this->getTemplateContent($_REQUEST['brand'] ?? 'digium');

            case 'saveTemplateContent':
                return $this->saveTemplateContent($_REQUEST['content'], $_REQUEST['brand'] ?? 'digium');

            case 'getDefaultTemplateContent':
                return $this->getDefaultTemplateContent($_REQUEST['brand'] ?? 'digium');

            case 'resetTemplate':
                return $this->resetTemplate($_REQUEST['brand'] ?? 'digium');

            case 'getBrands':
                return $this->getBrands();

            case 'getExtensions':
                return $this->getExtensions();

            case 'autoAssignExtensions':
                return $this->autoAssignExtensions();

            case 'exportCsv':
                return $this->exportCsv();

            case 'getDhcpLeases':
                return $this->getDhcpLeases();

            case 'addDiscoveredDevice':
                return $this->addDevice($_REQUEST['mac'], '', '');

            case 'addDiscoveredDevices':
                return $this->addDiscoveredDevices($_REQUEST['macs']);

            case 'pullPhoneConfig':
                return $this->pullPhoneConfig($_REQUEST['mac']);

            case 'revertConfigTemplate':
                return $this->revertConfigTemplate($_REQUEST['mac']);

            case 'pullSelectedConfigFiles':
                return $this->pullSelectedConfigFiles($_REQUEST['macs']);

            case 'revertSelectedConfigFiles':
                return $this->revertSelectedConfigFiles($_REQUEST['macs']);

            case 'fetchPhoneConfig':
                return $this->fetchPhoneConfig($_REQUEST['mac']);

            case 'saveAsActiveConfig':
                return $this->saveAsActiveConfig($_REQUEST['mac'], $_REQUEST['content']);

            default:
                return false;
        }
    }

    // =====================
    // PAGE
    // =====================
    public function showPage() {
        $vars = ['brands' => $this->getBrands()];
        return load_view(__DIR__ . '/views/main.php', $vars);
    }

    public function getActionBar($request) {
        return [];
    }

    public function getRightNav($request) {
        return '';
    }

    private function ensureTables() {
        $this->db->query("CREATE TABLE IF NOT EXISTS provisioner_devices (id INT AUTO_INCREMENT PRIMARY KEY, mac_address VARCHAR(12) NOT NULL UNIQUE, extension VARCHAR(20) NOT NULL, description VARCHAR(255) DEFAULT '', brand VARCHAR(50) DEFAULT 'digium', created_at DATETIME DEFAULT NULL, updated_at DATETIME DEFAULT NULL, needs_changes TINYINT(1) NOT NULL DEFAULT 1, previous_extension VARCHAR(20) DEFAULT NULL, previous_description VARCHAR(255) DEFAULT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8");
        $this->db->query("CREATE TABLE IF NOT EXISTS provisioner_logs (id INT AUTO_INCREMENT PRIMARY KEY, timestamp DATETIME NOT NULL, action VARCHAR(255) NOT NULL, details TEXT, status VARCHAR(50)) ENGINE=InnoDB DEFAULT CHARSET=utf8");
        $this->db->query("CREATE TABLE IF NOT EXISTS provisioner_settings (key_name VARCHAR(100) NOT NULL PRIMARY KEY, value TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8");
    }
}
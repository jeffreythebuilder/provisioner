<?php
$provisionerDb = isset($db) ? $db : FreePBX::Database();

$provisionerDb->query("DROP TABLE IF EXISTS provisioner_logs");
$provisionerDb->query("DROP TABLE IF EXISTS provisioner_devices");
$provisionerDb->query("DROP TABLE IF EXISTS provisioner_settings");

$provDir = '/var/www/html/provisioning';
if (is_dir($provDir)) {
    $dh = opendir($provDir);
    while (($file = readdir($dh)) !== false) {
        $ext = substr($file, -4);
        if ($ext === '.cfg') {
            if (preg_match('/^f0A\d+hw1\.100\.cfg$/', $file)) continue;
            if ($file === 'template.cfg') continue;
            unlink($provDir . '/' . $file);
        } elseif (preg_match('/^config\.[a-f0-9]{12}\.xml$/i', $file)) {
            unlink($provDir . '/' . $file);
        }
    }
    closedir($dh);
}
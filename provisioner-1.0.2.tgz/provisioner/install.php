<?php
$provisionerDb = FreePBX::Database();

try { $provisionerDb->query("ALTER TABLE provisioner_devices ADD COLUMN needs_changes TINYINT(1) NOT NULL DEFAULT 1"); } catch (\Exception $e) {}
try { $provisionerDb->query("ALTER TABLE provisioner_devices ADD COLUMN previous_extension VARCHAR(20) DEFAULT NULL"); } catch (\Exception $e) {}
try { $provisionerDb->query("ALTER TABLE provisioner_devices ADD COLUMN previous_description VARCHAR(255) DEFAULT NULL"); } catch (\Exception $e) {}
try { $provisionerDb->query("ALTER TABLE provisioner_devices ADD COLUMN brand VARCHAR(50) DEFAULT 'digium'"); } catch (\Exception $e) {}
try { $provisionerDb->query("ALTER TABLE provisioner_devices ADD COLUMN custom_config TINYINT(1) NOT NULL DEFAULT 0"); } catch (\Exception $e) {}

// Repair older schema: add PK, AUTO_INCREMENT, drop duplicate indexes
try {
    $row = $provisionerDb->query("SHOW CREATE TABLE provisioner_devices")->fetch(\PDO::FETCH_ASSOC);
    $sql = $row['Create Table'];
    if (strpos($sql, 'AUTO_INCREMENT') === false && strpos($sql, 'id int') !== false) {
        $indexes = $provisionerDb->query("SHOW INDEX FROM provisioner_devices WHERE Key_name LIKE 'mac_address\\_%' AND Seq_in_index = 1")->fetchAll(\PDO::FETCH_ASSOC);
        foreach ($indexes as $idx) {
            if ($idx['Key_name'] !== 'mac_address') {
                try { $provisionerDb->query("ALTER TABLE provisioner_devices DROP INDEX `{$idx['Key_name']}`"); } catch (\Exception $e) {}
            }
        }
        try { $provisionerDb->query("ALTER TABLE provisioner_devices DROP INDEX mac_address"); } catch (\Exception $e) {}
        try { $provisionerDb->query("ALTER TABLE provisioner_devices ADD PRIMARY KEY (id)"); } catch (\Exception $e) {}
        try { $provisionerDb->query("ALTER TABLE provisioner_devices MODIFY id INT AUTO_INCREMENT"); } catch (\Exception $e) {}
        try { $provisionerDb->query("ALTER TABLE provisioner_devices ADD UNIQUE (mac_address)"); } catch (\Exception $e) {}
    }
} catch (\Exception $e) {}

$defaults = [
    'pbx_ip'   => '192.168.0.10',
    'sip_port' => '5060',
    'transport'=> 'UDP',
    'prov_dir' => '/var/www/html/provisioning',
];

try {
    $stmt = $provisionerDb->prepare("INSERT IGNORE INTO provisioner_settings (key_name, value) VALUES (?, ?)");
    foreach ($defaults as $key => $value) {
        $stmt->execute([$key, $value]);
    }
} catch (\Exception $e) {}

$templateDir = __DIR__ . '/templates';
$provDir = '/var/www/html/provisioning';
if (!is_dir($provDir)) {
    mkdir($provDir, 0755, true);
}
@chown($provDir, 'asterisk');
@chgrp($provDir, 'asterisk');

$modelFiles = ['f0A20hw1.100.cfg', 'f0A22hw1.100.cfg', 'f0A25hw1.100.cfg'];
foreach ($modelFiles as $file) {
    $src = $templateDir . '/digium/' . $file;
    $dst = $provDir . '/' . $file;
    if (file_exists($src) && !file_exists($dst)) {
        copy($src, $dst);
    }
}
